/*!
 * \file solution_direct_mean.cpp
 * \brief Main subrotuines for solving direct problems (Euler, Navier-Stokes, etc.).
 * \author F. Palacios, T. Economon
 * \version 3.2.8 "eagle"
 *
 * SU2 Lead Developers: Dr. Francisco Palacios (fpalacios@stanford.edu).
 *                      Dr. Thomas D. Economon (economon@stanford.edu).
 *
 * SU2 Developers: Prof. Juan J. Alonso's group at Stanford University.
 *                 Prof. Piero Colonna's group at Delft University of Technology.
 *                 Prof. Nicolas R. Gauger's group at Kaiserslautern University of Technology.
 *                 Prof. Alberto Guardone's group at Polytechnic University of Milan.
 *                 Prof. Rafael Palacios' group at Imperial College London.
 *
 * Copyright (C) 2012-2015 SU2, the open-source CFD code.
 *
 * SU2 is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * SU2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with SU2. If not, see <http://www.gnu.org/licenses/>.
 */

#include "../include/solver_structure.hpp"

CEulerSolver::CEulerSolver(void) : CSolver() {

    CDrag_Inv = NULL; CLift_Inv = NULL; CSideForce_Inv = NULL;  CEff_Inv = NULL;
    CMx_Inv = NULL; CMy_Inv = NULL; CMz_Inv = NULL;
    CFx_Inv = NULL; CFy_Inv = NULL; CFz_Inv = NULL;

    CPressure = NULL; CPressureTarget = NULL; HeatFlux = NULL; HeatFluxTarget = NULL; YPlus = NULL;
    ForceInviscid = NULL; MomentInviscid = NULL;

    Surface_CLift_Inv = NULL; Surface_CDrag_Inv = NULL; Surface_CSideForce_Inv = NULL; Surface_CEff_Inv = NULL;
    Surface_CFx_Inv = NULL; Surface_CFy_Inv = NULL; Surface_CFz_Inv = NULL;
    Surface_CMx_Inv = NULL; Surface_CMy_Inv = NULL; Surface_CMz_Inv = NULL;

    Surface_CLift = NULL; Surface_CDrag = NULL; Surface_CSideForce = NULL; Surface_CEff = NULL;
    Surface_CFx = NULL; Surface_CFy = NULL; Surface_CFz = NULL;
    Surface_CMx = NULL; Surface_CMy = NULL; Surface_CMz = NULL;

    CMerit_Inv = NULL;  CT_Inv = NULL;  CQ_Inv = NULL;
    CNearFieldOF_Inv = NULL;

    iPoint_UndLapl = NULL;
    jPoint_UndLapl = NULL;
    LowMach_Precontioner = NULL;
    Primitive = NULL; Primitive_i = NULL; Primitive_j = NULL;
    CharacPrimVar = NULL;

    Smatrix = NULL;

    Secondary_i = NULL; Secondary_j = NULL;

    Cauchy_Value = 0;
    Cauchy_Func = 0;
    Old_Func = 0;
    New_Func = 0;
    Cauchy_Counter = 0;
    Cauchy_Serie = NULL;

    FluidModel   = NULL;

}

CEulerSolver::CEulerSolver(CGeometry *geometry, CConfig *config, unsigned short iMesh) : CSolver() {

    unsigned long iPoint, counter_local = 0, counter_global = 0, iVertex;
    unsigned short iVar, iDim, iMarker, nLineLets;
    double Density, Velocity2, Pressure, Temperature;

    bool compressible = (config->GetKind_Regime() == COMPRESSIBLE);
    bool incompressible = (config->GetKind_Regime() == INCOMPRESSIBLE);
    bool freesurface = (config->GetKind_Regime() == FREESURFACE);
    bool roe_turkel = (config->GetKind_Upwind_Flow() == TURKEL);
    bool low_mach_prec = config->Low_Mach_Preconditioning();

    int rank = MASTER_NODE;
#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

    CDrag_Inv = NULL; CLift_Inv = NULL; CSideForce_Inv = NULL;  CEff_Inv = NULL;
    CMx_Inv = NULL; CMy_Inv = NULL; CMz_Inv = NULL;
    CFx_Inv = NULL; CFy_Inv = NULL; CFz_Inv = NULL;

    CPressure = NULL; CPressureTarget = NULL; HeatFlux = NULL; HeatFluxTarget = NULL; YPlus = NULL;
    ForceInviscid = NULL; MomentInviscid = NULL;

    Surface_CLift_Inv = NULL; Surface_CDrag_Inv = NULL; Surface_CSideForce_Inv = NULL; Surface_CEff_Inv = NULL;
    Surface_CFx_Inv = NULL; Surface_CFy_Inv = NULL; Surface_CFz_Inv = NULL;
    Surface_CMx_Inv = NULL; Surface_CMy_Inv = NULL; Surface_CMz_Inv = NULL;

    Surface_CLift = NULL; Surface_CDrag = NULL; Surface_CSideForce = NULL; Surface_CEff = NULL;
    Surface_CFx = NULL; Surface_CFy = NULL; Surface_CFz = NULL;
    Surface_CMx = NULL; Surface_CMy = NULL; Surface_CMz = NULL;


    CMerit_Inv = NULL;  CT_Inv = NULL;  CQ_Inv = NULL; CNearFieldOF_Inv = NULL;

    CNearFieldOF_Inv = NULL;

    iPoint_UndLapl = NULL;  jPoint_UndLapl = NULL;
    LowMach_Precontioner = NULL;
    Primitive = NULL; Primitive_i = NULL; Primitive_j = NULL;
    CharacPrimVar = NULL;
    Cauchy_Serie = NULL;

    Smatrix = NULL;

    Secondary_i=NULL; Secondary_j=NULL;

    Cauchy_Value = 0;
    Cauchy_Func = 0;
    Old_Func = 0;
    New_Func = 0;
    Cauchy_Counter = 0;
    Cauchy_Serie = NULL;

    FluidModel = NULL;

    Gamma = config->GetGamma();
    Gamma_Minus_One = Gamma - 1.0;

    nDim = 3;//geometry->GetnDim();

    if (incompressible) { nVar = nDim+1; nPrimVar = nDim+5; nPrimVarGrad = nDim+3; }
    if (freesurface)    { nVar = nDim+2; nPrimVar = nDim+7; nPrimVarGrad = nDim+6; }
    if (compressible)   { nVar = nDim+2;
        nPrimVar = nDim+9; nPrimVarGrad = nDim+4;
        nSecondaryVar = 2; nSecondaryVarGrad = 2;
    }

    nMarker      = config->GetnMarker_All();
    nElem       = geometry->GetnElem();
    nElemDomain = geometry->GetnElemDomain();

    nElem_Bound = new unsigned long[nMarker];
    for (iMarker = 0; iMarker < nMarker; iMarker++)
        nElem_Bound[iMarker] = geometry->nElem_Bound[iMarker];

    SetNondimensionalization(geometry, config, iMesh);

    elem = new CVariable*[nElem];

    Residual      = new double[nVar];         for (iVar = 0; iVar < nVar; iVar++) Residual[iVar]      = 0.0;
    Residual_RMS  = new double[nVar];         for (iVar = 0; iVar < nVar; iVar++) Residual_RMS[iVar]  = 0.0;
    Residual_Max  = new double[nVar];         for (iVar = 0; iVar < nVar; iVar++) Residual_Max[iVar]  = 0.0;
    Residual_i    = new double[nVar];         for (iVar = 0; iVar < nVar; iVar++) Residual_i[iVar]    = 0.0;
    Residual_j    = new double[nVar];         for (iVar = 0; iVar < nVar; iVar++) Residual_j[iVar]    = 0.0;
    Res_Conv      = new double[nVar];         for (iVar = 0; iVar < nVar; iVar++) Res_Conv[iVar]      = 0.0;
    Res_Visc      = new double[nVar];         for (iVar = 0; iVar < nVar; iVar++) Res_Visc[iVar]      = 0.0;
    Res_Sour      = new double[nVar];         for (iVar = 0; iVar < nVar; iVar++) Res_Sour[iVar]      = 0.0;

    Point_Max     = new unsigned long[nVar];  for (iVar = 0; iVar < nVar; iVar++) Point_Max[iVar]     = 0;
    Point_Max_Coord = new double*[nVar];
    for (iVar = 0; iVar < nVar; iVar++) {
        Point_Max_Coord[iVar] = new double[nDim];
        for (iDim = 0; iDim < nDim; iDim++) Point_Max_Coord[iVar][iDim] = 0.0;
    }

    Solution   = new double[nVar]; for (iVar = 0; iVar < nVar; iVar++) Solution[iVar]   = 0.0;
    Solution_i = new double[nVar]; for (iVar = 0; iVar < nVar; iVar++) Solution_i[iVar] = 0.0;
    Solution_j = new double[nVar]; for (iVar = 0; iVar < nVar; iVar++) Solution_j[iVar] = 0.0;

    Vector   = new double[nDim]; for (iDim = 0; iDim < nDim; iDim++) Vector[iDim]   = 0.0;
    Vector_i = new double[nDim]; for (iDim = 0; iDim < nDim; iDim++) Vector_i[iDim] = 0.0;
    Vector_j = new double[nDim]; for (iDim = 0; iDim < nDim; iDim++) Vector_j[iDim] = 0.0;

    Primitive   = new double[nPrimVar]; for (iVar = 0; iVar < nPrimVar; iVar++) Primitive[iVar]   = 0.0;
    Primitive_i = new double[nPrimVar]; for (iVar = 0; iVar < nPrimVar; iVar++) Primitive_i[iVar] = 0.0;
    Primitive_j = new double[nPrimVar]; for (iVar = 0; iVar < nPrimVar; iVar++) Primitive_j[iVar] = 0.0;

    Secondary_i = new double[nSecondaryVar]; for (iVar = 0; iVar < nSecondaryVar; iVar++) Secondary_i[iVar] = 0.0;
    Secondary_j = new double[nSecondaryVar]; for (iVar = 0; iVar < nSecondaryVar; iVar++) Secondary_j[iVar] = 0.0;


    if (config->GetKind_ConvNumScheme_Flow() == SPACE_CENTERED) {
        iPoint_UndLapl = new double [nElem];
        jPoint_UndLapl = new double [nElem];
    }

    if (roe_turkel || low_mach_prec) {
        LowMach_Precontioner = new double* [nVar];
        for (iVar = 0; iVar < nVar; iVar ++)
            LowMach_Precontioner[iVar] = new double[nVar];
    }
    LinSysSol.Initialize(nElem, nElemDomain, nVar, 0.0);
    LinSysRes.Initialize(nElem, nElemDomain, nVar, 0.0);
    if (config->GetKind_TimeIntScheme_Flow() == EULER_IMPLICIT) {

        Jacobian_i = new double* [nVar];
        Jacobian_j = new double* [nVar];
        for (iVar = 0; iVar < nVar; iVar++) {
            Jacobian_i[iVar] = new double [nVar];
            Jacobian_j[iVar] = new double [nVar];
        }

        if (rank == MASTER_NODE) cout << "Initialize Jacobian structure (Euler). MG level: " << iMesh <<"." << endl;
        Jacobian.Initialize(nElem, nElemDomain, nVar, nVar, true, geometry, config);

        if ((config->GetKind_Linear_Solver_Prec() == LINELET) ||
                (config->GetKind_Linear_Solver() == SMOOTHER_LINELET)) {
            nLineLets = Jacobian.BuildLineletPreconditioner(geometry, config);
            if (rank == MASTER_NODE) cout << "Compute linelet structure. " << nLineLets << " elements in each line (average)." << endl;
        }

    } else {
        if (rank == MASTER_NODE) cout << "Explicit scheme. No Jacobian structure (Euler). MG level: " << iMesh <<"." << endl;
    }

    if (config->GetKind_Gradient_Method() == WEIGHTED_LEAST_SQUARES) {

        Smatrix = new double* [nDim];
        for (iDim = 0; iDim < nDim; iDim++)
            Smatrix[iDim] = new double [nDim];

        cvector = new double* [nPrimVarGrad];
        for (iVar = 0; iVar < nPrimVarGrad; iVar++)
            cvector[iVar] = new double [nDim];

    }

    CharacPrimVar = new double** [nMarker];
    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        CharacPrimVar[iMarker] = new double* [geometry->nElem_Bound[iMarker]];
        for (iVertex = 0; iVertex < geometry->nElem_Bound[iMarker]; iVertex++) {
            CharacPrimVar[iMarker][iVertex] = new double [nPrimVar];
            for (iVar = 0; iVar < nPrimVar; iVar++) {
                CharacPrimVar[iMarker][iVertex][iVar] = 0.0;
            }
        }
    }

    CPressure = new double* [nMarker];
    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        CPressure[iMarker] = new double [geometry->nElem_Bound[iMarker]];
        for (iVertex = 0; iVertex < geometry->nElem_Bound[iMarker]; iVertex++) {
            CPressure[iMarker][iVertex] = 0.0;
        }
    }

    CPressureTarget = new double* [nMarker];
    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        CPressureTarget[iMarker] = new double [geometry->nElem_Bound[iMarker]];
        for (iVertex = 0; iVertex < geometry->nElem_Bound[iMarker]; iVertex++) {
            CPressureTarget[iMarker][iVertex] = 0.0;
        }
    }

    ForceInviscid     = new double[nDim];
    MomentInviscid    = new double[3];
    CDrag_Inv         = new double[nMarker];
    CLift_Inv         = new double[nMarker];
    CSideForce_Inv    = new double[nMarker];
    CMx_Inv           = new double[nMarker];
    CMy_Inv           = new double[nMarker];
    CMz_Inv           = new double[nMarker];
    CEff_Inv          = new double[nMarker];
    CFx_Inv           = new double[nMarker];
    CFy_Inv           = new double[nMarker];
    CFz_Inv           = new double[nMarker];

    Surface_CLift_Inv      = new double[config->GetnMarker_Monitoring()];
    Surface_CDrag_Inv      = new double[config->GetnMarker_Monitoring()];
    Surface_CSideForce_Inv = new double[config->GetnMarker_Monitoring()];
    Surface_CEff_Inv       = new double[config->GetnMarker_Monitoring()];
    Surface_CFx_Inv        = new double[config->GetnMarker_Monitoring()];
    Surface_CFy_Inv        = new double[config->GetnMarker_Monitoring()];
    Surface_CFz_Inv        = new double[config->GetnMarker_Monitoring()];
    Surface_CMx_Inv        = new double[config->GetnMarker_Monitoring()];
    Surface_CMy_Inv        = new double[config->GetnMarker_Monitoring()];
    Surface_CMz_Inv        = new double[config->GetnMarker_Monitoring()];

    Surface_CLift          = new double[config->GetnMarker_Monitoring()];
    Surface_CDrag          = new double[config->GetnMarker_Monitoring()];
    Surface_CSideForce     = new double[config->GetnMarker_Monitoring()];
    Surface_CEff           = new double[config->GetnMarker_Monitoring()];
    Surface_CFx            = new double[config->GetnMarker_Monitoring()];
    Surface_CFy            = new double[config->GetnMarker_Monitoring()];
    Surface_CFz            = new double[config->GetnMarker_Monitoring()];
    Surface_CMx            = new double[config->GetnMarker_Monitoring()];
    Surface_CMy            = new double[config->GetnMarker_Monitoring()];
    Surface_CMz            = new double[config->GetnMarker_Monitoring()];

    CT_Inv           = new double[nMarker];
    CQ_Inv           = new double[nMarker];
    CMerit_Inv       = new double[nMarker];
    CNearFieldOF_Inv = new double[nMarker];

    Total_CDrag = 0.0;    Total_CLift = 0.0;      Total_CSideForce = 0.0;
    Total_CMx = 0.0;      Total_CMy = 0.0;        Total_CMz = 0.0;
    Total_CEff = 0.0;     Total_CNearFieldOF = 0.0;
    Total_CFx = 0.0;      Total_CFy = 0.0;        Total_CFz = 0.0;
    Total_CT = 0.0;       Total_CQ = 0.0;         Total_CMerit = 0.0;
    Total_MaxHeat = 0.0;  Total_Heat = 0.0;
    Total_CpDiff = 0.0;   Total_HeatFluxDiff = 0.0;

    /*--- Read farfield conditions ---*/

    Density_Inf     = config->GetDensity_FreeStreamND();
    Pressure_Inf    = config->GetPressure_FreeStreamND();
    Velocity_Inf    = config->GetVelocity_FreeStreamND();
    Energy_Inf      = config->GetEnergy_FreeStreamND();
    Temperature_Inf = config->GetTemperature_FreeStreamND();
    Mach_Inf        = config->GetMach();

    /*--- Check for a restart and set up the variables at each node
     appropriately.  OMITTED! ---*/

    for (iPoint = 0; iPoint < nElem; iPoint++)
        elem[iPoint] = new CEulerVariable(Density_Inf, Velocity_Inf, Energy_Inf, nDim, nVar, config);

    if (compressible) {
        counter_local = 0;
        for (iPoint = 0; iPoint < nElem; iPoint++) {
            Density = elem[iPoint]->GetSolution(0);
            Velocity2 = 0.0;
            for (iDim = 0; iDim < nDim; iDim++)
                Velocity2 += (elem[iPoint]->GetSolution(iDim+1)/Density)*(elem[iPoint]->GetSolution(iDim+1)/Density);
            double StaticEnergy= elem[iPoint]->GetSolution(nDim+1)/Density-0.5*Velocity2;
            FluidModel->SetTDState_rhoe(Density, StaticEnergy);
            Pressure= FluidModel->GetPressure();
            Temperature= FluidModel->GetTemperature();
            if ((Pressure < 0.0) || (Temperature < 0.0)) {
                Solution[0] = Density_Inf;
                for (iDim = 0; iDim < nDim; iDim++)
                    Solution[iDim+1] = Velocity_Inf[iDim]*Density_Inf;
                Solution[nDim+1] = Energy_Inf*Density_Inf;
                elem[iPoint]->SetSolution(Solution);
                elem[iPoint]->SetSolution_Old(Solution);
                counter_local++;
            }
        }

        if (config->GetConsole_Output_Verb() == VERB_HIGH) {
#ifdef HAVE_MPI
            MPI_Reduce(&counter_local, &counter_global, 1, MPI_UNSIGNED_LONG, MPI_SUM, MASTER_NODE, MPI_COMM_WORLD);
#else
            counter_global = counter_local;
#endif
            if ((rank == MASTER_NODE) && (counter_global != 0))
                cout << "Warning. The original solution contains "<< counter_global << " points that are not physical." << endl;
        }

    }

    if (config->GetKind_ConvNumScheme_Flow() == SPACE_CENTERED ) space_centered = true;
    else space_centered = false;

    if (config->GetKind_TimeIntScheme_Flow() == EULER_IMPLICIT) euler_implicit = true;
    else euler_implicit = false;

    if (config->GetKind_Gradient_Method() == WEIGHTED_LEAST_SQUARES) least_squares = true;
    else least_squares = false;

    Set_MPI_Solution(geometry, config);

}

CEulerSolver::~CEulerSolver(void) {

    unsigned short iVar, iMarker;
    unsigned long iVertex;

    if (CDrag_Inv != NULL)         delete [] CDrag_Inv;
    if (CLift_Inv != NULL)         delete [] CLift_Inv;
    if (CSideForce_Inv != NULL)    delete [] CSideForce_Inv;
    if (CMx_Inv != NULL)           delete [] CMx_Inv;
    if (CMy_Inv != NULL)           delete [] CMy_Inv;
    if (CMz_Inv != NULL)           delete [] CMz_Inv;
    if (CFx_Inv != NULL)           delete [] CFx_Inv;
    if (CFy_Inv != NULL)           delete [] CFy_Inv;
    if (CFz_Inv != NULL)           delete [] CFz_Inv;
    if (Surface_CLift_Inv != NULL) delete[] Surface_CLift_Inv;
    if (Surface_CDrag_Inv != NULL) delete[] Surface_CDrag_Inv;
    if (Surface_CSideForce_Inv != NULL) delete[] Surface_CSideForce_Inv;
    if (Surface_CEff_Inv != NULL) delete[] Surface_CEff_Inv;
    if (Surface_CFx_Inv != NULL)  delete [] Surface_CFx_Inv;
    if (Surface_CFy_Inv != NULL)  delete [] Surface_CFy_Inv;
    if (Surface_CFz_Inv != NULL)  delete [] Surface_CFz_Inv;
    if (Surface_CMx_Inv != NULL)  delete [] Surface_CMx_Inv;
    if (Surface_CMy_Inv != NULL)  delete [] Surface_CMy_Inv;
    if (Surface_CMz_Inv != NULL)  delete [] Surface_CMz_Inv;

    if (Surface_CLift != NULL)    delete [] Surface_CLift;
    if (Surface_CDrag != NULL)    delete [] Surface_CDrag;
    if (Surface_CSideForce != NULL) delete [] Surface_CSideForce;
    if (Surface_CEff != NULL) delete [] Surface_CEff;
    if (Surface_CFx != NULL)      delete [] Surface_CFx;
    if (Surface_CFy != NULL)      delete [] Surface_CFy;
    if (Surface_CFz != NULL)      delete [] Surface_CFz;
    if (Surface_CMx != NULL)      delete [] Surface_CMx;
    if (Surface_CMy != NULL)      delete [] Surface_CMy;
    if (Surface_CMz != NULL)      delete [] Surface_CMz;
    if (CEff_Inv != NULL)          delete [] CEff_Inv;
    if (CMerit_Inv != NULL)        delete [] CMerit_Inv;
    if (CT_Inv != NULL)            delete [] CT_Inv;
    if (CQ_Inv != NULL)            delete [] CQ_Inv;
    if (CNearFieldOF_Inv != NULL)  delete [] CNearFieldOF_Inv;

    if (ForceInviscid != NULL)     delete [] ForceInviscid;
    if (MomentInviscid != NULL)    delete [] MomentInviscid;
    if (iPoint_UndLapl != NULL)       delete [] iPoint_UndLapl;
    if (jPoint_UndLapl != NULL)       delete [] jPoint_UndLapl;
    if (Primitive != NULL)        delete [] Primitive;
    if (Primitive_i != NULL)      delete [] Primitive_i;
    if (Primitive_j != NULL)      delete [] Primitive_j;
    if (Secondary_i != NULL)      delete [] Secondary_i;
    if (Secondary_j != NULL)      delete [] Secondary_j;

    if (LowMach_Precontioner != NULL) {
        for (iVar = 0; iVar < nVar; iVar ++)
            delete LowMach_Precontioner[iVar];
        delete [] LowMach_Precontioner;
    }

    if (CPressure != NULL) {
        for (iMarker = 0; iMarker < nMarker; iMarker++)
            delete CPressure[iMarker];
        delete [] CPressure;
    }

    if (CPressureTarget != NULL) {
        for (iMarker = 0; iMarker < nMarker; iMarker++)
            delete CPressureTarget[iMarker];
        delete [] CPressureTarget;
    }

    if (CharacPrimVar != NULL) {
        for (iMarker = 0; iMarker < nMarker; iMarker++) {
            for (iVertex = 0; iVertex < nElem_Bound[iMarker]; iVertex++) {
                delete CharacPrimVar[iMarker][iVertex];
            }
        }
        delete [] CharacPrimVar;
    }

    if (nElem_Bound != NULL)  delete [] nElem_Bound;

    if (HeatFlux != NULL) {
        for (iMarker = 0; iMarker < nMarker; iMarker++) {
            delete HeatFlux[iMarker];
        }
        delete [] HeatFlux;
    }

    if (HeatFluxTarget != NULL) {
        for (iMarker = 0; iMarker < nMarker; iMarker++) {
            delete HeatFluxTarget[iMarker];
        }
        delete [] HeatFluxTarget;
    }

    if (YPlus != NULL) {
        for (iMarker = 0; iMarker < nMarker; iMarker++) {
            delete YPlus[iMarker];
        }
        delete [] YPlus;
    }

    if (Cauchy_Serie != NULL)
        delete [] Cauchy_Serie;

    if (FluidModel != NULL) delete FluidModel;


}

void CEulerSolver::Set_MPI_Solution(CGeometry *geometry, CConfig *config) {

    unsigned short iVar, iMarker, iPeriodic_Index, MarkerS, MarkerR;
    unsigned long iVertex, iPoint, nVertexS, nVertexR, nBufferS_Vector, nBufferR_Vector;
    double rotMatrix[3][3], *angles, theta, cosTheta, sinTheta, phi, cosPhi, sinPhi, psi, cosPsi, sinPsi, *Buffer_Receive_U = NULL, *Buffer_Send_U = NULL;

#ifdef HAVE_MPI
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

#ifdef HAVE_MPI
    int send_to, receive_from;
    MPI_Status status;
#endif

    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        if ((config->GetMarker_All_KindBC(iMarker) == SEND_RECEIVE) &&
                (config->GetMarker_All_SendRecv(iMarker) > 0)) {

            MarkerS = iMarker;  MarkerR = iMarker+1;

#ifdef HAVE_MPI
            send_to = config->GetMarker_All_SendRecv(MarkerS)-1;
            receive_from = abs(config->GetMarker_All_SendRecv(MarkerR))-1;
#endif

            nVertexS = geometry->nElem_Bound[MarkerS];  nVertexR = geometry->nElem_Bound[MarkerR];
            nBufferS_Vector = nVertexS*nVar;        nBufferR_Vector = nVertexR*nVar;

            /*--- Allocate Receive and send buffers  ---*/
            Buffer_Receive_U  = new double [nBufferR_Vector];
            Buffer_Send_U = new double[nBufferS_Vector];

            /*--- Copy the solution that should be sended ---*/
            for (iVertex = 0; iVertex < nVertexS; iVertex++) {

                iPoint = geometry->bound[MarkerS][iVertex]->GetBound_Element();

                for (iVar = 0; iVar < nVar; iVar++)
                    Buffer_Send_U[iVar*nVertexS+iVertex] = elem[iPoint]->GetSolution(iVar);
            }

#ifdef HAVE_MPI

            /*--- Send/Receive information using Sendrecv ---*/
            MPI_Sendrecv(Buffer_Send_U, nBufferS_Vector, MPI_DOUBLE, send_to, 0,
                         Buffer_Receive_U, nBufferR_Vector, MPI_DOUBLE, receive_from, 0, MPI_COMM_WORLD, &status);

#else

            for (iVertex = 0; iVertex < nVertexR; iVertex++) {
                for (iVar = 0; iVar < nVar; iVar++)
                    Buffer_Receive_U[iVar*nVertexR+iVertex] = Buffer_Send_U[iVar*nVertexR+iVertex];
            }

#endif

            delete [] Buffer_Send_U;

            for (iVertex = 0; iVertex < nVertexR; iVertex++) {

                iPoint = geometry->bound[MarkerR][iVertex]->GetBound_Element();

                theta    = 0;   phi    = 0;     psi    = 0;
                cosTheta = cos(theta);  cosPhi = cos(phi);      cosPsi = cos(psi);
                sinTheta = sin(theta);  sinPhi = sin(phi);      sinPsi = sin(psi);

                rotMatrix[0][0] = cosPhi*cosPsi;    rotMatrix[1][0] = sinTheta*sinPhi*cosPsi - cosTheta*sinPsi;     rotMatrix[2][0] = cosTheta*sinPhi*cosPsi + sinTheta*sinPsi;
                rotMatrix[0][1] = cosPhi*sinPsi;    rotMatrix[1][1] = sinTheta*sinPhi*sinPsi + cosTheta*cosPsi;     rotMatrix[2][1] = cosTheta*sinPhi*sinPsi - sinTheta*cosPsi;
                rotMatrix[0][2] = -sinPhi;          rotMatrix[1][2] = sinTheta*cosPhi;                              rotMatrix[2][2] = cosTheta*cosPhi;

                for (iVar = 0; iVar < nVar; iVar++)
                    Solution[iVar] = Buffer_Receive_U[iVar*nVertexR+iVertex];

                if (nDim == 2) {
                    Solution[1] = rotMatrix[0][0]*Buffer_Receive_U[1*nVertexR+iVertex] +
                            rotMatrix[0][1]*Buffer_Receive_U[2*nVertexR+iVertex];
                    Solution[2] = rotMatrix[1][0]*Buffer_Receive_U[1*nVertexR+iVertex] +
                            rotMatrix[1][1]*Buffer_Receive_U[2*nVertexR+iVertex];
                }
                else {
                    Solution[1] = rotMatrix[0][0]*Buffer_Receive_U[1*nVertexR+iVertex] +
                            rotMatrix[0][1]*Buffer_Receive_U[2*nVertexR+iVertex] +
                            rotMatrix[0][2]*Buffer_Receive_U[3*nVertexR+iVertex];
                    Solution[2] = rotMatrix[1][0]*Buffer_Receive_U[1*nVertexR+iVertex] +
                            rotMatrix[1][1]*Buffer_Receive_U[2*nVertexR+iVertex] +
                            rotMatrix[1][2]*Buffer_Receive_U[3*nVertexR+iVertex];
                    Solution[3] = rotMatrix[2][0]*Buffer_Receive_U[1*nVertexR+iVertex] +
                            rotMatrix[2][1]*Buffer_Receive_U[2*nVertexR+iVertex] +
                            rotMatrix[2][2]*Buffer_Receive_U[3*nVertexR+iVertex];
                }

                for (iVar = 0; iVar < nVar; iVar++){
                    elem[iPoint]->SetSolution(iVar, Solution[iVar]);
                }
            }


            delete [] Buffer_Receive_U;
        }

    }

}

void CEulerSolver::Set_MPI_Solution_Old(CGeometry *geometry, CConfig *config) {
    unsigned short iVar, iMarker, iPeriodic_Index, MarkerS, MarkerR;
    unsigned long iVertex, iPoint, nVertexS, nVertexR, nBufferS_Vector, nBufferR_Vector;
    double rotMatrix[3][3], *angles, theta, cosTheta, sinTheta, phi, cosPhi, sinPhi, psi, cosPsi, sinPsi,
            *Buffer_Receive_U = NULL, *Buffer_Send_U = NULL;

#ifdef HAVE_MPI
    int send_to, receive_from;
    MPI_Status status;
#endif

    for (iMarker = 0; iMarker < nMarker; iMarker++) {

        if ((config->GetMarker_All_KindBC(iMarker) == SEND_RECEIVE) &&
                (config->GetMarker_All_SendRecv(iMarker) > 0)) {

            MarkerS = iMarker;  MarkerR = iMarker+1;

#ifdef HAVE_MPI
            send_to = config->GetMarker_All_SendRecv(MarkerS)-1;
            receive_from = abs(config->GetMarker_All_SendRecv(MarkerR))-1;
#endif

            nVertexS = geometry->nElem_Bound[MarkerS];  nVertexR = geometry->nElem_Bound[MarkerR];
            nBufferS_Vector = nVertexS*nVar;        nBufferR_Vector = nVertexR*nVar;

            /*--- Allocate Receive and send buffers  ---*/
            Buffer_Receive_U = new double [nBufferR_Vector];
            Buffer_Send_U = new double[nBufferS_Vector];

            /*--- Copy the solution old that should be sended ---*/
            for (iVertex = 0; iVertex < nVertexS; iVertex++) {
                iPoint = geometry->bound[MarkerS][iVertex]->GetBound_Element();
                for (iVar = 0; iVar < nVar; iVar++)
                    Buffer_Send_U[iVar*nVertexS+iVertex] = elem[iPoint]->GetSolution_Old(iVar);
            }

#ifdef HAVE_MPI

            /*--- Send/Receive information using Sendrecv ---*/
            MPI_Sendrecv(Buffer_Send_U, nBufferS_Vector, MPI_DOUBLE, send_to, 0,
                         Buffer_Receive_U, nBufferR_Vector, MPI_DOUBLE, receive_from, 0, MPI_COMM_WORLD, &status);

#else

            /*--- Receive information without MPI ---*/
            for (iVertex = 0; iVertex < nVertexR; iVertex++) {
                for (iVar = 0; iVar < nVar; iVar++)
                    Buffer_Receive_U[iVar*nVertexR+iVertex] = Buffer_Send_U[iVar*nVertexR+iVertex];
            }

#endif

            /*--- Deallocate send buffer ---*/
            delete [] Buffer_Send_U;

            /*--- Do the coordinate transformation ---*/
            for (iVertex = 0; iVertex < nVertexR; iVertex++) {

                /*--- Find point and its type of transformation ---*/
                iPoint = geometry->bound[MarkerR][iVertex]->GetBound_Element();

                /*--- Store angles separately for clarity. ---*/
                theta    = 0;   phi    = 0;     psi    = 0;
                cosTheta = cos(theta);  cosPhi = cos(phi);      cosPsi = cos(psi);
                sinTheta = sin(theta);  sinPhi = sin(phi);      sinPsi = sin(psi);

                /*--- Compute the rotation matrix. Note that the implicit
         ordering is rotation about the x-axis, y-axis,
         then z-axis. Note that this is the transpose of the matrix
         used during the preprocessing stage. ---*/
                rotMatrix[0][0] = cosPhi*cosPsi;    rotMatrix[1][0] = sinTheta*sinPhi*cosPsi - cosTheta*sinPsi;     rotMatrix[2][0] = cosTheta*sinPhi*cosPsi + sinTheta*sinPsi;
                rotMatrix[0][1] = cosPhi*sinPsi;    rotMatrix[1][1] = sinTheta*sinPhi*sinPsi + cosTheta*cosPsi;     rotMatrix[2][1] = cosTheta*sinPhi*sinPsi - sinTheta*cosPsi;
                rotMatrix[0][2] = -sinPhi;          rotMatrix[1][2] = sinTheta*cosPhi;                              rotMatrix[2][2] = cosTheta*cosPhi;

                /*--- Copy conserved variables before performing transformation. ---*/
                for (iVar = 0; iVar < nVar; iVar++)
                    Solution[iVar] = Buffer_Receive_U[iVar*nVertexR+iVertex];

                /*--- Rotate the momentum components. ---*/
                if (nDim == 2) {
                    Solution[1] = rotMatrix[0][0]*Buffer_Receive_U[1*nVertexR+iVertex] +
                            rotMatrix[0][1]*Buffer_Receive_U[2*nVertexR+iVertex];
                    Solution[2] = rotMatrix[1][0]*Buffer_Receive_U[1*nVertexR+iVertex] +
                            rotMatrix[1][1]*Buffer_Receive_U[2*nVertexR+iVertex];
                }
                else {
                    Solution[1] = rotMatrix[0][0]*Buffer_Receive_U[1*nVertexR+iVertex] +
                            rotMatrix[0][1]*Buffer_Receive_U[2*nVertexR+iVertex] +
                            rotMatrix[0][2]*Buffer_Receive_U[3*nVertexR+iVertex];
                    Solution[2] = rotMatrix[1][0]*Buffer_Receive_U[1*nVertexR+iVertex] +
                            rotMatrix[1][1]*Buffer_Receive_U[2*nVertexR+iVertex] +
                            rotMatrix[1][2]*Buffer_Receive_U[3*nVertexR+iVertex];
                    Solution[3] = rotMatrix[2][0]*Buffer_Receive_U[1*nVertexR+iVertex] +
                            rotMatrix[2][1]*Buffer_Receive_U[2*nVertexR+iVertex] +
                            rotMatrix[2][2]*Buffer_Receive_U[3*nVertexR+iVertex];
                }

                /*--- Copy transformed conserved variables back into buffer. ---*/
                for (iVar = 0; iVar < nVar; iVar++)
                    elem[iPoint]->SetSolution_Old(iVar, Solution[iVar]);

            }

            /*--- Deallocate receive buffer ---*/
            delete [] Buffer_Receive_U;

        }

    }
}

void CEulerSolver::Set_MPI_Undivided_Laplacian(CGeometry *geometry, CConfig *config) {
    unsigned short iVar, iMarker, iPeriodic_Index, MarkerS, MarkerR;
    unsigned long iVertex, iPoint, nVertexS, nVertexR, nBufferS_Vector, nBufferR_Vector;
    double rotMatrix[3][3], *angles, theta, cosTheta, sinTheta, phi, cosPhi, sinPhi, psi, cosPsi, sinPsi,
            *Buffer_Receive_Undivided_Laplacian = NULL, *Buffer_Send_Undivided_Laplacian = NULL;

#ifdef HAVE_MPI
    int send_to, receive_from;
    MPI_Status status;
#endif

    for (iMarker = 0; iMarker < nMarker; iMarker++) {

        if ((config->GetMarker_All_KindBC(iMarker) == SEND_RECEIVE) &&
                (config->GetMarker_All_SendRecv(iMarker) > 0)) {

            MarkerS = iMarker;  MarkerR = iMarker+1;

#ifdef HAVE_MPI
            send_to = config->GetMarker_All_SendRecv(MarkerS)-1;
            receive_from = abs(config->GetMarker_All_SendRecv(MarkerR))-1;
#endif

            nVertexS = geometry->nElem_Bound[MarkerS];  nVertexR = geometry->nElem_Bound[MarkerR];
            nBufferS_Vector = nVertexS*nVar;        nBufferR_Vector = nVertexR*nVar;

            /*--- Allocate Receive and send buffers  ---*/
            Buffer_Receive_Undivided_Laplacian = new double [nBufferR_Vector];
            Buffer_Send_Undivided_Laplacian = new double[nBufferS_Vector];
            /*--- Copy the solution old that should be sended ---*/
            for (iVertex = 0; iVertex < nVertexS; iVertex++) {
                iPoint = geometry->bound[MarkerS][iVertex]->GetBound_Element();
                for (iVar = 0; iVar < nVar; iVar++){
                    Buffer_Send_Undivided_Laplacian[iVar*nVertexS+iVertex] = elem[iPoint]->GetUndivided_Laplacian(iVar);
                }
            }

#ifdef HAVE_MPI

            /*--- Send/Receive information using Sendrecv ---*/
            MPI_Sendrecv(Buffer_Send_Undivided_Laplacian, nBufferS_Vector, MPI_DOUBLE, send_to, 0,
                         Buffer_Receive_Undivided_Laplacian, nBufferR_Vector, MPI_DOUBLE, receive_from, 0, MPI_COMM_WORLD, &status);

#else

            /*--- Receive information without MPI ---*/
            for (iVertex = 0; iVertex < nVertexR; iVertex++) {
                for (iVar = 0; iVar < nVar; iVar++)
                    Buffer_Receive_Undivided_Laplacian[iVar*nVertexR+iVertex] = Buffer_Send_Undivided_Laplacian[iVar*nVertexR+iVertex];
            }

#endif

            /*--- Deallocate send buffer ---*/
            delete [] Buffer_Send_Undivided_Laplacian;

            /*--- Do the coordinate transformation ---*/
            for (iVertex = 0; iVertex < nVertexR; iVertex++) {

                /*--- Find point and its type of transformation ---*/
                iPoint = geometry->bound[MarkerR][iVertex]->GetBound_Element();

                /*--- Store angles separately for clarity. ---*/

                theta    = 0;   phi    = 0;     psi    = 0;
                cosTheta = cos(theta);  cosPhi = cos(phi);      cosPsi = cos(psi);
                sinTheta = sin(theta);  sinPhi = sin(phi);      sinPsi = sin(psi);

                rotMatrix[0][0] = cosPhi*cosPsi;    rotMatrix[1][0] = sinTheta*sinPhi*cosPsi - cosTheta*sinPsi;     rotMatrix[2][0] = cosTheta*sinPhi*cosPsi + sinTheta*sinPsi;
                rotMatrix[0][1] = cosPhi*sinPsi;    rotMatrix[1][1] = sinTheta*sinPhi*sinPsi + cosTheta*cosPsi;     rotMatrix[2][1] = cosTheta*sinPhi*sinPsi - sinTheta*cosPsi;
                rotMatrix[0][2] = -sinPhi;          rotMatrix[1][2] = sinTheta*cosPhi;                              rotMatrix[2][2] = cosTheta*cosPhi;

                /*--- Copy conserved variables before performing transformation. ---*/
                for (iVar = 0; iVar < nVar; iVar++)
                    Solution[iVar] = Buffer_Receive_Undivided_Laplacian[iVar*nVertexR+iVertex];
                /*--- Rotate the momentum components. ---*/
                if (nDim == 2) {
                    Solution[1] = rotMatrix[0][0]*Buffer_Receive_Undivided_Laplacian[1*nVertexR+iVertex] +
                            rotMatrix[0][1]*Buffer_Receive_Undivided_Laplacian[2*nVertexR+iVertex];
                    Solution[2] = rotMatrix[1][0]*Buffer_Receive_Undivided_Laplacian[1*nVertexR+iVertex] +
                            rotMatrix[1][1]*Buffer_Receive_Undivided_Laplacian[2*nVertexR+iVertex];
                }
                else {
                    Solution[1] = rotMatrix[0][0]*Buffer_Receive_Undivided_Laplacian[1*nVertexR+iVertex] +
                            rotMatrix[0][1]*Buffer_Receive_Undivided_Laplacian[2*nVertexR+iVertex] +
                            rotMatrix[0][2]*Buffer_Receive_Undivided_Laplacian[3*nVertexR+iVertex];
                    Solution[2] = rotMatrix[1][0]*Buffer_Receive_Undivided_Laplacian[1*nVertexR+iVertex] +
                            rotMatrix[1][1]*Buffer_Receive_Undivided_Laplacian[2*nVertexR+iVertex] +
                            rotMatrix[1][2]*Buffer_Receive_Undivided_Laplacian[3*nVertexR+iVertex];
                    Solution[3] = rotMatrix[2][0]*Buffer_Receive_Undivided_Laplacian[1*nVertexR+iVertex] +
                            rotMatrix[2][1]*Buffer_Receive_Undivided_Laplacian[2*nVertexR+iVertex] +
                            rotMatrix[2][2]*Buffer_Receive_Undivided_Laplacian[3*nVertexR+iVertex];
                }

                /*--- Copy transformed conserved variables back into buffer. ---*/
                for (iVar = 0; iVar < nVar; iVar++)
                    elem[iPoint]->SetUndivided_Laplacian(iVar, Solution[iVar]);
            }

            /*--- Deallocate receive buffer ---*/
            delete [] Buffer_Receive_Undivided_Laplacian;

        }

    }
}

void CEulerSolver::Set_MPI_MaxEigenvalue(CGeometry *geometry, CConfig *config) {
    unsigned short iMarker, MarkerS, MarkerR, *Buffer_Receive_Neighbor = NULL, *Buffer_Send_Neighbor = NULL;
    unsigned long iVertex, iPoint, nVertexS, nVertexR, nBufferS_Vector, nBufferR_Vector;
    double *Buffer_Receive_Lambda = NULL, *Buffer_Send_Lambda = NULL;

#ifdef HAVE_MPI
    int send_to, receive_from;
    MPI_Status status;
#endif

    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        if ((config->GetMarker_All_KindBC(iMarker) == SEND_RECEIVE) &&
                (config->GetMarker_All_SendRecv(iMarker) > 0)) {

            MarkerS = iMarker;  MarkerR = iMarker+1;

#ifdef HAVE_MPI
            send_to = config->GetMarker_All_SendRecv(MarkerS)-1;
            receive_from = abs(config->GetMarker_All_SendRecv(MarkerR))-1;
#endif

            nVertexS = geometry->nElem_Bound[MarkerS];  nVertexR = geometry->nElem_Bound[MarkerR];
            nBufferS_Vector = nVertexS;        nBufferR_Vector = nVertexR;

            /*--- Allocate Receive and send buffers  ---*/
            Buffer_Receive_Lambda = new double [nBufferR_Vector];
            Buffer_Send_Lambda = new double[nBufferS_Vector];
            Buffer_Receive_Neighbor = new unsigned short [nBufferR_Vector];
            Buffer_Send_Neighbor = new unsigned short[nBufferS_Vector];

            /*--- Copy the solution old that should be sended ---*/
            for (iVertex = 0; iVertex < nVertexS; iVertex++) {
                iPoint = geometry->bound[MarkerS][iVertex]->GetBound_Element();
                Buffer_Send_Lambda[iVertex] = elem[iPoint]->GetLambda();
                Buffer_Send_Neighbor[iVertex] = geometry->elem[iPoint]->GetnNeighbor_Cell(); //GetnPoint->GetnNeighbor_Cell
            }

#ifdef HAVE_MPI

            /*--- Send/Receive information using Sendrecv ---*/
            MPI_Sendrecv(Buffer_Send_Lambda, nBufferS_Vector, MPI_DOUBLE, send_to, 0,
                         Buffer_Receive_Lambda, nBufferR_Vector, MPI_DOUBLE, receive_from, 0, MPI_COMM_WORLD, &status);
            MPI_Sendrecv(Buffer_Send_Neighbor, nBufferS_Vector, MPI_UNSIGNED_SHORT, send_to, 1,
                         Buffer_Receive_Neighbor, nBufferR_Vector, MPI_UNSIGNED_SHORT, receive_from, 1, MPI_COMM_WORLD, &status);

#else

            /*--- Receive information without MPI ---*/
            for (iVertex = 0; iVertex < nVertexR; iVertex++) {
                Buffer_Receive_Lambda[iVertex] = Buffer_Send_Lambda[iVertex];
                Buffer_Receive_Neighbor[iVertex] = Buffer_Send_Neighbor[iVertex];
            }

#endif

            /*--- Deallocate send buffer ---*/
            delete [] Buffer_Send_Lambda;
            delete [] Buffer_Send_Neighbor;

            /*--- Do the coordinate transformation ---*/
            for (iVertex = 0; iVertex < nVertexR; iVertex++) {

                /*--- Find point and its type of transformation ---*/
                iPoint = geometry->bound[MarkerR][iVertex]->GetBound_Element();
                elem[iPoint]->SetLambda(Buffer_Receive_Lambda[iVertex]);
                geometry->elem[iPoint]->SetnNeighbor_Cell(Buffer_Receive_Neighbor[iVertex]); //SetnNeighbor-> SetnNeighbor_Cell

            }

            /*--- Deallocate receive buffer ---*/
            delete [] Buffer_Receive_Lambda;
            delete [] Buffer_Receive_Neighbor;

        }

    }
}

void CEulerSolver::Set_MPI_Sensor(CGeometry *geometry, CConfig *config) {
    unsigned short iMarker, MarkerS, MarkerR;
    unsigned long iVertex, iPoint, nVertexS, nVertexR, nBufferS_Vector, nBufferR_Vector;
    double *Buffer_Receive_Lambda = NULL, *Buffer_Send_Lambda = NULL;

#ifdef HAVE_MPI
    int send_to, receive_from;
    MPI_Status status;
#endif

    for (iMarker = 0; iMarker < nMarker; iMarker++) {

        if ((config->GetMarker_All_KindBC(iMarker) == SEND_RECEIVE) &&
                (config->GetMarker_All_SendRecv(iMarker) > 0)) {

            MarkerS = iMarker;  MarkerR = iMarker+1;

#ifdef HAVE_MPI
            send_to = config->GetMarker_All_SendRecv(MarkerS)-1;
            receive_from = abs(config->GetMarker_All_SendRecv(MarkerR))-1;
#endif

            nVertexS = geometry->nElem_Bound[MarkerS];  nVertexR = geometry->nElem_Bound[MarkerR];
            nBufferS_Vector = nVertexS;        nBufferR_Vector = nVertexR;

            /*--- Allocate Receive and send buffers  ---*/
            Buffer_Receive_Lambda = new double [nBufferR_Vector];
            Buffer_Send_Lambda = new double[nBufferS_Vector];

            /*--- Copy the solution old that should be sended ---*/
            for (iVertex = 0; iVertex < nVertexS; iVertex++) {
                iPoint = geometry->bound[MarkerS][iVertex]->GetBound_Element();
                Buffer_Send_Lambda[iVertex] = elem[iPoint]->GetSensor();
            }

#ifdef HAVE_MPI

            /*--- Send/Receive information using Sendrecv ---*/
            MPI_Sendrecv(Buffer_Send_Lambda, nBufferS_Vector, MPI_DOUBLE, send_to, 0,
                         Buffer_Receive_Lambda, nBufferR_Vector, MPI_DOUBLE, receive_from, 0, MPI_COMM_WORLD, &status);

#else

            /*--- Receive information without MPI ---*/
            for (iVertex = 0; iVertex < nVertexR; iVertex++) {
                Buffer_Receive_Lambda[iVertex] = Buffer_Send_Lambda[iVertex];
            }

#endif

            /*--- Deallocate send buffer ---*/
            delete [] Buffer_Send_Lambda;

            /*--- Do the coordinate transformation ---*/
            for (iVertex = 0; iVertex < nVertexR; iVertex++) {

                /*--- Find point and its type of transformation ---*/
                iPoint = geometry->bound[MarkerR][iVertex]->GetBound_Element();
                elem[iPoint]->SetSensor(Buffer_Receive_Lambda[iVertex]);

            }

            /*--- Deallocate receive buffer ---*/
            delete [] Buffer_Receive_Lambda;

        }

    }
}


void CEulerSolver::Set_MPI_Solution_Gradient(CGeometry *geometry, CConfig *config) {
    unsigned short iVar, iDim, iMarker, iPeriodic_Index, MarkerS, MarkerR;
    unsigned long iVertex, iPoint, nVertexS, nVertexR, nBufferS_Vector, nBufferR_Vector;
    double rotMatrix[3][3], *angles, theta, cosTheta, sinTheta, phi, cosPhi, sinPhi, psi, cosPsi, sinPsi,
            *Buffer_Receive_Gradient = NULL, *Buffer_Send_Gradient = NULL;

    double **Gradient = new double* [nVar];
    for (iVar = 0; iVar < nVar; iVar++)
        Gradient[iVar] = new double[nDim];

#ifdef HAVE_MPI
    int send_to, receive_from;
    MPI_Status status;
#endif

    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        if ((config->GetMarker_All_KindBC(iMarker) == SEND_RECEIVE) &&
                (config->GetMarker_All_SendRecv(iMarker) > 0)) {

            MarkerS = iMarker;  MarkerR = iMarker+1;

#ifdef HAVE_MPI
            send_to = config->GetMarker_All_SendRecv(MarkerS)-1;
            receive_from = abs(config->GetMarker_All_SendRecv(MarkerR))-1;
#endif

            nVertexS = geometry->nElem_Bound[MarkerS];  nVertexR = geometry->nElem_Bound[MarkerR];
            nBufferS_Vector = nVertexS*nVar*nDim;        nBufferR_Vector = nVertexR*nVar*nDim;

            /*--- Allocate Receive and send buffers  ---*/
            Buffer_Receive_Gradient = new double [nBufferR_Vector];
            Buffer_Send_Gradient = new double[nBufferS_Vector];

            /*--- Copy the solution old that should be sended ---*/
            for (iVertex = 0; iVertex < nVertexS; iVertex++) {
                iPoint = geometry->bound[MarkerS][iVertex]->GetBound_Element();
                for (iVar = 0; iVar < nVar; iVar++)
                    for (iDim = 0; iDim < nDim; iDim++)
                        Buffer_Send_Gradient[iDim*nVar*nVertexS+iVar*nVertexS+iVertex] = elem[iPoint]->GetGradient(iVar, iDim);
            }

#ifdef HAVE_MPI

            /*--- Send/Receive information using Sendrecv ---*/
            MPI_Sendrecv(Buffer_Send_Gradient, nBufferS_Vector, MPI_DOUBLE, send_to, 0,
                         Buffer_Receive_Gradient, nBufferR_Vector, MPI_DOUBLE, receive_from, 0, MPI_COMM_WORLD, &status);

#else

            /*--- Receive information without MPI ---*/
            for (iVertex = 0; iVertex < nVertexR; iVertex++) {
                for (iVar = 0; iVar < nVar; iVar++)
                    for (iDim = 0; iDim < nDim; iDim++)
                        Buffer_Receive_Gradient[iDim*nVar*nVertexR+iVar*nVertexR+iVertex] = Buffer_Send_Gradient[iDim*nVar*nVertexR+iVar*nVertexR+iVertex];
            }

#endif

            /*--- Deallocate send buffer ---*/
            delete [] Buffer_Send_Gradient;

            /*--- Do the coordinate transformation ---*/
            for (iVertex = 0; iVertex < nVertexR; iVertex++) {

                /*--- Find point and its type of transformation ---*/
                iPoint = geometry->bound[MarkerR][iVertex]->GetBound_Element();

                /*--- Store angles separately for clarity. ---*/
                theta    = 0;   phi    = 0;     psi    = 0;
                cosTheta = cos(theta);  cosPhi = cos(phi);      cosPsi = cos(psi);
                sinTheta = sin(theta);  sinPhi = sin(phi);      sinPsi = sin(psi);

                /*--- Compute the rotation matrix. ---*/
                rotMatrix[0][0] = cosPhi*cosPsi;    rotMatrix[1][0] = sinTheta*sinPhi*cosPsi - cosTheta*sinPsi;     rotMatrix[2][0] = cosTheta*sinPhi*cosPsi + sinTheta*sinPsi;
                rotMatrix[0][1] = cosPhi*sinPsi;    rotMatrix[1][1] = sinTheta*sinPhi*sinPsi + cosTheta*cosPsi;     rotMatrix[2][1] = cosTheta*sinPhi*sinPsi - sinTheta*cosPsi;
                rotMatrix[0][2] = -sinPhi;          rotMatrix[1][2] = sinTheta*cosPhi;                              rotMatrix[2][2] = cosTheta*cosPhi;

                /*--- Copy conserved variables before performing transformation. ---*/
                for (iVar = 0; iVar < nVar; iVar++)
                    for (iDim = 0; iDim < nDim; iDim++)
                        Gradient[iVar][iDim] = Buffer_Receive_Gradient[iDim*nVar*nVertexR+iVar*nVertexR+iVertex];

                /*--- Need to rotate the gradients for all conserved variables. ---*/
                for (iVar = 0; iVar < nVar; iVar++) {
                    if (nDim == 2) {
                        Gradient[iVar][0] = rotMatrix[0][0]*Buffer_Receive_Gradient[0*nVar*nVertexR+iVar*nVertexR+iVertex] + rotMatrix[0][1]*Buffer_Receive_Gradient[1*nVar*nVertexR+iVar*nVertexR+iVertex];
                        Gradient[iVar][1] = rotMatrix[1][0]*Buffer_Receive_Gradient[0*nVar*nVertexR+iVar*nVertexR+iVertex] + rotMatrix[1][1]*Buffer_Receive_Gradient[1*nVar*nVertexR+iVar*nVertexR+iVertex];
                    }
                    else {
                        Gradient[iVar][0] = rotMatrix[0][0]*Buffer_Receive_Gradient[0*nVar*nVertexR+iVar*nVertexR+iVertex] + rotMatrix[0][1]*Buffer_Receive_Gradient[1*nVar*nVertexR+iVar*nVertexR+iVertex] + rotMatrix[0][2]*Buffer_Receive_Gradient[2*nVar*nVertexR+iVar*nVertexR+iVertex];
                        Gradient[iVar][1] = rotMatrix[1][0]*Buffer_Receive_Gradient[0*nVar*nVertexR+iVar*nVertexR+iVertex] + rotMatrix[1][1]*Buffer_Receive_Gradient[1*nVar*nVertexR+iVar*nVertexR+iVertex] + rotMatrix[1][2]*Buffer_Receive_Gradient[2*nVar*nVertexR+iVar*nVertexR+iVertex];
                        Gradient[iVar][2] = rotMatrix[2][0]*Buffer_Receive_Gradient[0*nVar*nVertexR+iVar*nVertexR+iVertex] + rotMatrix[2][1]*Buffer_Receive_Gradient[1*nVar*nVertexR+iVar*nVertexR+iVertex] + rotMatrix[2][2]*Buffer_Receive_Gradient[2*nVar*nVertexR+iVar*nVertexR+iVertex];
                    }
                }

                /*--- Store the received information ---*/
                for (iVar = 0; iVar < nVar; iVar++)
                    for (iDim = 0; iDim < nDim; iDim++)
                        elem[iPoint]->SetGradient(iVar, iDim, Gradient[iVar][iDim]);

            }

            /*--- Deallocate receive buffer ---*/
            delete [] Buffer_Receive_Gradient;

        }

    }

    for (iVar = 0; iVar < nVar; iVar++)
        delete [] Gradient[iVar];
    delete [] Gradient;

}

void CEulerSolver::Set_MPI_Solution_Limiter(CGeometry *geometry, CConfig *config) {
    unsigned short iVar, iMarker, iPeriodic_Index, MarkerS, MarkerR;
    unsigned long iVertex, iPoint, nVertexS, nVertexR, nBufferS_Vector, nBufferR_Vector;
    double rotMatrix[3][3], *angles, theta, cosTheta, sinTheta, phi, cosPhi, sinPhi, psi, cosPsi, sinPsi,
            *Buffer_Receive_Limit = NULL, *Buffer_Send_Limit = NULL;

    double *Limiter = new double [nVar];

#ifdef HAVE_MPI
    int send_to, receive_from;
    MPI_Status status;
#endif

    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        if ((config->GetMarker_All_KindBC(iMarker) == SEND_RECEIVE) &&
                (config->GetMarker_All_SendRecv(iMarker) > 0)) {

            MarkerS = iMarker;  MarkerR = iMarker+1;

#ifdef HAVE_MPI
            send_to = config->GetMarker_All_SendRecv(MarkerS)-1;
            receive_from = abs(config->GetMarker_All_SendRecv(MarkerR))-1;
#endif

            nVertexS = geometry->nElem_Bound[MarkerS];  nVertexR = geometry->nElem_Bound[MarkerR];
            nBufferS_Vector = nVertexS*nVar;        nBufferR_Vector = nVertexR*nVar;

            /*--- Allocate Receive and send buffers  ---*/
            Buffer_Receive_Limit = new double [nBufferR_Vector];
            Buffer_Send_Limit = new double[nBufferS_Vector];

            /*--- Copy the solution old that should be sended ---*/
            for (iVertex = 0; iVertex < nVertexS; iVertex++) {
                iPoint = geometry->bound[MarkerS][iVertex]->GetBound_Element();
                for (iVar = 0; iVar < nVar; iVar++)
                    Buffer_Send_Limit[iVar*nVertexS+iVertex] = elem[iPoint]->GetLimiter(iVar);
            }

#ifdef HAVE_MPI

            /*--- Send/Receive information using Sendrecv ---*/
            MPI_Sendrecv(Buffer_Send_Limit, nBufferS_Vector, MPI_DOUBLE, send_to, 0,
                         Buffer_Receive_Limit, nBufferR_Vector, MPI_DOUBLE, receive_from, 0, MPI_COMM_WORLD, &status);

#else

            /*--- Receive information without MPI ---*/
            for (iVertex = 0; iVertex < nVertexR; iVertex++) {
                for (iVar = 0; iVar < nVar; iVar++)
                    Buffer_Receive_Limit[iVar*nVertexR+iVertex] = Buffer_Send_Limit[iVar*nVertexR+iVertex];
            }

#endif

            /*--- Deallocate send buffer ---*/
            delete [] Buffer_Send_Limit;

            /*--- Do the coordinate transformation ---*/
            for (iVertex = 0; iVertex < nVertexR; iVertex++) {

                /*--- Find point and its type of transformation ---*/
                iPoint = geometry->bound[MarkerR][iVertex]->GetBound_Element();

                /*--- Store angles separately for clarity. ---*/
                theta    = 0;   phi    = 0;     psi    = 0;
                cosTheta = cos(theta);  cosPhi = cos(phi);      cosPsi = cos(psi);
                sinTheta = sin(theta);  sinPhi = sin(phi);      sinPsi = sin(psi);

                /*--- Compute the rotation matrix. ---*/
                rotMatrix[0][0] = cosPhi*cosPsi;    rotMatrix[1][0] = sinTheta*sinPhi*cosPsi - cosTheta*sinPsi;     rotMatrix[2][0] = cosTheta*sinPhi*cosPsi + sinTheta*sinPsi;
                rotMatrix[0][1] = cosPhi*sinPsi;    rotMatrix[1][1] = sinTheta*sinPhi*sinPsi + cosTheta*cosPsi;     rotMatrix[2][1] = cosTheta*sinPhi*sinPsi - sinTheta*cosPsi;
                rotMatrix[0][2] = -sinPhi;          rotMatrix[1][2] = sinTheta*cosPhi;                              rotMatrix[2][2] = cosTheta*cosPhi;

                /*--- Copy conserved variables before performing transformation. ---*/
                for (iVar = 0; iVar < nVar; iVar++)
                    Limiter[iVar] = Buffer_Receive_Limit[iVar*nVertexR+iVertex];

                /*--- Rotate the momentum components. ---*/
                if (nDim == 2) {
                    Limiter[1] = rotMatrix[0][0]*Buffer_Receive_Limit[1*nVertexR+iVertex] +
                            rotMatrix[0][1]*Buffer_Receive_Limit[2*nVertexR+iVertex];
                    Limiter[2] = rotMatrix[1][0]*Buffer_Receive_Limit[1*nVertexR+iVertex] +
                            rotMatrix[1][1]*Buffer_Receive_Limit[2*nVertexR+iVertex];
                }
                else {
                    Limiter[1] = rotMatrix[0][0]*Buffer_Receive_Limit[1*nVertexR+iVertex] +
                            rotMatrix[0][1]*Buffer_Receive_Limit[2*nVertexR+iVertex] +
                            rotMatrix[0][2]*Buffer_Receive_Limit[3*nVertexR+iVertex];
                    Limiter[2] = rotMatrix[1][0]*Buffer_Receive_Limit[1*nVertexR+iVertex] +
                            rotMatrix[1][1]*Buffer_Receive_Limit[2*nVertexR+iVertex] +
                            rotMatrix[1][2]*Buffer_Receive_Limit[3*nVertexR+iVertex];
                    Limiter[3] = rotMatrix[2][0]*Buffer_Receive_Limit[1*nVertexR+iVertex] +
                            rotMatrix[2][1]*Buffer_Receive_Limit[2*nVertexR+iVertex] +
                            rotMatrix[2][2]*Buffer_Receive_Limit[3*nVertexR+iVertex];
                }

                /*--- Copy transformed conserved variables back into buffer. ---*/
                for (iVar = 0; iVar < nVar; iVar++)
                    elem[iPoint]->SetLimiter(iVar, Limiter[iVar]);

            }

            /*--- Deallocate receive buffer ---*/
            delete [] Buffer_Receive_Limit;

        }

    }

    delete [] Limiter;

}

void CEulerSolver::Set_MPI_Primitive_Gradient(CGeometry *geometry, CConfig *config) {
    unsigned short iVar, iDim, iMarker, iPeriodic_Index, MarkerS, MarkerR;
    unsigned long iVertex, iPoint, nVertexS, nVertexR, nBufferS_Vector, nBufferR_Vector;
    double rotMatrix[3][3], *angles, theta, cosTheta, sinTheta, phi, cosPhi, sinPhi, psi, cosPsi, sinPsi,
            *Buffer_Receive_Gradient = NULL, *Buffer_Send_Gradient = NULL;

    double **Gradient = new double* [nPrimVarGrad];
    for (iVar = 0; iVar < nPrimVarGrad; iVar++)
        Gradient[iVar] = new double[nDim];

#ifdef HAVE_MPI
    int send_to, receive_from;
    MPI_Status status;
#endif

    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        if ((config->GetMarker_All_KindBC(iMarker) == SEND_RECEIVE) &&
                (config->GetMarker_All_SendRecv(iMarker) > 0)) {

            MarkerS = iMarker;  MarkerR = iMarker+1;

#ifdef HAVE_MPI
            send_to = config->GetMarker_All_SendRecv(MarkerS)-1;
            receive_from = abs(config->GetMarker_All_SendRecv(MarkerR))-1;
#endif

            nVertexS = geometry->nElem_Bound[MarkerS];  nVertexR = geometry->nElem_Bound[MarkerR];
            nBufferS_Vector = nVertexS*nPrimVarGrad*nDim;        nBufferR_Vector = nVertexR*nPrimVarGrad*nDim;

            Buffer_Receive_Gradient = new double [nBufferR_Vector];
            Buffer_Send_Gradient = new double[nBufferS_Vector];

            for (iVertex = 0; iVertex < nVertexS; iVertex++) {
                iPoint = geometry->bound[MarkerS][iVertex]->GetBound_Element();
                for (iVar = 0; iVar < nPrimVarGrad; iVar++)
                    for (iDim = 0; iDim < nDim; iDim++)
                        Buffer_Send_Gradient[iDim*nPrimVarGrad*nVertexS+iVar*nVertexS+iVertex] = elem[iPoint]->GetGradient_Primitive(iVar, iDim);
            }

#ifdef HAVE_MPI

            MPI_Sendrecv(Buffer_Send_Gradient, nBufferS_Vector, MPI_DOUBLE, send_to, 0,
                         Buffer_Receive_Gradient, nBufferR_Vector, MPI_DOUBLE, receive_from, 0, MPI_COMM_WORLD, &status);

#else

            for (iVertex = 0; iVertex < nVertexR; iVertex++) {
                for (iVar = 0; iVar < nPrimVarGrad; iVar++)
                    for (iDim = 0; iDim < nDim; iDim++)
                        Buffer_Receive_Gradient[iDim*nPrimVarGrad*nVertexR+iVar*nVertexR+iVertex] = Buffer_Send_Gradient[iDim*nPrimVarGrad*nVertexR+iVar*nVertexR+iVertex];
            }

#endif

            delete [] Buffer_Send_Gradient;

            for (iVertex = 0; iVertex < nVertexR; iVertex++) {

                iPoint = geometry->bound[MarkerR][iVertex]->GetBound_Element();

                theta    = 0;   phi    = 0;     psi    = 0;
                cosTheta = cos(theta);  cosPhi = cos(phi);      cosPsi = cos(psi);
                sinTheta = sin(theta);  sinPhi = sin(phi);      sinPsi = sin(psi);

                rotMatrix[0][0] = cosPhi*cosPsi;    rotMatrix[1][0] = sinTheta*sinPhi*cosPsi - cosTheta*sinPsi;     rotMatrix[2][0] = cosTheta*sinPhi*cosPsi + sinTheta*sinPsi;
                rotMatrix[0][1] = cosPhi*sinPsi;    rotMatrix[1][1] = sinTheta*sinPhi*sinPsi + cosTheta*cosPsi;     rotMatrix[2][1] = cosTheta*sinPhi*sinPsi - sinTheta*cosPsi;
                rotMatrix[0][2] = -sinPhi;          rotMatrix[1][2] = sinTheta*cosPhi;                              rotMatrix[2][2] = cosTheta*cosPhi;

                for (iVar = 0; iVar < nPrimVarGrad; iVar++)
                    for (iDim = 0; iDim < nDim; iDim++)
                        Gradient[iVar][iDim] = Buffer_Receive_Gradient[iDim*nPrimVarGrad*nVertexR+iVar*nVertexR+iVertex];

                for (iVar = 0; iVar < nPrimVarGrad; iVar++) {
                    if (nDim == 2) {
                        Gradient[iVar][0] = rotMatrix[0][0]*Buffer_Receive_Gradient[0*nPrimVarGrad*nVertexR+iVar*nVertexR+iVertex] + rotMatrix[0][1]*Buffer_Receive_Gradient[1*nPrimVarGrad*nVertexR+iVar*nVertexR+iVertex];
                        Gradient[iVar][1] = rotMatrix[1][0]*Buffer_Receive_Gradient[0*nPrimVarGrad*nVertexR+iVar*nVertexR+iVertex] + rotMatrix[1][1]*Buffer_Receive_Gradient[1*nPrimVarGrad*nVertexR+iVar*nVertexR+iVertex];
                    }
                    else {
                        Gradient[iVar][0] = rotMatrix[0][0]*Buffer_Receive_Gradient[0*nPrimVarGrad*nVertexR+iVar*nVertexR+iVertex] + rotMatrix[0][1]*Buffer_Receive_Gradient[1*nPrimVarGrad*nVertexR+iVar*nVertexR+iVertex] + rotMatrix[0][2]*Buffer_Receive_Gradient[2*nPrimVarGrad*nVertexR+iVar*nVertexR+iVertex];
                        Gradient[iVar][1] = rotMatrix[1][0]*Buffer_Receive_Gradient[0*nPrimVarGrad*nVertexR+iVar*nVertexR+iVertex] + rotMatrix[1][1]*Buffer_Receive_Gradient[1*nPrimVarGrad*nVertexR+iVar*nVertexR+iVertex] + rotMatrix[1][2]*Buffer_Receive_Gradient[2*nPrimVarGrad*nVertexR+iVar*nVertexR+iVertex];
                        Gradient[iVar][2] = rotMatrix[2][0]*Buffer_Receive_Gradient[0*nPrimVarGrad*nVertexR+iVar*nVertexR+iVertex] + rotMatrix[2][1]*Buffer_Receive_Gradient[1*nPrimVarGrad*nVertexR+iVar*nVertexR+iVertex] + rotMatrix[2][2]*Buffer_Receive_Gradient[2*nPrimVarGrad*nVertexR+iVar*nVertexR+iVertex];
                    }
                }

                for (iVar = 0; iVar < nPrimVarGrad; iVar++)
                    for (iDim = 0; iDim < nDim; iDim++)
                        elem[iPoint]->SetGradient_Primitive(iVar, iDim, Gradient[iVar][iDim]); //cout<<iPoint<<"    Gradient     "<<Gradient[iVar][iDim]<<endl;}}

            }

            delete [] Buffer_Receive_Gradient;

        }

    }

    for (iVar = 0; iVar < nPrimVarGrad; iVar++)
        delete [] Gradient[iVar];
    delete [] Gradient;

}

void CEulerSolver::Set_MPI_Primitive_Limiter(CGeometry *geometry, CConfig *config) {
    unsigned short iVar, iMarker, iPeriodic_Index, MarkerS, MarkerR;
    unsigned long iVertex, iPoint, nVertexS, nVertexR, nBufferS_Vector, nBufferR_Vector;
    double rotMatrix[3][3], *angles, theta, cosTheta, sinTheta, phi, cosPhi, sinPhi, psi, cosPsi, sinPsi,
            *Buffer_Receive_Limit = NULL, *Buffer_Send_Limit = NULL;

    double *Limiter = new double [nPrimVarGrad];
    double *LimiterIt = Limiter;

#ifdef HAVE_MPI
    int send_to, receive_from;
    MPI_Status status;
#endif

    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        if ((config->GetMarker_All_KindBC(iMarker) == SEND_RECEIVE) &&
                (config->GetMarker_All_SendRecv(iMarker) > 0)) {

            MarkerS = iMarker;  MarkerR = iMarker+1;

#ifdef HAVE_MPI
            send_to = config->GetMarker_All_SendRecv(MarkerS)-1;
            receive_from = abs(config->GetMarker_All_SendRecv(MarkerR))-1;
#endif

            nVertexS = geometry->nElem_Bound[MarkerS];  nVertexR = geometry->nElem_Bound[MarkerR];
            nBufferS_Vector = nVertexS*nPrimVarGrad;        nBufferR_Vector = nVertexR*nPrimVarGrad;

            /*--- Allocate Receive and send buffers  ---*/
            Buffer_Receive_Limit = new double [nBufferR_Vector];
            Buffer_Send_Limit = new double[nBufferS_Vector];

            /*--- Copy the solution old that should be sended ---*/
            for (iVertex = 0; iVertex < nVertexS; iVertex++) {
                iPoint = geometry->bound[MarkerS][iVertex]->GetBound_Element();
                for (iVar = 0; iVar < nPrimVarGrad; iVar++)
                    Buffer_Send_Limit[iVar*nVertexS+iVertex] = elem[iPoint]->GetLimiter_Primitive(iVar);
            }

#ifdef HAVE_MPI

            /*--- Send/Receive information using Sendrecv ---*/
            MPI_Sendrecv(Buffer_Send_Limit, nBufferS_Vector, MPI_DOUBLE, send_to, 0,
                         Buffer_Receive_Limit, nBufferR_Vector, MPI_DOUBLE, receive_from, 0, MPI_COMM_WORLD, &status);

#else

            /*--- Receive information without MPI ---*/
            for (iVertex = 0; iVertex < nVertexR; iVertex++) {
                for (iVar = 0; iVar < nPrimVarGrad; iVar++)
                    Buffer_Receive_Limit[iVar*nVertexR+iVertex] = Buffer_Send_Limit[iVar*nVertexR+iVertex];
            }

#endif

            /*--- Deallocate send buffer ---*/
            delete [] Buffer_Send_Limit;

            /*--- Do the coordinate transformation ---*/
            for (iVertex = 0; iVertex < nVertexR; iVertex++) {

                /*--- Find point and its type of transformation ---*/
                iPoint = geometry->bound[MarkerR][iVertex]->GetBound_Element();

                /*--- Store angles separately for clarity. ---*/
                theta    = 0;   phi    = 0;     psi    = 0;
                cosTheta = cos(theta);  cosPhi = cos(phi);      cosPsi = cos(psi);
                sinTheta = sin(theta);  sinPhi = sin(phi);      sinPsi = sin(psi);

                /*--- Compute the rotation matrix.---*/
                rotMatrix[0][0] = cosPhi*cosPsi;    rotMatrix[1][0] = sinTheta*sinPhi*cosPsi - cosTheta*sinPsi;     rotMatrix[2][0] = cosTheta*sinPhi*cosPsi + sinTheta*sinPsi;
                rotMatrix[0][1] = cosPhi*sinPsi;    rotMatrix[1][1] = sinTheta*sinPhi*sinPsi + cosTheta*cosPsi;     rotMatrix[2][1] = cosTheta*sinPhi*sinPsi - sinTheta*cosPsi;
                rotMatrix[0][2] = -sinPhi;          rotMatrix[1][2] = sinTheta*cosPhi;                              rotMatrix[2][2] = cosTheta*cosPhi;

                /*--- Copy conserved variables before performing transformation. ---*/
                for (iVar = 0; iVar < nPrimVarGrad; iVar++)
                    Limiter[iVar] = Buffer_Receive_Limit[iVar*nVertexR+iVertex];

                /*--- Rotate the momentum components. ---*/
                if (nDim == 2) {
                    Limiter[1] = rotMatrix[0][0]*Buffer_Receive_Limit[1*nVertexR+iVertex] +
                            rotMatrix[0][1]*Buffer_Receive_Limit[2*nVertexR+iVertex];
                    Limiter[2] = rotMatrix[1][0]*Buffer_Receive_Limit[1*nVertexR+iVertex] +
                            rotMatrix[1][1]*Buffer_Receive_Limit[2*nVertexR+iVertex];
                }
                else {
                    Limiter[1] = rotMatrix[0][0]*Buffer_Receive_Limit[1*nVertexR+iVertex] +
                            rotMatrix[0][1]*Buffer_Receive_Limit[2*nVertexR+iVertex] +
                            rotMatrix[0][2]*Buffer_Receive_Limit[3*nVertexR+iVertex];
                    Limiter[2] = rotMatrix[1][0]*Buffer_Receive_Limit[1*nVertexR+iVertex] +
                            rotMatrix[1][1]*Buffer_Receive_Limit[2*nVertexR+iVertex] +
                            rotMatrix[1][2]*Buffer_Receive_Limit[3*nVertexR+iVertex];
                    Limiter[3] = rotMatrix[2][0]*Buffer_Receive_Limit[1*nVertexR+iVertex] +
                            rotMatrix[2][1]*Buffer_Receive_Limit[2*nVertexR+iVertex] +
                            rotMatrix[2][2]*Buffer_Receive_Limit[3*nVertexR+iVertex];
                }

                /*--- Copy transformed conserved variables back into buffer. ---*/
                for (iVar = 0; iVar < nPrimVarGrad; iVar++){
                    elem[iPoint]->SetLimiter_Primitive(iVar, Limiter[iVar]);
                }

            }

            /*--- Deallocate receive buffer ---*/
            delete [] Buffer_Receive_Limit;

        }

    }

    delete [] LimiterIt;

}

void CEulerSolver::SetNondimensionalization(CGeometry *geometry, CConfig *config, unsigned short iMesh) {

    double Temperature_FreeStream = 0.0, Mach2Vel_FreeStream = 0.0, ModVel_FreeStream = 0.0, Energy_FreeStream = 0.0, ModVel_FreeStreamND = 0.0,
            Velocity_Reynolds = 0.0, Omega_FreeStream = 0.0, Omega_FreeStreamND = 0.0, Viscosity_FreeStream = 0.0,
            Density_FreeStream = 0.0, Pressure_FreeStream = 0.0, Tke_FreeStream = 0.0;
    double Length_Ref = 0.0, Density_Ref = 0.0, Pressure_Ref = 0.0, Temperature_Ref = 0.0, Velocity_Ref = 0.0, Time_Ref = 0.0, Omega_Ref = 0.0, Force_Ref = 0.0,
            Gas_Constant_Ref = 0.0, Viscosity_Ref = 0.0, Conductivity_Ref = 0.0, Energy_Ref= 0.0, Froude = 0.0;
    double Pressure_FreeStreamND = 0.0, Density_FreeStreamND = 0.0, Temperature_FreeStreamND = 0.0, Gas_ConstantND = 0.0,
            Velocity_FreeStreamND[3] = {0.0, 0.0, 0.0}, Viscosity_FreeStreamND = 0.0, Tke_FreeStreamND = 0.0, Energy_FreeStreamND = 0.0,
            Total_UnstTimeND = 0.0, Delta_UnstTimeND = 0.0;
    unsigned short iDim;

    int rank = MASTER_NODE;
#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

    /*--- Local variables and memory allocation ---*/

    double Alpha            = config->GetAoA()*PI_NUMBER/180.0;
    double Beta             = config->GetAoS()*PI_NUMBER/180.0;
    double Mach             = config->GetMach();
    double Reynolds         = config->GetReynolds();
    bool compressible       = (config->GetKind_Regime() == COMPRESSIBLE);
    bool unsteady           = (config->GetUnsteady_Simulation() != NO);
    bool viscous            = config->GetViscous();
    bool grid_movement      = config->GetGrid_Movement();
    bool gravity            = config->GetGravityForce();
    bool turbulent          = config->GetKind_Solver() == RANS;
    bool tkeNeeded          = ((config->GetKind_Solver() == RANS) && (config->GetKind_Turb_Model() == SST));
    bool fs_temperature     = (config->GetKind_FreeStreamOption() == TEMPERATURE_FS);
    bool standard_air       = (config->GetKind_FluidModel() == STANDARD_AIR);

    if (compressible) {

        /*--- Compute the Free Stream velocity, using the Mach number ---*/

        Pressure_FreeStream = config->GetPressure_FreeStream();
        Density_FreeStream  = config->GetDensity_FreeStream();
        Temperature_FreeStream  = config->GetTemperature_FreeStream();

        switch (config->GetKind_FluidModel()) {

        case STANDARD_AIR:
            if (config->GetSystemMeasurements() == SI) config->SetGas_Constant(287.058);
            else if (config->GetSystemMeasurements() == US) config->SetGas_Constant(1716.49);

            FluidModel = new CIdealGas(1.4, config->GetGas_Constant());
            if(fs_temperature) {
                FluidModel->SetTDState_PT(Pressure_FreeStream, Temperature_FreeStream);
                Density_FreeStream = FluidModel->GetDensity();
                config->SetDensity_FreeStream(Density_FreeStream);

            }
            else {
                FluidModel->SetTDState_Prho(Pressure_FreeStream, Density_FreeStream );
                Temperature_FreeStream = FluidModel->GetTemperature();
                config->SetTemperature_FreeStream(Temperature_FreeStream);
            }
            break;

        case IDEAL_GAS:
            FluidModel = new CIdealGas(Gamma, config->GetGas_Constant());
            if(fs_temperature) {
                FluidModel->SetTDState_PT(Pressure_FreeStream, Temperature_FreeStream);
                Density_FreeStream = FluidModel->GetDensity();
                config->SetDensity_FreeStream(Density_FreeStream);
            }
            else {
                FluidModel->SetTDState_Prho(Pressure_FreeStream, Density_FreeStream );
                Temperature_FreeStream = FluidModel->GetTemperature();
                config->SetTemperature_FreeStream(Temperature_FreeStream);
            }
            break;

        case VW_GAS:
            FluidModel = new CVanDerWaalsGas(Gamma, config->GetGas_Constant(), config->GetPressure_Critical(), config->GetTemperature_Critical());
            if(fs_temperature) {
                FluidModel->SetTDState_PT(Pressure_FreeStream, Temperature_FreeStream);
                Density_FreeStream = FluidModel->GetDensity();
                config->SetDensity_FreeStream(Density_FreeStream);
            }
            else {
                FluidModel->SetTDState_Prho(Pressure_FreeStream, Density_FreeStream );
                Temperature_FreeStream = FluidModel->GetTemperature();
                config->SetTemperature_FreeStream(Temperature_FreeStream);
            }
            break;

        case PR_GAS:
            FluidModel = new CPengRobinson(Gamma, config->GetGas_Constant(), config->GetPressure_Critical(), config->GetTemperature_Critical(), config->GetAcentric_Factor());
            if(fs_temperature) {
                FluidModel->SetTDState_PT(Pressure_FreeStream, Temperature_FreeStream);
                Density_FreeStream = FluidModel->GetDensity();
                config->SetDensity_FreeStream(Density_FreeStream);
            }
            else {
                FluidModel->SetTDState_Prho(Pressure_FreeStream, Density_FreeStream );
                Temperature_FreeStream = FluidModel->GetTemperature();
                config->SetTemperature_FreeStream(Temperature_FreeStream);
            }
            break;
        }

        Mach2Vel_FreeStream = FluidModel->GetSoundSpeed();

        /*--- Compute the Free Stream velocity, using the Mach number ---*/

        if (nDim == 2) {
            config->GetVelocity_FreeStream()[0] = cos(Alpha)*Mach*Mach2Vel_FreeStream;
            config->GetVelocity_FreeStream()[1] = sin(Alpha)*Mach*Mach2Vel_FreeStream;
        }
        if (nDim == 3) {
            config->GetVelocity_FreeStream()[0] = cos(Alpha)*cos(Beta)*Mach*Mach2Vel_FreeStream;
            config->GetVelocity_FreeStream()[1] = sin(Beta)*Mach*Mach2Vel_FreeStream;
            config->GetVelocity_FreeStream()[2] = sin(Alpha)*cos(Beta)*Mach*Mach2Vel_FreeStream;
        }

        /*--- Compute the modulus of the free stream velocity ---*/

        ModVel_FreeStream = 0.0;
        for (iDim = 0; iDim < nDim; iDim++)
            ModVel_FreeStream += config->GetVelocity_FreeStream()[iDim]*config->GetVelocity_FreeStream()[iDim];
        ModVel_FreeStream = sqrt(ModVel_FreeStream); config->SetModVel_FreeStream(ModVel_FreeStream);

        if (viscous) {

            if (config->GetKind_InitOption()== REYNOLDS) {

                /*--- First, check if there is mesh motion. If yes, use the Mach
         number relative to the body to initialize the flow. ---*/

                if (grid_movement) Velocity_Reynolds = config->GetMach_Motion()*Mach2Vel_FreeStream;
                else Velocity_Reynolds = ModVel_FreeStream;

                /*--- Change of measurement system, hard coded value working only with STANDAR AIR model ---*/

                if (standard_air){
                    if (config->GetSystemMeasurements() == SI) {
                        config->SetMu_RefND(1.716E-5);
                        config->SetMu_SND(110.4);
                        config->SetMu_Temperature_RefND(273.15);
                    }
                    if (config->GetSystemMeasurements() == US) {
                        config->SetMu_RefND(3.62E-7);
                        config->SetMu_SND(198.72);
                        config->SetMu_Temperature_RefND(518.7);
                    }
                }

                /*--- For viscous flows, pressure will be computed from a density
         that is found from the Reynolds number. The viscosity is computed
         from the dimensional version of Sutherland's law ---*/
                FluidModel->SetLaminarViscosityModel(config);

                Viscosity_FreeStream = FluidModel->GetLaminarViscosity();
                config->SetViscosity_FreeStream(Viscosity_FreeStream);

                Density_FreeStream   = Reynolds*Viscosity_FreeStream/(Velocity_Reynolds*config->GetLength_Reynolds());
                config->SetDensity_FreeStream(Density_FreeStream);
                FluidModel->SetTDState_rhoT(Density_FreeStream, Temperature_FreeStream);
                Pressure_FreeStream  = FluidModel->GetPressure();
                config->SetPressure_FreeStream(Pressure_FreeStream);
                Energy_FreeStream = FluidModel->GetStaticEnergy() + 0.5*ModVel_FreeStream*ModVel_FreeStream;

            } else {
                FluidModel->SetLaminarViscosityModel(config);
                Viscosity_FreeStream = FluidModel->GetLaminarViscosity();
                config->SetViscosity_FreeStream(Viscosity_FreeStream);
                Energy_FreeStream = FluidModel->GetStaticEnergy() + 0.5*ModVel_FreeStream*ModVel_FreeStream;

            }

            /*--- Turbulence kinetic energy ---*/

            Tke_FreeStream  = 3.0/2.0*(ModVel_FreeStream*ModVel_FreeStream*config->GetTurbulenceIntensity_FreeStream()*config->GetTurbulenceIntensity_FreeStream());

        }
        else {

            /*--- For inviscid flow, energy is calculated from the specified
       FreeStream quantities using the proper gas law. ---*/

            Energy_FreeStream = FluidModel->GetStaticEnergy() + 0.5*ModVel_FreeStream*ModVel_FreeStream;

        }

        /*-- Compute the freestream energy. ---*/

        if (tkeNeeded) { Energy_FreeStream += Tke_FreeStream; }; config->SetEnergy_FreeStream(Energy_FreeStream);

        /*--- Additional reference values defined by Pref, Tref, Rho_ref. By definition,
     Lref is one because we have converted the grid to meters.---*/

        if (config->GetRef_NonDim() == DIMENSIONAL) {
            Pressure_Ref      = 1.0;
            Density_Ref       = 1.0;
            Temperature_Ref   = 1.0;
        }

        else if (config->GetRef_NonDim() == FREESTREAM_PRESS_EQ_ONE) {
            Pressure_Ref      = Pressure_FreeStream;     // Pressure_FreeStream = 1.0
            Density_Ref       = Density_FreeStream;      // Density_FreeStream = 1.0
            Temperature_Ref   = Temperature_FreeStream;  // Temperature_FreeStream = 1.0
        }
        else if (config->GetRef_NonDim() == FREESTREAM_VEL_EQ_MACH) {
            Pressure_Ref      = Gamma*Pressure_FreeStream; // Pressure_FreeStream = 1.0/Gamma
            Density_Ref       = Density_FreeStream;        // Density_FreeStream = 1.0
            Temperature_Ref   = Temperature_FreeStream;    // Temp_FreeStream = 1.0
        }
        else if (config->GetRef_NonDim() == FREESTREAM_VEL_EQ_ONE) {
            Pressure_Ref      = Mach*Mach*Gamma*Pressure_FreeStream; // Pressure_FreeStream = 1.0/(Gamma*(M_inf)^2)
            Density_Ref       = Density_FreeStream;        // Density_FreeStream = 1.0
            Temperature_Ref   = Temperature_FreeStream;    // Temp_FreeStream = 1.0
        }
        config->SetPressure_Ref(Pressure_Ref);
        config->SetDensity_Ref(Density_Ref);
        config->SetTemperature_Ref(Temperature_Ref);

        Length_Ref        = 1.0;                                                         config->SetLength_Ref(Length_Ref);
        Velocity_Ref      = sqrt(config->GetPressure_Ref()/config->GetDensity_Ref());    config->SetVelocity_Ref(Velocity_Ref);
        Time_Ref          = Length_Ref/Velocity_Ref;                                     config->SetTime_Ref(Time_Ref);
        Omega_Ref         = Velocity_Ref/Length_Ref;                                     config->SetOmega_Ref(Omega_Ref);
        Force_Ref         = config->GetDensity_Ref()*Velocity_Ref*Velocity_Ref*Length_Ref*Length_Ref; config->SetForce_Ref(Force_Ref);
        Gas_Constant_Ref  = Velocity_Ref*Velocity_Ref/config->GetTemperature_Ref();      config->SetGas_Constant_Ref(Gas_Constant_Ref);
        Viscosity_Ref     = config->GetDensity_Ref()*Velocity_Ref*Length_Ref;            config->SetViscosity_Ref(Viscosity_Ref);
        Conductivity_Ref  = Viscosity_Ref*Gas_Constant_Ref;                              config->SetConductivity_Ref(Conductivity_Ref);
        Froude            = ModVel_FreeStream/sqrt(STANDART_GRAVITY*Length_Ref);         config->SetFroude(Froude);

    }

    //Incompressible Case is not included..//

    /*--- Divide by reference values, to compute the non-dimensional free-stream values ---*/

    Pressure_FreeStreamND = Pressure_FreeStream/config->GetPressure_Ref();  config->SetPressure_FreeStreamND(Pressure_FreeStreamND);
    Density_FreeStreamND  = Density_FreeStream/config->GetDensity_Ref();    config->SetDensity_FreeStreamND(Density_FreeStreamND);
    for (iDim = 0; iDim < nDim; iDim++) {
        Velocity_FreeStreamND[iDim] = config->GetVelocity_FreeStream()[iDim]/Velocity_Ref; config->SetVelocity_FreeStreamND(Velocity_FreeStreamND[iDim], iDim);
    }

    Temperature_FreeStreamND = Temperature_FreeStream/config->GetTemperature_Ref(); config->SetTemperature_FreeStreamND(Temperature_FreeStreamND);

    Gas_ConstantND = config->GetGas_Constant()/Gas_Constant_Ref;    config->SetGas_ConstantND(Gas_ConstantND);


    ModVel_FreeStreamND = 0.0;
    for (iDim = 0; iDim < nDim; iDim++) ModVel_FreeStreamND += Velocity_FreeStreamND[iDim]*Velocity_FreeStreamND[iDim];
    ModVel_FreeStreamND    = sqrt(ModVel_FreeStreamND); config->SetModVel_FreeStreamND(ModVel_FreeStreamND);

    Viscosity_FreeStreamND = Viscosity_FreeStream / Viscosity_Ref;   config->SetViscosity_FreeStreamND(Viscosity_FreeStreamND);

    Tke_FreeStream  = 3.0/2.0*(ModVel_FreeStream*ModVel_FreeStream*config->GetTurbulenceIntensity_FreeStream()*config->GetTurbulenceIntensity_FreeStream());
    config->SetTke_FreeStream(Tke_FreeStream);

    Tke_FreeStreamND  = 3.0/2.0*(ModVel_FreeStreamND*ModVel_FreeStreamND*config->GetTurbulenceIntensity_FreeStream()*config->GetTurbulenceIntensity_FreeStream());
    config->SetTke_FreeStreamND(Tke_FreeStreamND);

    Omega_FreeStream = Density_FreeStream*Tke_FreeStream/(Viscosity_FreeStream*config->GetTurb2LamViscRatio_FreeStream());
    config->SetOmega_FreeStream(Omega_FreeStream);

    Omega_FreeStreamND = Density_FreeStreamND*Tke_FreeStreamND/(Viscosity_FreeStreamND*config->GetTurb2LamViscRatio_FreeStream());
    config->SetOmega_FreeStreamND(Omega_FreeStreamND);

    /*--- Initialize the dimensionless Fluid Model that will be used to solve the dimensionless problem ---*/

    switch (config->GetKind_FluidModel()) {

    case STANDARD_AIR:
        FluidModel = new CIdealGas(1.4, Gas_ConstantND);
        FluidModel->SetEnergy_Prho(Pressure_FreeStreamND, Density_FreeStreamND);
        break;

    case IDEAL_GAS:
        FluidModel = new CIdealGas(Gamma, Gas_ConstantND);
        FluidModel->SetEnergy_Prho(Pressure_FreeStreamND, Density_FreeStreamND);
        break;

    case VW_GAS:
        FluidModel = new CVanDerWaalsGas(Gamma, Gas_ConstantND, config->GetPressure_Critical() /config->GetPressure_Ref(),
                                         config->GetTemperature_Critical()/config->GetTemperature_Ref());
        FluidModel->SetEnergy_Prho(Pressure_FreeStreamND, Density_FreeStreamND);
        break;

    case PR_GAS:
        FluidModel = new CPengRobinson(Gamma, Gas_ConstantND, config->GetPressure_Critical() /config->GetPressure_Ref(),
                                       config->GetTemperature_Critical()/config->GetTemperature_Ref(), config->GetAcentric_Factor());
        FluidModel->SetEnergy_Prho(Pressure_FreeStreamND, Density_FreeStreamND);
        break;

    }

    Energy_FreeStreamND = FluidModel->GetStaticEnergy() + 0.5*ModVel_FreeStreamND*ModVel_FreeStreamND;

    if (viscous) {

        /*--- Constant viscosity model ---*/
        config->SetMu_ConstantND(config->GetMu_ConstantND()/Viscosity_Ref);

        /*--- Sutherland's model ---*/

        config->SetMu_RefND(config->GetMu_RefND()/Viscosity_Ref);
        config->SetMu_SND(config->GetMu_SND()/config->GetTemperature_Ref());
        config->SetMu_Temperature_RefND(config->GetMu_Temperature_RefND()/config->GetTemperature_Ref());

        /* constant thermal conductivity model */
        config->SetKt_ConstantND(config->GetKt_ConstantND()/Conductivity_Ref);

        FluidModel->SetLaminarViscosityModel(config);
        FluidModel->SetThermalConductivityModel(config);

    }

    if (tkeNeeded) { Energy_FreeStreamND += Tke_FreeStreamND; };  config->SetEnergy_FreeStreamND(Energy_FreeStreamND);

    Energy_Ref = Energy_FreeStream/Energy_FreeStreamND; config->SetEnergy_Ref(Energy_Ref);

    Total_UnstTimeND = config->GetTotal_UnstTime() / Time_Ref;    config->SetTotal_UnstTimeND(Total_UnstTimeND);
    Delta_UnstTimeND = config->GetDelta_UnstTime() / Time_Ref;    config->SetDelta_UnstTimeND(Delta_UnstTimeND);

    /*--- Write output to the console if this is the master node and first domain ---*/

    if ((rank == MASTER_NODE) && (iMesh == MESH_0)) {

        cout.precision(6);

        if (compressible) {
            if (viscous) {
                cout << "Viscous flow: Computing pressure using the ideal gas law" << endl;
                cout << "based on the free-stream temperature and a density computed" << endl;
                cout << "from the Reynolds number." << endl;
            } else {
                cout << "Inviscid flow: Computing density based on free-stream" << endl;
                cout << "temperature and pressure using the ideal gas law." << endl;
            }
        }

        if (grid_movement) cout << "Force coefficients computed using MACH_MOTION." << endl;
        else cout << "Force coefficients computed using free-stream values." << endl;

        //..Incompressible and Free Surface are not included..//

        cout <<"-- Input conditions:"<< endl;

        if (compressible) {
            switch (config->GetKind_FluidModel()) {

            case STANDARD_AIR:
                cout << "Fluid Model: STANDARD_AIR "<< endl;
                cout << "Specific gas constant: " << config->GetGas_Constant();
                if (config->GetSystemMeasurements() == SI) cout << " N.m/kg.K." << endl;
                else if (config->GetSystemMeasurements() == US) cout << " lbf.ft/slug.R." << endl;
                cout << "Specific gas constant (non-dim): " << config->GetGas_ConstantND()<< endl;
                cout << "Specific Heat Ratio: 1.4000 "<< endl;
                break;

            case IDEAL_GAS:
                cout << "Fluid Model: IDEAL_GAS "<< endl;
                cout << "Specific gas constant: " << config->GetGas_Constant() << " N.m/kg.K." << endl;
                cout << "Specific gas constant (non-dim): " << config->GetGas_ConstantND()<< endl;
                cout << "Specific Heat Ratio: "<< Gamma << endl;
                break;

            case VW_GAS:
                cout << "Fluid Model: Van der Waals "<< endl;
                cout << "Specific gas constant: " << config->GetGas_Constant() << " N.m/kg.K." << endl;
                cout << "Specific gas constant (non-dim): " << config->GetGas_ConstantND()<< endl;
                cout << "Specific Heat Ratio: "<< Gamma << endl;
                cout << "Critical Pressure:   " << config->GetPressure_Critical()  << " Pa." << endl;
                cout << "Critical Temperature:  " << config->GetTemperature_Critical() << " K." << endl;
                cout << "Critical Pressure (non-dim):   " << config->GetPressure_Critical() /config->GetPressure_Ref() << endl;
                cout << "Critical Temperature (non-dim) :  " << config->GetTemperature_Critical() /config->GetTemperature_Ref() << endl;
                break;

            case PR_GAS:
                cout << "Fluid Model: Peng-Robinson "<< endl;
                cout << "Specific gas constant: " << config->GetGas_Constant() << " N.m/kg.K." << endl;
                cout << "Specific gas constant (non-dim): " << config->GetGas_ConstantND()<< endl;
                cout << "Specific Heat Ratio: "<< Gamma << endl;
                cout << "Critical Pressure:   " << config->GetPressure_Critical()  << " Pa." << endl;
                cout << "Critical Temperature:  " << config->GetTemperature_Critical() << " K." << endl;
                cout << "Critical Pressure (non-dim):   " << config->GetPressure_Critical() /config->GetPressure_Ref() << endl;
                cout << "Critical Temperature (non-dim) :  " << config->GetTemperature_Critical() /config->GetTemperature_Ref() << endl;
                break;

            }
            if(viscous){
                switch (config->GetKind_ViscosityModel()) {

                case CONSTANT_VISCOSITY:
                    cout << "Viscosity Model: CONSTANT_VISCOSITY  "<< endl;
                    cout << "Laminar Viscosity: " << config->GetMu_ConstantND()*Viscosity_Ref;
                    if (config->GetSystemMeasurements() == SI) cout << " N.s/m^2." << endl;
                    else if (config->GetSystemMeasurements() == US) cout << " lbf.s/ft^2." << endl;
                    cout << "Laminar Viscosity (non-dim): " << config->GetMu_ConstantND()<< endl;
                    break;

                case SUTHERLAND:
                    cout << "Viscosity Model: SUTHERLAND "<< endl;
                    cout << "Ref. Laminar Viscosity: " << config->GetMu_RefND()*Viscosity_Ref;
                    if (config->GetSystemMeasurements() == SI) cout << " N.s/m^2." << endl;
                    else if (config->GetSystemMeasurements() == US) cout << " lbf.s/ft^2." << endl;
                    cout << "Ref. Temperature: " << config->GetMu_Temperature_RefND()*config->GetTemperature_Ref();
                    if (config->GetSystemMeasurements() == SI) cout << " K." << endl;
                    else if (config->GetSystemMeasurements() == US) cout << " R." << endl;
                    cout << "Sutherland Constant: "<< config->GetMu_SND()*config->GetTemperature_Ref();
                    if (config->GetSystemMeasurements() == SI) cout << " K." << endl;
                    else if (config->GetSystemMeasurements() == US) cout << " R." << endl;
                    cout << "Laminar Viscosity (non-dim): " << config->GetMu_ConstantND()<< endl;
                    cout << "Ref. Temperature (non-dim): " << config->GetMu_Temperature_RefND()<< endl;
                    cout << "Sutherland constant (non-dim): "<< config->GetMu_SND()<< endl;
                    break;

                }
                switch (config->GetKind_ConductivityModel()) {

                case CONSTANT_PRANDTL:
                    cout << "Conductivity Model: CONSTANT_PRANDTL  "<< endl;
                    cout << "Prandtl: " << config->GetPrandtl_Lam()<< endl;
                    break;

                case CONSTANT_CONDUCTIVITY:
                    cout << "Conductivity Model: CONSTANT_CONDUCTIVITY "<< endl;
                    cout << "Molecular Conductivity: " << config->GetKt_ConstantND()*Conductivity_Ref<< " W/m^2.K." << endl;
                    cout << "Molecular Conductivity (non-dim): " << config->GetKt_ConstantND()<< endl;
                    break;

                }
            }
        }

        //..Incompressible and Free Surface are not included..//

        cout << "Free-stream pressure: " << config->GetPressure_FreeStream();
        if (config->GetSystemMeasurements() == SI) cout << " Pa." << endl;
        else if (config->GetSystemMeasurements() == US) cout << " psf." << endl;

        if (compressible) {
            cout << "Free-stream temperature: " << config->GetTemperature_FreeStream();
            if (config->GetSystemMeasurements() == SI) cout << " K." << endl;
            else if (config->GetSystemMeasurements() == US) cout << " R." << endl;
        }

        cout << "Free-stream density: " << config->GetDensity_FreeStream();
        if (config->GetSystemMeasurements() == SI) cout << " kg/m^3." << endl;
        else if (config->GetSystemMeasurements() == US) cout << " slug/ft^3." << endl;

        if (nDim == 2) {
            cout << "Free-stream velocity: (" << config->GetVelocity_FreeStream()[0] << ", ";
            cout << config->GetVelocity_FreeStream()[1] << ")";
        }
        if (nDim == 3) {
            cout << "Free-stream velocity: (" << config->GetVelocity_FreeStream()[0] << ", ";
            cout << config->GetVelocity_FreeStream()[1] << ", " << config->GetVelocity_FreeStream()[2] << ")";
        }
        if (config->GetSystemMeasurements() == SI) cout << " m/s. ";
        else if (config->GetSystemMeasurements() == US) cout << " ft/s. ";

        cout << "Magnitude: "	<< config->GetModVel_FreeStream();
        if (config->GetSystemMeasurements() == SI) cout << " m/s." << endl;
        else if (config->GetSystemMeasurements() == US) cout << " ft/s." << endl;

        if (compressible) {
            cout << "Free-stream total energy per unit mass: " << config->GetEnergy_FreeStream();
            if (config->GetSystemMeasurements() == SI) cout << " m^2/s^2." << endl;
            else if (config->GetSystemMeasurements() == US) cout << " ft^2/s^2." << endl;
        }

        if (viscous) {
            cout << "Free-stream viscosity: " << config->GetViscosity_FreeStream();
            if (config->GetSystemMeasurements() == SI) cout << " N.s/m^2." << endl;
            else if (config->GetSystemMeasurements() == US) cout << " lbf.s/ft^2." << endl;
            if (turbulent){
                cout << "Free-stream turb. kinetic energy per unit mass: " << config->GetTke_FreeStream();
                if (config->GetSystemMeasurements() == SI) cout << " m^2/s^2." << endl;
                else if (config->GetSystemMeasurements() == US) cout << " ft^2/s^2." << endl;
                cout << "Free-stream specific dissipation: " << config->GetOmega_FreeStream();
                if (config->GetSystemMeasurements() == SI) cout << " 1/s." << endl;
                else if (config->GetSystemMeasurements() == US) cout << " 1/s." << endl;
            }
        }

        if (unsteady) { cout << "Total time: " << config->GetTotal_UnstTime() << " s. Time step: " << config->GetDelta_UnstTime() << " s." << endl; }

        /*--- Print out reference values. ---*/

        cout <<"-- Reference values:"<< endl;

        if (compressible) {
            cout << "Reference specific gas constant: " << config->GetGas_Constant_Ref();
            if (config->GetSystemMeasurements() == SI) cout << " N.m/kg.K." << endl;
            else if (config->GetSystemMeasurements() == US) cout << " lbf.ft/slug.R." << endl;
        }

        cout << "Reference pressure: " << config->GetPressure_Ref();
        if (config->GetSystemMeasurements() == SI) cout << " Pa." << endl;
        else if (config->GetSystemMeasurements() == US) cout << " psf." << endl;

        if (compressible) {
            cout << "Reference temperature: " << config->GetTemperature_Ref();
            if (config->GetSystemMeasurements() == SI) cout << " K." << endl;
            else if (config->GetSystemMeasurements() == US) cout << " R." << endl;
        }

        cout << "Reference density: " << config->GetDensity_Ref();
        if (config->GetSystemMeasurements() == SI) cout << " kg/m^3." << endl;
        else if (config->GetSystemMeasurements() == US) cout << " slug/ft^3." << endl;

        cout << "Reference velocity: " << config->GetVelocity_Ref();
        if (config->GetSystemMeasurements() == SI) cout << " m/s." << endl;
        else if (config->GetSystemMeasurements() == US) cout << " ft/s." << endl;

        if (compressible) {
            cout << "Reference energy per unit mass: " << config->GetEnergy_Ref();
            if (config->GetSystemMeasurements() == SI) cout << " m^2/s^2." << endl;
            else if (config->GetSystemMeasurements() == US) cout << " ft^2/s^2." << endl;
        }

        //..Incompressible and Free Surface are not included..//

        if (viscous) {
            cout << "Reference viscosity: " << config->GetViscosity_Ref();
            if (config->GetSystemMeasurements() == SI) cout << " N.s/m^2." << endl;
            else if (config->GetSystemMeasurements() == US) cout << " lbf.s/ft^2." << endl;
            cout << "Reference conductivity: " << config->GetConductivity_Ref();
            if (config->GetSystemMeasurements() == SI) cout << " W/m^2.K." << endl;
            else if (config->GetSystemMeasurements() == US) cout << " lbf/ft.s.R." << endl;
        }


        if (unsteady) cout << "Reference time: " << config->GetTime_Ref() <<" s." << endl;

        /*--- Print out resulting non-dim values here. ---*/

        cout << "-- Resulting non-dimensional state:" << endl;
        cout << "Mach number (non-dim): " << config->GetMach() << endl;
        if (viscous) {
            cout << "Reynolds number (non-dim): " << config->GetReynolds() <<". Re length: " << config->GetLength_Reynolds();
            if (config->GetSystemMeasurements() == SI) cout << " m." << endl;
            else if (config->GetSystemMeasurements() == US) cout << " ft." << endl;
        }
        if (gravity) {
            cout << "Froude number (non-dim): " << Froude << endl;
            cout << "Lenght of the baseline wave (non-dim): " << 2.0*PI_NUMBER*Froude*Froude << endl;
        }

        if (compressible) {
            cout << "Specific gas constant (non-dim): " << config->GetGas_ConstantND() << endl;
            cout << "Free-stream temperature (non-dim): " << config->GetTemperature_FreeStreamND() << endl;
        }

        cout << "Free-stream pressure (non-dim): " << config->GetPressure_FreeStreamND() << endl;

        cout << "Free-stream density (non-dim): " << config->GetDensity_FreeStreamND() << endl;

        if (nDim == 2) {
            cout << "Free-stream velocity (non-dim): (" << config->GetVelocity_FreeStreamND()[0] << ", ";
            cout << config->GetVelocity_FreeStreamND()[1] << "). ";
        } else {
            cout << "Free-stream velocity (non-dim): (" << config->GetVelocity_FreeStreamND()[0] << ", ";
            cout << config->GetVelocity_FreeStreamND()[1] << ", " << config->GetVelocity_FreeStreamND()[2] << "). ";
        }
        cout << "Magnitude: "	 << config->GetModVel_FreeStreamND() << endl;

        if (compressible)
            cout << "Free-stream total energy per unit mass (non-dim): " << config->GetEnergy_FreeStreamND() << endl;

        if (viscous) {
            cout << "Free-stream viscosity (non-dim): " << config->GetViscosity_FreeStreamND() << endl;
            if (turbulent){
                cout << "Free-stream turb. kinetic energy (non-dim): " << config->GetTke_FreeStreamND() << endl;
                cout << "Free-stream specific dissipation (non-dim): " << config->GetOmega_FreeStreamND() << endl;
            }
        }

        if (unsteady) {
            cout << "Total time (non-dim): " << config->GetTotal_UnstTimeND() << endl;
            cout << "Time step (non-dim): " << config->GetDelta_UnstTimeND() << endl;
        }

        cout << endl;

    }

}

void CEulerSolver::SetInitialCondition(CGeometry **geometry, CSolver ***solver_container, CConfig *config, unsigned long ExtIter) {

    unsigned long iPoint;
    unsigned short iMesh;

    bool restart = (config->GetRestart() || config->GetRestart_Flow());
    bool rans = ((config->GetKind_Solver() == RANS) ||
                 (config->GetKind_Solver() == ADJ_RANS));
    bool dual_time = ((config->GetUnsteady_Simulation() == DT_STEPPING_1ST) ||
                      (config->GetUnsteady_Simulation() == DT_STEPPING_2ND));

    //..Incompressible and Gravity are not included..//

    if (dual_time && (ExtIter == 0 || (restart && ExtIter == config->GetUnst_RestartIter()))) {

        for (iMesh = 0; iMesh <= config->GetnMGLevels(); iMesh++) {
            for (iPoint = 0; iPoint < geometry[iMesh]->GetnElem(); iPoint++) {
                solver_container[iMesh][FLOW_SOL]->elem[iPoint]->Set_Solution_time_n();
                solver_container[iMesh][FLOW_SOL]->elem[iPoint]->Set_Solution_time_n1();
                if (rans) {
                    solver_container[iMesh][TURB_SOL]->elem[iPoint]->Set_Solution_time_n();
                    solver_container[iMesh][TURB_SOL]->elem[iPoint]->Set_Solution_time_n1();
                }
            }
        }

        if ((restart && ExtIter == config->GetUnst_RestartIter()) &&
                (config->GetUnsteady_Simulation() == DT_STEPPING_2ND)) {

            solver_container[MESH_0][FLOW_SOL]->LoadRestart(geometry, solver_container, config, int(config->GetUnst_RestartIter()-1), true);

            if (rans)
                solver_container[MESH_0][TURB_SOL]->LoadRestart(geometry, solver_container, config, int(config->GetUnst_RestartIter()-1), false);

            for (iMesh = 0; iMesh <= config->GetnMGLevels(); iMesh++) {
                for (iPoint = 0; iPoint < geometry[iMesh]->GetnElem(); iPoint++) {
                    solver_container[iMesh][FLOW_SOL]->elem[iPoint]->Set_Solution_time_n();
                    if (rans) {
                        solver_container[iMesh][TURB_SOL]->elem[iPoint]->Set_Solution_time_n();
                    }
                }
            }
        }
    }
}

void CEulerSolver::Preprocessing(CGeometry *geometry, CSolver **solver_container, CConfig *config, unsigned short iMesh, unsigned short iRKStep, unsigned short RunTime_EqSystem, bool Output) {

    unsigned long ErrorCounter = 0;

#ifdef HAVE_MPI
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

    unsigned long ExtIter = config->GetExtIter();
    bool implicit         = (config->GetKind_TimeIntScheme_Flow() == EULER_IMPLICIT);
    bool muscl            = (config->GetMUSCL_Flow());
    bool limiter          = ((config->GetKind_SlopeLimit_Flow() != NO_LIMITER) && (ExtIter <= config->GetLimiterIter()));
    bool center           = (config->GetKind_ConvNumScheme_Flow() == SPACE_CENTERED);
    bool center_jst       = center && (config->GetKind_Centered_Flow() == JST);
    bool van_albada       = config->GetKind_SlopeLimit_Flow() == VAN_ALBADA_EDGE;
    unsigned short kind_row_dissipation = config->GetKind_RoeLowDiss();
    bool roe_low_dissipation  = (kind_row_dissipation != NO_ROELOWDISS) && (config->GetKind_Upwind_Flow() == ROE);
    bool fixed_cl         = config->GetFixed_CL_Mode();
    unsigned long iPoint;
    bool RightSol = true;

    if (fixed_cl) { SetFarfield_AoA(geometry, solver_container, config, iMesh, Output); }

    for (iPoint = 0; iPoint < nElem; iPoint ++) {

        elem[iPoint]->SetNon_Physical(false);
        RightSol = elem[iPoint]->SetPrimVar_Compressible(FluidModel);

        //..RightSol for Incompressible and Free Surface are not included..//

        elem[iPoint]->SetSecondaryVar_Compressible(FluidModel);
        if (!RightSol) { elem[iPoint]->SetNon_Physical(true); ErrorCounter++;
        }
        if (!Output) LinSysRes.SetBlock_Zero(iPoint);
    }

    if (config->GetKind_Gradient_Method() == GREEN_GAUSS) {
        SetPrimitive_Gradient_GG(geometry, config);
    }

    if ((muscl && !center) && (iMesh == MESH_0) && !Output) {

        if (config->GetKind_Gradient_Method() == GREEN_GAUSS) {
            SetPrimitive_Gradient_GG(geometry, config);
        }
        if (config->GetKind_Gradient_Method() == WEIGHTED_LEAST_SQUARES) {
            SetPrimitive_Gradient_LS(geometry, config);
        }

        if (limiter && (iMesh == MESH_0)
                && !Output && !van_albada) { SetPrimitive_Limiter(geometry, config); }

    }

    if (center && !Output) {
        SetMax_Eigenvalue(geometry, config);
        if ((center_jst) && (iMesh == MESH_0)) {
            SetCentered_Dissipation_Sensor(geometry, config);
            SetUndivided_Laplacian(geometry, config);
        }
    }

    if (roe_low_dissipation){
        SetRoe_Dissipation(geometry, config);
        if (kind_row_dissipation == FD_DUCROS || kind_row_dissipation == NTS_DUCROS){
            SetUpwind_Ducros_Sensor(geometry, config);
        }
    }

    if (implicit) Jacobian.SetValZero();

    if (config->GetConsole_Output_Verb() == VERB_HIGH) {
#ifdef HAVE_MPI
        unsigned long MyErrorCounter = ErrorCounter; ErrorCounter = 0;
        MPI_Allreduce(&MyErrorCounter, &ErrorCounter, 1, MPI_UNSIGNED_LONG, MPI_SUM, MPI_COMM_WORLD);
#endif
        if (iMesh == MESH_0) config->SetNonphysical_Points(ErrorCounter);
    }

}

void CEulerSolver::Postprocessing(CGeometry *geometry, CSolver **solver_container, CConfig *config,
                                  unsigned short iMesh) { }

unsigned long CEulerSolver::SetPrimitive_Variables(CSolver **solver_container, CConfig *config, bool Output) {

    unsigned long iPoint, ErrorCounter = 0;
    bool RightSol = true;

    for (iPoint = 0; iPoint < nElem; iPoint ++) {

        elem[iPoint]->SetNon_Physical(false);
        RightSol = elem[iPoint]->SetPrimVar_Compressible(FluidModel);
        elem[iPoint]->SetSecondaryVar_Compressible(FluidModel);

        if (!RightSol) { elem[iPoint]->SetNon_Physical(true); ErrorCounter++; }

        if (!Output) LinSysRes.SetBlock_Zero(iPoint);
    }

    return ErrorCounter;
}


void CEulerSolver::SetTime_Step(CGeometry *geometry, CSolver **solver_container, CConfig *config,
                                unsigned short iMesh, unsigned long Iteration) {
    int rank = MASTER_NODE;
#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

    double Area, Vol, Mean_SoundSpeed = 0.0, Mean_ProjVel = 0.0, Mean_BetaInc2, Lambda, Local_Delta_Time, Mean_DensityInc,
            Global_Delta_Time = 1E6, Global_Delta_UnstTimeND, ProjVel, ProjVel_i, ProjVel_j;
    unsigned long iFace, iVertex, iPoint, jPoint;
    unsigned short iDim, iMarker;
    double *Normal, UnitNormal[3] = {0.0, 0.0, 0.0};

    bool implicit = (config->GetKind_TimeIntScheme_Flow() == EULER_IMPLICIT);
    bool compressible = (config->GetKind_Regime() == COMPRESSIBLE);
    bool dual_time = ((config->GetUnsteady_Simulation() == DT_STEPPING_1ST) ||
                      (config->GetUnsteady_Simulation() == DT_STEPPING_2ND));

    Min_Delta_Time = 1.E6; Max_Delta_Time = 0.0;

    for (iPoint = 0; iPoint < nElemDomain; iPoint++){
        elem[iPoint]->SetMax_Lambda_Inv(0.0);
    }

    for (iFace = 0; iFace < geometry->GetnFace(); iFace++) {

        iPoint = geometry->face[iFace]->GetElems(0);

        if(geometry->face[iFace]->GetElems(1) != -1){

            jPoint = geometry->face[iFace]->GetElems(1);
            Normal = geometry->face[iFace]->GetNormal_Face();
            Area = 0.0; for (iDim = 0; iDim < nDim; iDim++) Area += Normal[iDim]*Normal[iDim]; Area = sqrt(Area);
            for(iDim = 0; iDim < nDim; iDim++) UnitNormal[iDim] = Normal[iDim]/Area;

            if (compressible) {
                Mean_ProjVel = 0.5 * (elem[iPoint]->GetProjVel(UnitNormal) + elem[jPoint]->GetProjVel(UnitNormal));
                Mean_SoundSpeed = 0.5 * (elem[iPoint]->GetSoundSpeed() + elem[jPoint]->GetSoundSpeed());// * Area;
            }

            //..Incompressible, Free Surface and Grid Movements are not included..//

            Lambda = (fabs(Mean_ProjVel) + Mean_SoundSpeed)*Area;

            if (geometry->elem[iPoint]->GetDomain()){
                elem[iPoint]->AddMax_Lambda_Inv(Lambda);
            }
            if (geometry->elem[jPoint]->GetDomain()){
                elem[jPoint]->AddMax_Lambda_Inv(Lambda);
            }
        }
    }

    for (iMarker = 0; iMarker < geometry->GetnMarker(); iMarker++) {
        if(config->GetMarker_All_KindBC(iMarker) != SEND_RECEIVE){
            for (iVertex = 0; iVertex < geometry->GetnElem_Bound(iMarker); iVertex++) {

                iFace = geometry->bound[iMarker][iVertex]->GetGlobalFace();
                iPoint = geometry->face[iFace]->GetElems(0);
                Normal = geometry->face[iFace]->GetNormal_Face();
                Area = 0.0; for (iDim = 0; iDim < nDim; iDim++) Area += Normal[iDim]*Normal[iDim]; Area = sqrt(Area);
                for(iDim = 0; iDim < nDim; iDim++) UnitNormal[iDim] = Normal[iDim]/Area;

                if (compressible) {
                    Mean_ProjVel = elem[iPoint]->GetProjVel(UnitNormal);
                    Mean_SoundSpeed = elem[iPoint]->GetSoundSpeed();// * Area;
                }

                //..Incompressible, Free Surface and Grid Movements are not included..//

                Lambda = (fabs(Mean_ProjVel) + Mean_SoundSpeed)*Area;

                if (geometry->elem[iPoint]->GetDomain()) {
                    elem[iPoint]->AddMax_Lambda_Inv(Lambda);
                }
            }
        }
    }

    for (iPoint = 0; iPoint < nElemDomain; iPoint++) {
        Vol = geometry->elem[iPoint]->GetVolume();

        if (Vol != 0.0) {
            Local_Delta_Time = config->GetCFL(iMesh)*Vol/ elem[iPoint]->GetMax_Lambda_Inv();
            Global_Delta_Time = min(Global_Delta_Time, Local_Delta_Time);
            Min_Delta_Time = min(Min_Delta_Time, Local_Delta_Time);
            Max_Delta_Time = max(Max_Delta_Time, Local_Delta_Time);
            if (Local_Delta_Time > config->GetMax_DeltaTime())
                Local_Delta_Time = config->GetMax_DeltaTime();

            elem[iPoint]->SetDelta_Time(Local_Delta_Time);
        }
        else {
            elem[iPoint]->SetDelta_Time(0.0);
        }
    }

    if (config->GetConsole_Output_Verb() == VERB_HIGH) {
#ifdef HAVE_MPI
        double rbuf_time, sbuf_time;
        sbuf_time = Min_Delta_Time;
        MPI_Reduce(&sbuf_time, &rbuf_time, 1, MPI_DOUBLE, MPI_MIN, MASTER_NODE, MPI_COMM_WORLD);
        MPI_Bcast(&rbuf_time, 1, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
        Min_Delta_Time = rbuf_time;

        sbuf_time = Max_Delta_Time;
        MPI_Reduce(&sbuf_time, &rbuf_time, 1, MPI_DOUBLE, MPI_MAX, MASTER_NODE, MPI_COMM_WORLD);
        MPI_Bcast(&rbuf_time, 1, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
        Max_Delta_Time = rbuf_time;
#endif
    }

    if (config->GetUnsteady_Simulation() == TIME_STEPPING) {
#ifdef HAVE_MPI
        double rbuf_time, sbuf_time;
        sbuf_time = Global_Delta_Time;
        MPI_Reduce(&sbuf_time, &rbuf_time, 1, MPI_DOUBLE, MPI_MIN, MASTER_NODE, MPI_COMM_WORLD);
        MPI_Bcast(&rbuf_time, 1, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
        Global_Delta_Time = rbuf_time;
#endif
        for (iPoint = 0; iPoint < nElemDomain; iPoint++) {

            config->SetCFL(iMesh,config->GetUnst_CFL());

            if (config->GetCFL(iMesh) == 0.0) {
                elem[iPoint]->SetDelta_Time(config->GetDelta_UnstTime());
            } else {
                elem[iPoint]->SetDelta_Time(Global_Delta_Time);
            }
        }
    }


    if ((dual_time) && (Iteration == 0) && (config->GetUnst_CFL() != 0.0) && (iMesh == MESH_0)) {
        Global_Delta_UnstTimeND = config->GetUnst_CFL()*Global_Delta_Time/config->GetCFL(iMesh);

#ifdef HAVE_MPI
        double rbuf_time, sbuf_time;
        sbuf_time = Global_Delta_UnstTimeND;
        MPI_Reduce(&sbuf_time, &rbuf_time, 1, MPI_DOUBLE, MPI_MIN, MASTER_NODE, MPI_COMM_WORLD);
        MPI_Bcast(&rbuf_time, 1, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
        Global_Delta_UnstTimeND = rbuf_time;
#endif
        config->SetDelta_UnstTimeND(Global_Delta_UnstTimeND);
    }

    if (dual_time)
        for (iPoint = 0; iPoint < nElemDomain; iPoint++) {
            if (!implicit) {
                Local_Delta_Time = min((2.0/3.0)*config->GetDelta_UnstTimeND(), elem[iPoint]->GetDelta_Time());
                elem[iPoint]->SetDelta_Time(Local_Delta_Time);
            }
        }
}

void CEulerSolver::Centered_Residual(CGeometry *geometry, CSolver **solver_container, CNumerics *numerics,
                                     CConfig *config, unsigned short iMesh, unsigned short iRKStep) {
    unsigned long iFace, iPoint, jPoint;

    bool implicit = (config->GetKind_TimeIntScheme_Flow() == EULER_IMPLICIT);
    bool jst_scheme = ((config->GetKind_Centered_Flow() == JST) && (iMesh == MESH_0));

    for(iFace = 0; iFace < geometry->GetnFace(); iFace++) {
        iPoint = geometry->face[iFace]->GetElems(0);
        if(geometry->face[iFace]->GetElems(1) != -1){

            jPoint = geometry->face[iFace]->GetElems(1);
            numerics->SetNormal(geometry->face[iFace]->GetNormal_Face());
            numerics->SetNeighbor(geometry->elem[iPoint]->GetnNeighbor_Cell(), geometry->elem[jPoint]->GetnNeighbor_Cell());

            /*--- Set primitive variables w/o reconstruction ---*/

            numerics->SetPrimitive(elem[iPoint]->GetPrimitive(), elem[jPoint]->GetPrimitive());

            /*--- Set the largest convective eigenvalue ---*/

            numerics->SetLambda(elem[iPoint]->GetLambda(), elem[jPoint]->GetLambda());

            /*--- Set undivided laplacian an pressure based sensor ---*/

            if ( jst_scheme ) {
                numerics->SetUndivided_Laplacian(elem[iPoint]->GetUndivided_Laplacian(), elem[jPoint]->GetUndivided_Laplacian());
                numerics->SetSensor(elem[iPoint]->GetSensor(), elem[jPoint]->GetSensor());
            }

            //..Grid Movements are not included..//

            /*--- Compute residuals, and Jacobians ---*/

            numerics->ComputeResidual(Res_Conv, Jacobian_i, Jacobian_j, config);

            /*--- Update convective and artificial dissipation residuals ---*/

            LinSysRes.AddBlock(iPoint, Res_Conv);
            LinSysRes.SubtractBlock(jPoint, Res_Conv);

            /*--- Set implicit computation ---*/
            if (implicit) {
                Jacobian.AddBlock(iPoint,iPoint,Jacobian_i);
                Jacobian.AddBlock(iPoint,jPoint,Jacobian_j);
                Jacobian.SubtractBlock(jPoint,iPoint,Jacobian_i);
                Jacobian.SubtractBlock(jPoint,jPoint,Jacobian_j);
            }
        }
    }
}

void CEulerSolver::Upwind_Residual(CGeometry *geometry, CSolver **solver_container, CNumerics *numerics,
                                   CConfig *config, unsigned short iMesh) {
#ifdef HAVE_MPI
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

    unsigned long iFace = 0, iPoint = 0, jPoint = 0, counter_local = 0, counter_global = 0;
    unsigned short iDim = 0, iVar = 0;
    double z = 0.0, velocity2_i = 0.0, velocity2_j = 0.0, mach_i = 0.0, mach_j = 0.0, vel_i_corr[3], vel_j_corr[3];
    double **Gradient_i, **Gradient_j, Project_Grad_i = 0.0, Project_Grad_j = 0.0, RoeVelocity[3] = {0.0,0.0,0.0}, R = 0.0, sq_vel = 0.0, RoeEnthalpy = 0.0,
            *V_i, *V_j, *S_i, *S_j, *Limiter_i = NULL, *Limiter_j = NULL, sqvel = 0.0, Non_Physical = 1.0, Sensor_i = 0.0, Sensor_j = 0.0, Dissipation_i = 0.0, Dissipation_j = 0.0, *Coord_i, *Coord_j;
    bool neg_density_i = false, neg_density_j = false, neg_pressure_i = false, neg_pressure_j = false, neg_sound_speed = false;
    double *Normal, UnitNormal[3];
    unsigned long ExtIter = config->GetExtIter();
    unsigned short kind_dissipation = config->GetKind_RoeLowDiss();
    double *CGF, *CGI, *CGJ, SUM_1, SUM_2;

    bool implicit         = (config->GetKind_TimeIntScheme_Flow() == EULER_IMPLICIT);
    bool muscl            = (config->GetMUSCL_Flow() && (iMesh == MESH_0));
    bool limiter          = ((config->GetKind_SlopeLimit_Flow() != NO_LIMITER) && (ExtIter <= config->GetLimiterIter()));// && !(disc_adjoint && config->GetFrozen_Limiter_Disc()));
    bool compressible     = (config->GetKind_Regime() == COMPRESSIBLE);
    bool roe_turkel       = (config->GetKind_Upwind_Flow() == TURKEL);
    bool ideal_gas        = (config->GetKind_FluidModel() == STANDARD_AIR || config->GetKind_FluidModel() == IDEAL_GAS );
    bool low_mach_corr    = config->Low_Mach_Correction();
    double Area;

    for(iFace = 0; iFace < geometry->GetnFace(); iFace++) {
        iPoint = geometry->face[iFace]->GetElems(0);
        if(geometry->face[iFace]->GetElems(1) != -1){

            jPoint = geometry->face[iFace]->GetElems(1);
            Normal = geometry->face[iFace]->GetNormal_Face();
            Area = 0.0;
            for (iDim = 0; iDim < nDim; iDim++) Area += Normal[iDim]*Normal[iDim]; Area = sqrt(Area);

            numerics->SetNormal(Normal);

            for (iDim = 0; iDim < nDim; iDim++) UnitNormal[iDim] = Normal[iDim]/Area;

            CGF = geometry->face[iFace]->GetCG();
            CGI = geometry->elem[iPoint]->GetCG();
            CGJ = geometry->elem[jPoint]->GetCG();

            SUM_1 = 0.0; SUM_2 = 0.0;
            for(iDim = 0; iDim < nDim; iDim++){
                SUM_1 += Normal[iDim]*(CGF[iDim]-CGI[iDim]);
                SUM_2 += Normal[iDim]*(CGF[iDim]-CGJ[iDim]);
            }

            if (roe_turkel) {
                sqvel = 0.0;
                for (iDim = 0; iDim < nDim; iDim ++)
                    sqvel += config->GetVelocity_FreeStream()[iDim]*config->GetVelocity_FreeStream()[iDim];
                numerics->SetVelocity2_Inf(sqvel);
            }

            //..Grid Movements are not included..//

            V_i = elem[iPoint]->GetPrimitive(); V_j = elem[jPoint]->GetPrimitive();
            S_i = elem[iPoint]->GetSecondary(); S_j = elem[jPoint]->GetSecondary();


            if (muscl) {
                for (iDim = 0; iDim < nDim; iDim++) {
                    Vector_i[iDim] = 0.5*(geometry->elem[jPoint]->GetCG(iDim) - geometry->elem[iPoint]->GetCG(iDim));
                    Vector_j[iDim] = 0.5*(geometry->elem[iPoint]->GetCG(iDim) - geometry->elem[jPoint]->GetCG(iDim));

                }

                Gradient_i = elem[iPoint]->GetGradient_Primitive();
                Gradient_j = elem[jPoint]->GetGradient_Primitive();

                if (limiter) {
                    Limiter_i = elem[iPoint]->GetLimiter_Primitive();
                    Limiter_j = elem[jPoint]->GetLimiter_Primitive();
                }

                for (iVar = 0; iVar < nPrimVarGrad; iVar++) {
                    Project_Grad_i = 0.0; Project_Grad_j = 0.0;
                    Non_Physical = elem[iPoint]->GetNon_Physical()*elem[jPoint]->GetNon_Physical();
                    for (iDim = 0; iDim < nDim; iDim++) {
                        Project_Grad_i += Vector_i[iDim]*Gradient_i[iVar][iDim]*Non_Physical;
                        Project_Grad_j += Vector_j[iDim]*Gradient_j[iVar][iDim]*Non_Physical;
                    }
                    if (limiter) {
                        Primitive_i[iVar] = V_i[iVar] + Limiter_i[iVar]*Project_Grad_i;
                        Primitive_j[iVar] = V_j[iVar] + Limiter_j[iVar]*Project_Grad_j;
                    }
                    else {
                        Primitive_i[iVar] = V_i[iVar] + Project_Grad_i;
                        Primitive_j[iVar] = V_j[iVar] + Project_Grad_j;
                    }
                }

                if (!ideal_gas || low_mach_corr) { ComputeConsExtrapolation(config);}

                if (compressible) {

                    if (low_mach_corr) {

                        velocity2_i = 0.0;
                        velocity2_j = 0.0;

                        for (iDim = 0; iDim < nDim; iDim++) {
                            velocity2_i += Primitive_i[iDim+1]*Primitive_i[iDim+1];
                            velocity2_j += Primitive_j[iDim+1]*Primitive_j[iDim+1];
                        }

                        mach_i = sqrt(velocity2_i)/Primitive_i[nDim+4];
                        mach_j = sqrt(velocity2_j)/Primitive_j[nDim+4];

                        z = min(max(mach_i,mach_j),1.0);
                        velocity2_i = 0.0;
                        velocity2_j = 0.0;

                        for (iDim = 0; iDim < nDim; iDim++) {
                            vel_i_corr[iDim] = ( Primitive_i[iDim+1] + Primitive_j[iDim+1] )/2.0 \
                                    + z * ( Primitive_i[iDim+1] - Primitive_j[iDim+1] )/2.0;
                            vel_j_corr[iDim] = ( Primitive_i[iDim+1] + Primitive_j[iDim+1] )/2.0 \
                                    + z * ( Primitive_j[iDim+1] - Primitive_i[iDim+1] )/2.0;

                            velocity2_j += vel_j_corr[iDim]*vel_j_corr[iDim];
                            velocity2_i += vel_i_corr[iDim]*vel_i_corr[iDim];

                            Primitive_i[iDim+1] = vel_i_corr[iDim];
                            Primitive_j[iDim+1] = vel_j_corr[iDim];

                        }

                        FluidModel->SetEnergy_Prho(Primitive_i[nDim+1],Primitive_i[nDim+2]);
                        Primitive_i[nDim+3]= FluidModel->GetStaticEnergy() + Primitive_i[nDim+1]/Primitive_i[nDim+2] + 0.5*velocity2_i;

                        FluidModel->SetEnergy_Prho(Primitive_j[nDim+1],Primitive_j[nDim+2]);
                        Primitive_j[nDim+3]= FluidModel->GetStaticEnergy() + Primitive_j[nDim+1]/Primitive_j[nDim+2] + 0.5*velocity2_j;

                    }

                    neg_pressure_i = (Primitive_i[nDim+1] < 0.0); neg_pressure_j = (Primitive_j[nDim+1] < 0.0);
                    neg_density_i  = (Primitive_i[nDim+2] < 0.0); neg_density_j  = (Primitive_j[nDim+2] < 0.0);

                    R = sqrt(fabs(Primitive_j[nDim+2]/Primitive_i[nDim+2]));
                    sq_vel = 0.0;
                    for (iDim = 0; iDim < nDim; iDim++) {
                        RoeVelocity[iDim] = (R*Primitive_j[iDim+1]+Primitive_i[iDim+1])/(R+1);
                        sq_vel += RoeVelocity[iDim]*RoeVelocity[iDim];
                    }
                    RoeEnthalpy = (R*Primitive_j[nDim+3]+Primitive_i[nDim+3])/(R+1);
                    neg_sound_speed = ((Gamma-1)*(RoeEnthalpy-0.5*sq_vel) < 0.0);

                }

                if (neg_sound_speed) {
                    for (iVar = 0; iVar < nPrimVar; iVar++) {
                        Primitive_i[iVar] = V_i[iVar];
                        Primitive_j[iVar] = V_j[iVar]; }
                    if (compressible) {
                        Secondary_i[0] = S_i[0]; Secondary_i[1] = S_i[1];
                        Secondary_j[0] = S_i[0]; Secondary_j[1] = S_i[1]; }
                    counter_local++;
                }

                if (neg_density_i || neg_pressure_i) {
                    for (iVar = 0; iVar < nPrimVar; iVar++) Primitive_i[iVar] = V_i[iVar];
                    if (compressible) { Secondary_i[0] = S_i[0]; Secondary_i[1] = S_i[1]; }
                    counter_local++;
                }

                if (neg_density_j || neg_pressure_j) {
                    for (iVar = 0; iVar < nPrimVar; iVar++) Primitive_j[iVar] = V_j[iVar];
                    if (compressible) { Secondary_j[0] = S_j[0]; Secondary_j[1] = S_j[1]; }
                    counter_local++;
                }

                numerics->SetPrimitive(Primitive_i, Primitive_j);
                numerics->SetSecondary(Secondary_i, Secondary_j);

            }
            else {

                numerics->SetPrimitive(V_i, V_j);
                numerics->SetSecondary(S_i, S_j);
            }

            if (kind_dissipation != NO_ROELOWDISS){

                Dissipation_i = elem[iPoint]->GetRoe_Dissipation();
                Dissipation_j = elem[jPoint]->GetRoe_Dissipation();
                numerics->SetDissipation(Dissipation_i, Dissipation_j);

                if (kind_dissipation == FD_DUCROS || kind_dissipation == NTS_DUCROS){
                    Sensor_i = elem[iPoint]->GetSensor();
                    Sensor_j = elem[jPoint]->GetSensor();
                    numerics->SetSensor(Sensor_i, Sensor_j);
                }
                if (kind_dissipation == NTS || kind_dissipation == NTS_DUCROS){
                    Coord_i = geometry->elem[iPoint]->GetCG();
                    Coord_j = geometry->elem[jPoint]->GetCG();
                    numerics->SetCoord(Coord_i, Coord_j);
                }
            }

            numerics->ComputeResidual(Res_Conv, Jacobian_i, Jacobian_j, config);

            LinSysRes.AddBlock(iPoint, Res_Conv);
            LinSysRes.SubtractBlock(jPoint, Res_Conv);

            if (implicit) {
                Jacobian.AddBlock(iPoint, iPoint, Jacobian_i);
                Jacobian.AddBlock(iPoint, jPoint, Jacobian_j);
                Jacobian.SubtractBlock(jPoint, iPoint, Jacobian_i);
                Jacobian.SubtractBlock(jPoint, jPoint, Jacobian_j);
            }

            if (roe_turkel) {
                elem[iPoint]->SetPreconditioner_Beta(numerics->GetPrecond_Beta());
                elem[jPoint]->SetPreconditioner_Beta(numerics->GetPrecond_Beta());
            }

            if (kind_dissipation != NO_ROELOWDISS){
                elem[iPoint]->SetRoe_Dissipation(numerics->GetDissipation());
                elem[jPoint]->SetRoe_Dissipation(numerics->GetDissipation());
            }
        }
    }

    if (config->GetConsole_Output_Verb() == VERB_HIGH) {
#ifdef HAVE_MPI
        MPI_Reduce(&counter_local, &counter_global, 1, MPI_UNSIGNED_LONG, MPI_SUM, MASTER_NODE, MPI_COMM_WORLD);
#else
        counter_global = counter_local;
#endif
        if (iMesh == MESH_0) config->SetNonphysical_Reconstr(counter_global);
    }
}

void CEulerSolver::ComputeConsExtrapolation(CConfig *config){
    unsigned short iDim;

    double density_i = Primitive_i[nDim+2];
    double pressure_i = Primitive_i[nDim+1];
    double velocity2_i = 0.0;
    for (iDim = 0; iDim < nDim; iDim++) {
        velocity2_i += Primitive_i[iDim+1]*Primitive_i[iDim+1];
    }

    FluidModel->SetTDState_Prho(pressure_i, density_i);

    Primitive_i[0]= FluidModel->GetTemperature();
    Primitive_i[nDim+3]= FluidModel->GetStaticEnergy() + Primitive_i[nDim+1]/Primitive_i[nDim+2] + 0.5*velocity2_i;
    Primitive_i[nDim+4]= FluidModel->GetSoundSpeed();
    Secondary_i[0]=FluidModel->GetdPdrho_e();
    Secondary_i[1]=FluidModel->GetdPde_rho();


    double density_j = Primitive_j[nDim+2];
    double pressure_j = Primitive_j[nDim+1];
    double velocity2_j = 0.0;
    for (iDim = 0; iDim < nDim; iDim++) {
        velocity2_j += Primitive_j[iDim+1]*Primitive_j[iDim+1];
    }

    FluidModel->SetTDState_Prho(pressure_j, density_j);

    Primitive_j[0]= FluidModel->GetTemperature();
    Primitive_j[nDim+3]= FluidModel->GetStaticEnergy() + Primitive_j[nDim+1]/Primitive_j[nDim+2] + 0.5*velocity2_j;
    Primitive_j[nDim+4]=FluidModel->GetSoundSpeed();
    Secondary_j[0]=FluidModel->GetdPdrho_e();
    Secondary_j[1]=FluidModel->GetdPde_rho();

}

void CEulerSolver::Source_Residual(CGeometry *geometry, CSolver **solver_container, CNumerics *numerics, CNumerics *second_numerics,
                                   CConfig *config, unsigned short iMesh) {
#ifdef HAVE_MPI
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

    unsigned short iVar;
    unsigned long iPoint;
    bool implicit       = (config->GetKind_TimeIntScheme_Flow() == EULER_IMPLICIT);
    bool axisymmetric   = config->GetAxisymmetric();
    bool gravity        = (config->GetGravityForce() == YES);
    bool body_force       = config->GetBody_Force();
    bool rotating_frame = config->GetRotating_Frame();

    if (rotating_frame) {

        /*--- Loop over all points ---*/
        for (iPoint = 0; iPoint < nElem; iPoint++) {

            if(geometry->elem[iPoint]->GetDomain()){

                numerics->SetConservative(elem[iPoint]->GetSolution(),
                                          elem[iPoint]->GetSolution());
                numerics->SetVolume(geometry->elem[iPoint]->GetVolume());
                numerics->ComputeResidual(Residual, Jacobian_i, config);
                LinSysRes.AddBlock(iPoint, Residual);
                if (implicit) Jacobian.AddBlock(iPoint, iPoint, Jacobian_i);
            }
        }
    }

    if (body_force) {
        for (iPoint = 0; iPoint < nElemDomain; iPoint++) {

            numerics->SetConservative(elem[iPoint]->GetSolution(),
                                      elem[iPoint]->GetSolution());
            numerics->SetVolume(geometry->elem[iPoint]->GetVolume());
            numerics->ComputeResidual(Residual, config);
            LinSysRes.AddBlock(iPoint, Residual);
        }
    }

    if (axisymmetric) {
        if (implicit) {
            for (iVar = 0; iVar < nVar; iVar ++)
                for (unsigned short jVar = 0; jVar < nVar; jVar ++)
                    Jacobian_i[iVar][jVar] = 0.0;
        }

        for (iPoint = 0; iPoint < nElemDomain; iPoint++) {

            numerics->SetConservative(elem[iPoint]->GetSolution(), elem[iPoint]->GetSolution());

            //..Incompressible, Free Surface are not included..//

            numerics->SetVolume(geometry->elem[iPoint]->GetVolume());

            numerics->SetCoord(geometry->elem[iPoint]->GetCG(),geometry->elem[iPoint]->GetCG());

            numerics->ComputeResidual(Residual, Jacobian_i, config);

            LinSysRes.AddBlock(iPoint, Residual);

            if (implicit)
                Jacobian.AddBlock(iPoint, iPoint, Jacobian_i);
        }
    }

    if (gravity) {

        for (iPoint = 0; iPoint < nElemDomain; iPoint++) {

            numerics->SetConservative(elem[iPoint]->GetSolution(), elem[iPoint]->GetSolution());

            //..Incompressible, Free Surface are not included..//

            numerics->SetVolume(geometry->elem[iPoint]->GetVolume());

            numerics->ComputeResidual(Residual, config);

            LinSysRes.AddBlock(iPoint, Residual);

        }

    }
}

void CEulerSolver::Source_Template(CGeometry *geometry, CSolver **solver_container, CNumerics *numerics,
                                   CConfig *config, unsigned short iMesh) {

    /* This method should be used to call any new source terms for a particular problem*/
    /* This method calls the new child class in CNumerics, where the new source term should be implemented.  */

    /* Next we describe how to get access to some important quanties for this method */
    /* Access to all points in the current geometric mesh by saying: nPointDomain */
    /* Get the vector of conservative variables at some point iPoint = node[iPoint]->GetSolution() */
    /* Get the volume (or area in 2D) associated with iPoint = node[iPoint]->GetVolume() */
    /* Get the vector of geometric coordinates of point iPoint = node[iPoint]->GetCoord() */

}

void CEulerSolver::SetMax_Eigenvalue(CGeometry *geometry, CConfig *config) {

    double *Normal, Area, Mean_SoundSpeed = 0.0, Mean_ProjVel = 0.0, Mean_BetaInc2, Lambda, Mean_DensityInc;
    unsigned long iFace, iVertex, iPoint, jPoint;
    unsigned short iDim, iMarker;

    bool compressible = (config->GetKind_Regime() == COMPRESSIBLE);

    /*--- Set maximum inviscid eigenvalue to zero, and compute sound speed ---*/

    for (iPoint = 0; iPoint < nElemDomain; iPoint++) {
        elem[iPoint]->SetLambda(0.0);
    }

    /*--- Loop interior edges ---*/

    for(iFace = 0; iFace < geometry->GetnFace(); iFace++) {
        iPoint = geometry->face[iFace]->GetElems(0);
        if(geometry->face[iFace]->GetElems(1) != -1){

            jPoint = geometry->face[iFace]->GetElems(1);

            Normal = geometry->face[iFace]->GetNormal_Face();
            Area = 0.0; for (iDim = 0; iDim < nDim; iDim++) Area += Normal[iDim]*Normal[iDim]; Area = sqrt(Area);

            /*--- Mean Values ---*/

            if (compressible) {
                Mean_ProjVel = 0.5 * (elem[iPoint]->GetProjVel(Normal) + elem[jPoint]->GetProjVel(Normal));
                Mean_SoundSpeed = 0.5 * (elem[iPoint]->GetSoundSpeed() + elem[jPoint]->GetSoundSpeed()) * Area;
            }

            //..Incompressible, Free Surface are not included..//

            /*--- Inviscid contribution ---*/

            Lambda = fabs(Mean_ProjVel) + Mean_SoundSpeed;
            if (geometry->elem[iPoint]->GetDomain()) elem[iPoint]->AddLambda(Lambda);
            if (geometry->elem[jPoint]->GetDomain()) elem[jPoint]->AddLambda(Lambda);

        }
    }

    /*--- Loop boundary edges ---*/

    for (iMarker = 0; iMarker < geometry->GetnMarker(); iMarker++) {
        if(config->GetMarker_All_KindBC(iMarker) != SEND_RECEIVE){
            for (iVertex = 0; iVertex < geometry->GetnElem_Bound(iMarker); iVertex++) {

                iFace = geometry->bound[iMarker][iVertex]->GetGlobalFace();
                iPoint = geometry->face[iFace]->GetElems(0);
                Normal = geometry->face[iFace]->GetNormal_Face();
                Area = 0.0; for (iDim = 0; iDim < nDim; iDim++) Area += Normal[iDim]*Normal[iDim]; Area = sqrt(Area);

                /*--- Mean Values ---*/

                if (compressible) {
                    Mean_ProjVel = elem[iPoint]->GetProjVel(Normal);
                    Mean_SoundSpeed = elem[iPoint]->GetSoundSpeed() * Area;
                }

                //..Incompressible, Free Surface are not included..//

                /*--- Inviscid contribution ---*/

                Lambda = fabs(Mean_ProjVel) + Mean_SoundSpeed;
                if (geometry->elem[iPoint]->GetDomain()) {
                    elem[iPoint]->AddLambda(Lambda);
                }

            }
        }
    }

    /*--- MPI parallelization ---*/

    Set_MPI_MaxEigenvalue(geometry, config);

}

void CEulerSolver::SetUndivided_Laplacian(CGeometry *geometry, CConfig *config) {

    unsigned long iPoint, jPoint, iFace;
    double Pressure_i = 0, Pressure_j = 0, *Diff;
    unsigned short iVar;
    bool boundary_i, boundary_j;

    bool compressible = (config->GetKind_Regime() == COMPRESSIBLE);

    Diff = new double[nVar];

    for (iPoint = 0; iPoint < nElemDomain; iPoint++)
        elem[iPoint]->SetUnd_LaplZero();

    for(iFace = 0; iFace < geometry->GetnFace(); iFace++) {

        iPoint = geometry->face[iFace]->GetElems(0);

        if(geometry->face[iFace]->GetElems(1) != -1){

            jPoint = geometry->face[iFace]->GetElems(1);

            /*--- Solution differences ---*/

            for (iVar = 0; iVar < nVar; iVar++)
                Diff[iVar] = elem[iPoint]->GetSolution(iVar) - elem[jPoint]->GetSolution(iVar);

            /*--- Correction for compressible flows which use the enthalpy ---*/

            if (compressible) {
                Pressure_i = elem[iPoint]->GetPressure();
                Pressure_j = elem[jPoint]->GetPressure();
                Diff[nVar-1] = (elem[iPoint]->GetSolution(nVar-1) + Pressure_i) - (elem[jPoint]->GetSolution(nVar-1) + Pressure_j);
            }

            boundary_i = geometry->elem[iPoint]->GetPhysicalBoundary();
            boundary_j = geometry->elem[jPoint]->GetPhysicalBoundary();

            /*--- Both points inside the domain, or both in the boundary ---*/

            if ((!boundary_i && !boundary_j) || (boundary_i && boundary_j)) {
                if (geometry->elem[iPoint]->GetDomain()) elem[iPoint]->SubtractUnd_Lapl(Diff);
                if (geometry->elem[jPoint]->GetDomain()) elem[jPoint]->AddUnd_Lapl(Diff);
            }

            /*--- iPoint inside the domain, jPoint on the boundary ---*/

            if (!boundary_i && boundary_j)
                if (geometry->elem[iPoint]->GetDomain()) elem[iPoint]->SubtractUnd_Lapl(Diff);

            /*--- jPoint inside the domain, iPoint on the boundary ---*/

            if (boundary_i && !boundary_j)
                if (geometry->elem[jPoint]->GetDomain()) elem[jPoint]->AddUnd_Lapl(Diff);
        }

    }

    /*--- MPI parallelization ---*/

    Set_MPI_Undivided_Laplacian(geometry, config);
    //delete [] Diff;
}

void CEulerSolver::SetCentered_Dissipation_Sensor(CGeometry *geometry, CConfig *config) {

    unsigned long iFace, iPoint, jPoint;
    double Pressure_i = 0.0, Pressure_j = 0.0;
    bool boundary_i, boundary_j;

    /*--- Reset variables to store the undivided pressure ---*/

    for (iPoint = 0; iPoint < nElemDomain; iPoint++) {
        iPoint_UndLapl[iPoint] = 0.0;
        jPoint_UndLapl[iPoint] = 0.0;
    }

    /*--- Evaluate the pressure sensor ---*/

    for(iFace = 0; iFace < geometry->GetnFace(); iFace++) {

        iPoint = geometry->face[iFace]->GetElems(0);

        if(geometry->face[iFace]->GetElems(1) != -1){

            jPoint = geometry->face[iFace]->GetElems(1);

            Pressure_i = elem[iPoint]->GetPressure();
            Pressure_j = elem[jPoint]->GetPressure();

            boundary_i = geometry->elem[iPoint]->GetPhysicalBoundary();
            boundary_j = geometry->elem[jPoint]->GetPhysicalBoundary();

            /*--- Both points inside the domain, or both on the boundary ---*/

            if ((!boundary_i && !boundary_j) || (boundary_i && boundary_j)) {
                if (geometry->elem[iPoint]->GetDomain()) { iPoint_UndLapl[iPoint] += (Pressure_j - Pressure_i); jPoint_UndLapl[iPoint] += (Pressure_i + Pressure_j); }
                if (geometry->elem[jPoint]->GetDomain()) { iPoint_UndLapl[jPoint] += (Pressure_i - Pressure_j); jPoint_UndLapl[jPoint] += (Pressure_i + Pressure_j); }
            }

            /*--- iPoint inside the domain, jPoint on the boundary ---*/

            if (!boundary_i && boundary_j)
                if (geometry->elem[iPoint]->GetDomain()) { iPoint_UndLapl[iPoint] += (Pressure_j - Pressure_i); jPoint_UndLapl[iPoint] += (Pressure_i + Pressure_j); }

            /*--- jPoint inside the domain, iPoint on the boundary ---*/

            if (boundary_i && !boundary_j)
                if (geometry->elem[jPoint]->GetDomain()) { iPoint_UndLapl[jPoint] += (Pressure_i - Pressure_j); jPoint_UndLapl[jPoint] += (Pressure_i + Pressure_j); }

        }
    }

    /*--- Set pressure switch for each point ---*/

    for (iPoint = 0; iPoint < nElemDomain; iPoint++)
        elem[iPoint]->SetSensor(fabs(iPoint_UndLapl[iPoint]) / jPoint_UndLapl[iPoint]);

    /*--- MPI parallelization ---*/

    Set_MPI_Sensor(geometry, config);

}

void CEulerSolver::SetUpwind_Ducros_Sensor(CGeometry *geometry, CConfig *config){

    unsigned long iPoint, jPoint;
    unsigned short iNeigh, iDim;

    double *Vorticity;

    double uixi = 0.0, Ducros_i = 0.0, Ducros_j = 0.0, Omega = 0.0;

    for (iPoint = 0; iPoint < geometry->GetnElem(); iPoint++){

        uixi=0.0;
        for(iDim = 0; iDim < nDim; iDim++){
            uixi += elem[iPoint]->GetGradient_Primitive(iDim+1, iDim);
        }

        /*--- Compute norm of vorticity ---*/

        Vorticity = elem[iPoint]->GetVorticity();
        Omega = 0.0;
        for (iDim = 0; iDim < nDim; iDim++){
            Omega += Vorticity[iDim]*Vorticity[iDim];
        }
        Omega = sqrt(Omega);

        /*---- Ducros sensor for iPoint ---*/

        if (config->GetKind_RoeLowDiss() == FD_DUCROS){
            Ducros_i = -uixi / (fabs(uixi) + Omega + 1e-20);
        } else if (config->GetKind_RoeLowDiss() == NTS_DUCROS){
            Ducros_i = pow(uixi,2.0) /(pow(uixi,2.0)+ pow(Omega,2.0) + 1e-20);
        }

        elem[iPoint]->SetSensor(Ducros_i);

        /*---- Ducros sensor for neighbor points of iPoint to avoid lower the dissipation in regions near the shock ---*/

        for (iNeigh = 0; iNeigh > geometry->elem[iPoint]->GetnNeighbor_Cell(); iNeigh++){

            jPoint = geometry->elem[iPoint]->GetNeighbor_Cell(iNeigh);

            /*---- Dilatation for jPoint ---*/

            uixi=0.0;
            for(iDim = 0; iDim < nDim; iDim++){
                uixi += elem[jPoint]->GetGradient_Primitive(iDim+1, iDim);
            }

            /*--- Compute norm of vorticity ---*/

            Vorticity = elem[jPoint]->GetVorticity();
            Omega = 0.0;
            for (iDim = 0; iDim < nDim; iDim++){
                Omega += Vorticity[iDim]*Vorticity[iDim];
            }
            Omega = sqrt(Omega);

            if (config->GetKind_RoeLowDiss() == FD_DUCROS){
                Ducros_j = -uixi / (fabs(uixi) + Omega + 1e-20);
            } else if (config->GetKind_RoeLowDiss() == NTS_DUCROS){
                Ducros_j = pow(uixi,2.0) /(pow(uixi,2.0)+ pow(Omega,2.0) + 1e-20);
            }
            elem[iPoint]->SetSensor(max(elem[iPoint]->GetSensor(), Ducros_j));

        }
    }

    Set_MPI_Sensor(geometry, config);

}

void CEulerSolver::Inviscid_Forces(CGeometry *geometry, CConfig *config) {
    unsigned long iVertex, iPoint, iFace;
    unsigned short iDim, iMarker, Boundary, Monitoring, iMarker_Monitoring;
    double Pressure = 0.0, MomentDist[3] = {0.0,0.0,0.0}, *Coord, Area, V_n2,
            factor, NFPressOF, RefVel2, RefTemp, RefDensity, RefPressure,
            UnitNormal[3] = {0.0,0.0,0.0}, Force[3] = {0.0,0.0,0.0};
    double *Normal, *Coord_f;
    string Marker_Tag, Monitoring_Tag;

    int rank = MASTER_NODE;
#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

#ifdef HAVE_MPI
    double MyAllBound_CDrag_Inv, MyAllBound_CLift_Inv, MyAllBound_CSideForce_Inv, MyAllBound_CEff_Inv, MyAllBound_CMx_Inv, MyAllBound_CMy_Inv, MyAllBound_CMz_Inv, MyAllBound_CFx_Inv, MyAllBound_CFy_Inv, MyAllBound_CFz_Inv, MyAllBound_CT_Inv, MyAllBound_CQ_Inv, MyAllBound_CMerit_Inv, MyAllBound_CNearFieldOF_Inv, *MySurface_CLift_Inv = NULL, *MySurface_CDrag_Inv = NULL, *MySurface_CSideForce_Inv = NULL, *MySurface_CEff_Inv = NULL, *MySurface_CFx_Inv = NULL, *MySurface_CFy_Inv = NULL, *MySurface_CFz_Inv = NULL, *MySurface_CMx_Inv = NULL, *MySurface_CMy_Inv = NULL, *MySurface_CMz_Inv = NULL;
#endif

    double Alpha            = config->GetAoA()*PI_NUMBER/180.0;
    double Beta             = config->GetAoS()*PI_NUMBER/180.0;
    double RefAreaCoeff     = config->GetRefAreaCoeff();
    double RefLengthMoment  = config->GetRefLengthMoment();
    double *Origin          = config->GetRefOriginMoment(0);
    bool compressible       = (config->GetKind_Regime() == COMPRESSIBLE);

    RefTemp     = Temperature_Inf;
    RefDensity  = Density_Inf;
    RefPressure = Pressure_Inf;

    //..Grid Movements are not included..//

        RefVel2 = 0.0;
        for (iDim = 0; iDim < nDim; iDim++)
            RefVel2  += Velocity_Inf[iDim]*Velocity_Inf[iDim];

    factor = 1.0 / (0.5*RefDensity*RefAreaCoeff*RefVel2);

    Total_CDrag = 0.0;        Total_CLift = 0.0; Total_CSideForce = 0.0; Total_CEff = 0.0;
    Total_CMx = 0.0;          Total_CMy = 0.0;   Total_CMz = 0.0;
    Total_CFx = 0.0;          Total_CFy = 0.0;   Total_CFz = 0.0;
    Total_CT = 0.0;           Total_CQ = 0.0;    Total_CMerit = 0.0;
    Total_CNearFieldOF = 0.0; Total_Heat = 0.0;  Total_MaxHeat = 0.0;

    AllBound_CDrag_Inv = 0.0;        AllBound_CLift_Inv = 0.0; AllBound_CSideForce_Inv = 0.0;
    AllBound_CMx_Inv = 0.0;          AllBound_CMy_Inv = 0.0;   AllBound_CMz_Inv = 0.0;
    AllBound_CFx_Inv = 0.0;          AllBound_CFy_Inv = 0.0;   AllBound_CFz_Inv = 0.0;
    AllBound_CT_Inv = 0.0;           AllBound_CQ_Inv = 0.0;    AllBound_CMerit_Inv = 0.0;
    AllBound_CNearFieldOF_Inv = 0.0; AllBound_CEff_Inv = 0.0;

    for (iMarker_Monitoring = 0; iMarker_Monitoring < config->GetnMarker_Monitoring(); iMarker_Monitoring++) {
        Surface_CLift_Inv[iMarker_Monitoring]      = 0.0; Surface_CDrag_Inv[iMarker_Monitoring]      = 0.0;
        Surface_CSideForce_Inv[iMarker_Monitoring] = 0.0; Surface_CEff_Inv[iMarker_Monitoring]       = 0.0;
        Surface_CFx_Inv[iMarker_Monitoring]        = 0.0; Surface_CFy_Inv[iMarker_Monitoring]        = 0.0;
        Surface_CFz_Inv[iMarker_Monitoring]        = 0.0; Surface_CMx_Inv[iMarker_Monitoring]        = 0.0;
        Surface_CMy_Inv[iMarker_Monitoring]        = 0.0; Surface_CMz_Inv[iMarker_Monitoring]        = 0.0;
        Surface_CLift[iMarker_Monitoring]          = 0.0; Surface_CDrag[iMarker_Monitoring]          = 0.0;
        Surface_CSideForce[iMarker_Monitoring]     = 0.0; Surface_CEff[iMarker_Monitoring]           = 0.0;
        Surface_CFx[iMarker_Monitoring]            = 0.0; Surface_CFy[iMarker_Monitoring]            = 0.0;
        Surface_CFz[iMarker_Monitoring]            = 0.0; Surface_CMx[iMarker_Monitoring]            = 0.0;
        Surface_CMy[iMarker_Monitoring]            = 0.0; Surface_CMz[iMarker_Monitoring]            = 0.0;
    }

    for (iMarker = 0; iMarker < nMarker; iMarker++) {

        Boundary   = config->GetMarker_All_KindBC(iMarker);
        Monitoring = config->GetMarker_All_Monitoring(iMarker);

        if (Monitoring == YES) {
            for (iMarker_Monitoring = 0; iMarker_Monitoring < config->GetnMarker_Monitoring(); iMarker_Monitoring++) {

                Monitoring_Tag = config->GetMarker_Monitoring(iMarker_Monitoring);
                Marker_Tag = config->GetMarker_All_TagBound(iMarker);
                if (Marker_Tag == Monitoring_Tag)
                    Origin = config->GetRefOriginMoment(iMarker_Monitoring);
            }
        }

        if((Boundary == EULER_WALL) || (Boundary == HEAT_FLUX) || (Boundary == ISOTHERMAL) || (Boundary == NEARFIELD_BOUNDARY)) {

            CDrag_Inv[iMarker] = 0.0;        CLift_Inv[iMarker] = 0.0; CSideForce_Inv[iMarker] = 0.0;
            CMx_Inv[iMarker] = 0.0;          CMy_Inv[iMarker] = 0.0;   CMz_Inv[iMarker] = 0.0;
            CFx_Inv[iMarker] = 0.0;          CFy_Inv[iMarker] = 0.0;   CFz_Inv[iMarker] = 0.0;
            CT_Inv[iMarker] = 0.0;           CQ_Inv[iMarker] = 0.0;    CMerit_Inv[iMarker] = 0.0;
            CNearFieldOF_Inv[iMarker] = 0.0; CEff_Inv[iMarker] = 0.0;

            for (iDim = 0; iDim < nDim; iDim++) ForceInviscid[iDim] = 0.0;
            MomentInviscid[0] = 0.0; MomentInviscid[1] = 0.0; MomentInviscid[2] = 0.0;
            NFPressOF = 0.0;

            for (iVertex = 0; iVertex < nElem_Bound[iMarker]; iVertex++) {

                iFace = geometry->bound[iMarker][iVertex]->GetGlobalFace();
                iPoint = geometry->face[iFace]->GetElems(0);
                Coord_f = geometry->face[iFace]->GetCG();
                Coord   = geometry->elem[iPoint]->GetCG();
                Normal = geometry->face[iFace]->GetNormal_Face();

                Area = 0.0; for (iDim = 0; iDim < nDim; iDim++) Area += Normal[iDim]*Normal[iDim]; Area = sqrt(Area);

                for (iDim = 0; iDim < nDim; iDim++) UnitNormal[iDim] = Normal[iDim]/Area;

                V_n2 = 0.0; for (iDim = 0; iDim < nDim; iDim++)
                     V_n2 += elem[iPoint]->GetSolution(iDim+1)*elem[iPoint]->GetSolution(iDim+1);

                if (compressible)   Pressure = elem[iPoint]->GetPressure();

                //..Incompressible, Free Surface are not included..//

                CPressure[iMarker][iVertex] = (Pressure - RefPressure)*factor*RefAreaCoeff;

                if ( (geometry->elem[iPoint]->GetDomain())&& (Monitoring == YES) ) {

                    NFPressOF += 0.5*(Pressure - Pressure_Inf)*(Pressure - Pressure_Inf)*Normal[nDim-1];

                    for (iDim = 0; iDim < nDim; iDim++) {
                        MomentDist[iDim] = Coord_f[iDim] - Origin[iDim];
                    }

                    for (iDim = 0; iDim < nDim; iDim++) {
                        Force[iDim] = -(Pressure - Pressure_Inf)*Normal[iDim]*factor;
                        ForceInviscid[iDim] += Force[iDim];
                    }

                    if (nDim == 3) {
                        MomentInviscid[0] += (Force[2]*MomentDist[1]-Force[1]*MomentDist[2])/RefLengthMoment;
                        MomentInviscid[1] += (Force[0]*MomentDist[2]-Force[2]*MomentDist[0])/RefLengthMoment;
                    }
                    MomentInviscid[2] += (Force[1]*MomentDist[0]-Force[0]*MomentDist[1])/RefLengthMoment;
                }
            }

            if  (Monitoring == YES) {
                if (Boundary != NEARFIELD_BOUNDARY) {
                    if (nDim == 2) {
                        CDrag_Inv[iMarker]  =  ForceInviscid[0]*cos(Alpha) + ForceInviscid[1]*sin(Alpha);
                        CLift_Inv[iMarker]  = -ForceInviscid[0]*sin(Alpha) + ForceInviscid[1]*cos(Alpha);
                        CEff_Inv[iMarker]   = CLift_Inv[iMarker] / (CDrag_Inv[iMarker]+EPS);
                        CMz_Inv[iMarker]    = MomentInviscid[2];
                        CFx_Inv[iMarker]    = ForceInviscid[0];
                        CFy_Inv[iMarker]    = ForceInviscid[1];
                        CT_Inv[iMarker]     = -CFx_Inv[iMarker];
                        CQ_Inv[iMarker]     = -CMz_Inv[iMarker];
                        CMerit_Inv[iMarker] = CT_Inv[iMarker] / (CQ_Inv[iMarker] + EPS);
                    }
                    if (nDim == 3) {
                        CDrag_Inv[iMarker]      =  -(ForceInviscid[0]*cos(Alpha)*cos(Beta) + ForceInviscid[1]*sin(Beta) + ForceInviscid[2]*sin(Alpha)*cos(Beta));
                        CLift_Inv[iMarker]      = -(-ForceInviscid[0]*sin(Alpha) + ForceInviscid[2]*cos(Alpha));
                        CSideForce_Inv[iMarker] = -ForceInviscid[0]*sin(Beta)*cos(Alpha) + ForceInviscid[1]*cos(Beta) - ForceInviscid[2]*sin(Beta)*sin(Alpha);
                        CEff_Inv[iMarker]       = CLift_Inv[iMarker] / (CDrag_Inv[iMarker] + EPS);
                        CMx_Inv[iMarker]        = MomentInviscid[0];
                        CMy_Inv[iMarker]        = MomentInviscid[1];
                        CMz_Inv[iMarker]        = MomentInviscid[2];
                        CFx_Inv[iMarker]        = ForceInviscid[0];
                        CFy_Inv[iMarker]        = ForceInviscid[1];
                        CFz_Inv[iMarker]        = ForceInviscid[2];
                        CT_Inv[iMarker]         = -CFz_Inv[iMarker];
                        CQ_Inv[iMarker]         = -CMz_Inv[iMarker];
                        CMerit_Inv[iMarker]     = CT_Inv[iMarker] / (CQ_Inv[iMarker] + EPS);
                    }

                    AllBound_CDrag_Inv        += CDrag_Inv[iMarker];
                    AllBound_CLift_Inv        += CLift_Inv[iMarker];
                    AllBound_CSideForce_Inv   += CSideForce_Inv[iMarker];
                    AllBound_CEff_Inv          = AllBound_CLift_Inv / (AllBound_CDrag_Inv + EPS);
                    AllBound_CMx_Inv          += CMx_Inv[iMarker];
                    AllBound_CMy_Inv          += CMy_Inv[iMarker];
                    AllBound_CMz_Inv          += CMz_Inv[iMarker];
                    AllBound_CFx_Inv          += CFx_Inv[iMarker];
                    AllBound_CFy_Inv          += CFy_Inv[iMarker];
                    AllBound_CFz_Inv          += CFz_Inv[iMarker];
                    AllBound_CT_Inv           += CT_Inv[iMarker];
                    AllBound_CQ_Inv           += CQ_Inv[iMarker];
                    AllBound_CMerit_Inv        = AllBound_CT_Inv / (AllBound_CQ_Inv + EPS);

                    for (iMarker_Monitoring = 0; iMarker_Monitoring < config->GetnMarker_Monitoring(); iMarker_Monitoring++) {
                        Monitoring_Tag = config->GetMarker_Monitoring(iMarker_Monitoring);
                        Marker_Tag = config->GetMarker_All_TagBound(iMarker);
                        if (Marker_Tag == Monitoring_Tag) {
                            Surface_CLift_Inv[iMarker_Monitoring]      += CLift_Inv[iMarker];
                            Surface_CDrag_Inv[iMarker_Monitoring]      += CDrag_Inv[iMarker];
                            Surface_CSideForce_Inv[iMarker_Monitoring] += CSideForce_Inv[iMarker];
                            Surface_CEff_Inv[iMarker_Monitoring]        = CLift_Inv[iMarker] / (CDrag_Inv[iMarker] + EPS);
                            Surface_CFx_Inv[iMarker_Monitoring]        += CFx_Inv[iMarker];
                            Surface_CFy_Inv[iMarker_Monitoring]        += CFy_Inv[iMarker];
                            Surface_CFz_Inv[iMarker_Monitoring]        += CFz_Inv[iMarker];
                            Surface_CMx_Inv[iMarker_Monitoring]        += CMx_Inv[iMarker];
                            Surface_CMy_Inv[iMarker_Monitoring]        += CMy_Inv[iMarker];
                            Surface_CMz_Inv[iMarker_Monitoring]        += CMz_Inv[iMarker];
                        }
                    }

                }

                else {
                    CNearFieldOF_Inv[iMarker] = NFPressOF;
                    AllBound_CNearFieldOF_Inv += CNearFieldOF_Inv[iMarker];
                }

            }

        }
    }


#ifdef HAVE_MPI

    /*--- Add AllBound information using all the nodes ---*/

    MyAllBound_CDrag_Inv        = AllBound_CDrag_Inv;        AllBound_CDrag_Inv = 0.0;
    MyAllBound_CLift_Inv        = AllBound_CLift_Inv;        AllBound_CLift_Inv = 0.0;
    MyAllBound_CSideForce_Inv   = AllBound_CSideForce_Inv;   AllBound_CSideForce_Inv = 0.0;
    MyAllBound_CEff_Inv         = AllBound_CEff_Inv;         AllBound_CEff_Inv = 0.0;
    MyAllBound_CMx_Inv          = AllBound_CMx_Inv;          AllBound_CMx_Inv = 0.0;
    MyAllBound_CMy_Inv          = AllBound_CMy_Inv;          AllBound_CMy_Inv = 0.0;
    MyAllBound_CMz_Inv          = AllBound_CMz_Inv;          AllBound_CMz_Inv = 0.0;
    MyAllBound_CFx_Inv          = AllBound_CFx_Inv;          AllBound_CFx_Inv = 0.0;
    MyAllBound_CFy_Inv          = AllBound_CFy_Inv;          AllBound_CFy_Inv = 0.0;
    MyAllBound_CFz_Inv          = AllBound_CFz_Inv;          AllBound_CFz_Inv = 0.0;
    MyAllBound_CT_Inv           = AllBound_CT_Inv;           AllBound_CT_Inv = 0.0;
    MyAllBound_CQ_Inv           = AllBound_CQ_Inv;           AllBound_CQ_Inv = 0.0;
    MyAllBound_CMerit_Inv       = AllBound_CMerit_Inv;       AllBound_CMerit_Inv = 0.0;
    MyAllBound_CNearFieldOF_Inv = AllBound_CNearFieldOF_Inv; AllBound_CNearFieldOF_Inv = 0.0;

    MPI_Allreduce(&MyAllBound_CDrag_Inv, &AllBound_CDrag_Inv, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&MyAllBound_CLift_Inv, &AllBound_CLift_Inv, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&MyAllBound_CSideForce_Inv, &AllBound_CSideForce_Inv, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    AllBound_CEff_Inv = AllBound_CLift_Inv / (AllBound_CDrag_Inv + EPS);
    MPI_Allreduce(&MyAllBound_CMx_Inv, &AllBound_CMx_Inv, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&MyAllBound_CMy_Inv, &AllBound_CMy_Inv, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&MyAllBound_CMz_Inv, &AllBound_CMz_Inv, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&MyAllBound_CFx_Inv, &AllBound_CFx_Inv, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&MyAllBound_CFy_Inv, &AllBound_CFy_Inv, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&MyAllBound_CFz_Inv, &AllBound_CFz_Inv, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&MyAllBound_CT_Inv, &AllBound_CT_Inv, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&MyAllBound_CQ_Inv, &AllBound_CQ_Inv, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    AllBound_CMerit_Inv = AllBound_CT_Inv / (AllBound_CQ_Inv + EPS);
    MPI_Allreduce(&MyAllBound_CNearFieldOF_Inv, &AllBound_CNearFieldOF_Inv, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);

    /*--- Add the forces on the surfaces using all the nodes ---*/

    MySurface_CLift_Inv      = new double[config->GetnMarker_Monitoring()];
    MySurface_CDrag_Inv      = new double[config->GetnMarker_Monitoring()];
    MySurface_CSideForce_Inv = new double[config->GetnMarker_Monitoring()];
    MySurface_CEff_Inv       = new double[config->GetnMarker_Monitoring()];
    MySurface_CFx_Inv        = new double[config->GetnMarker_Monitoring()];
    MySurface_CFy_Inv        = new double[config->GetnMarker_Monitoring()];
    MySurface_CFz_Inv        = new double[config->GetnMarker_Monitoring()];
    MySurface_CMx_Inv        = new double[config->GetnMarker_Monitoring()];
    MySurface_CMy_Inv        = new double[config->GetnMarker_Monitoring()];
    MySurface_CMz_Inv        = new double[config->GetnMarker_Monitoring()];

    for (iMarker_Monitoring = 0; iMarker_Monitoring < config->GetnMarker_Monitoring(); iMarker_Monitoring++) {
        MySurface_CLift_Inv[iMarker_Monitoring]      = Surface_CLift_Inv[iMarker_Monitoring];
        MySurface_CDrag_Inv[iMarker_Monitoring]      = Surface_CDrag_Inv[iMarker_Monitoring];
        MySurface_CSideForce_Inv[iMarker_Monitoring] = Surface_CSideForce_Inv[iMarker_Monitoring];
        MySurface_CEff_Inv[iMarker_Monitoring]       = Surface_CEff_Inv[iMarker_Monitoring];
        MySurface_CFx_Inv[iMarker_Monitoring]        = Surface_CFx_Inv[iMarker_Monitoring];
        MySurface_CFy_Inv[iMarker_Monitoring]        = Surface_CFy_Inv[iMarker_Monitoring];
        MySurface_CFz_Inv[iMarker_Monitoring]        = Surface_CFz_Inv[iMarker_Monitoring];
        MySurface_CMx_Inv[iMarker_Monitoring]        = Surface_CMx_Inv[iMarker_Monitoring];
        MySurface_CMy_Inv[iMarker_Monitoring]        = Surface_CMy_Inv[iMarker_Monitoring];
        MySurface_CMz_Inv[iMarker_Monitoring]        = Surface_CMz_Inv[iMarker_Monitoring];

        Surface_CLift_Inv[iMarker_Monitoring]      = 0.0;
        Surface_CDrag_Inv[iMarker_Monitoring]      = 0.0;
        Surface_CSideForce_Inv[iMarker_Monitoring] = 0.0;
        Surface_CEff_Inv[iMarker_Monitoring]       = 0.0;
        Surface_CFx_Inv[iMarker_Monitoring]        = 0.0;
        Surface_CFy_Inv[iMarker_Monitoring]        = 0.0;
        Surface_CFz_Inv[iMarker_Monitoring]        = 0.0;
        Surface_CMx_Inv[iMarker_Monitoring]        = 0.0;
        Surface_CMy_Inv[iMarker_Monitoring]        = 0.0;
        Surface_CMz_Inv[iMarker_Monitoring]        = 0.0;
    }

    MPI_Allreduce(MySurface_CLift_Inv, Surface_CLift_Inv, config->GetnMarker_Monitoring(), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(MySurface_CDrag_Inv, Surface_CDrag_Inv, config->GetnMarker_Monitoring(), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(MySurface_CSideForce_Inv, Surface_CSideForce_Inv, config->GetnMarker_Monitoring(), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    for (iMarker_Monitoring = 0; iMarker_Monitoring < config->GetnMarker_Monitoring(); iMarker_Monitoring++)
        Surface_CEff_Inv[iMarker_Monitoring] = Surface_CLift_Inv[iMarker_Monitoring] / (Surface_CDrag_Inv[iMarker_Monitoring] + EPS);
    MPI_Allreduce(MySurface_CFx_Inv, Surface_CFx_Inv, config->GetnMarker_Monitoring(), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(MySurface_CFy_Inv, Surface_CFy_Inv, config->GetnMarker_Monitoring(), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(MySurface_CFz_Inv, Surface_CFz_Inv, config->GetnMarker_Monitoring(), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(MySurface_CMx_Inv, Surface_CMx_Inv, config->GetnMarker_Monitoring(), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(MySurface_CMy_Inv, Surface_CMy_Inv, config->GetnMarker_Monitoring(), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(MySurface_CMz_Inv, Surface_CMz_Inv, config->GetnMarker_Monitoring(), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);

    delete [] MySurface_CLift_Inv; delete [] MySurface_CDrag_Inv;
    delete [] MySurface_CSideForce_Inv; delete [] MySurface_CEff_Inv;
    delete [] MySurface_CFx_Inv; delete [] MySurface_CFy_Inv;
    delete [] MySurface_CFz_Inv; delete [] MySurface_CMx_Inv;
    delete [] MySurface_CMy_Inv; delete [] MySurface_CMz_Inv;

#endif


    Total_CDrag         = AllBound_CDrag_Inv;
    Total_CLift         = AllBound_CLift_Inv;
    Total_CSideForce    = AllBound_CSideForce_Inv;
    Total_CEff          = Total_CLift / (Total_CDrag + EPS);
    Total_CMx           = AllBound_CMx_Inv;
    Total_CMy           = AllBound_CMy_Inv;
    Total_CMz           = AllBound_CMz_Inv;
    Total_CFx           = AllBound_CFx_Inv;
    Total_CFy           = AllBound_CFy_Inv;
    Total_CFz           = AllBound_CFz_Inv;
    Total_CT            = AllBound_CT_Inv;
    Total_CQ            = AllBound_CQ_Inv;
    Total_CMerit        = Total_CT / (Total_CQ + EPS);
    Total_CNearFieldOF  = AllBound_CNearFieldOF_Inv;

    for (iMarker_Monitoring = 0; iMarker_Monitoring < config->GetnMarker_Monitoring(); iMarker_Monitoring++) {
        Surface_CLift[iMarker_Monitoring]      = Surface_CLift_Inv[iMarker_Monitoring];
        Surface_CDrag[iMarker_Monitoring]      = Surface_CDrag_Inv[iMarker_Monitoring];
        Surface_CSideForce[iMarker_Monitoring] = Surface_CSideForce_Inv[iMarker_Monitoring];
        Surface_CEff[iMarker_Monitoring]       = Surface_CLift_Inv[iMarker_Monitoring] / (Surface_CDrag_Inv[iMarker_Monitoring] + EPS);
        Surface_CFx[iMarker_Monitoring]        = Surface_CFx_Inv[iMarker_Monitoring];
        Surface_CFy[iMarker_Monitoring]        = Surface_CFy_Inv[iMarker_Monitoring];
        Surface_CFz[iMarker_Monitoring]        = Surface_CFz_Inv[iMarker_Monitoring];
        Surface_CMx[iMarker_Monitoring]        = Surface_CMx_Inv[iMarker_Monitoring];
        Surface_CMy[iMarker_Monitoring]        = Surface_CMy_Inv[iMarker_Monitoring];
        Surface_CMz[iMarker_Monitoring]        = Surface_CMz_Inv[iMarker_Monitoring];
    }
    //delete [] Normal;

}

void CEulerSolver::ExplicitRK_Iteration(CGeometry *geometry, CSolver **solver_container,
                                        CConfig *config, unsigned short iRKStep) {
    double *Residual, *Res_TruncError, Vol, Delta, Res;
    unsigned short iVar;
    unsigned long iPoint;

    double RK_AlphaCoeff = config->Get_Alpha_RKStep(iRKStep);
    bool adjoint = config->GetAdjoint();

    for (iVar = 0; iVar < nVar; iVar++) {
        SetRes_RMS(iVar, 0.0);
        SetRes_Max(iVar, 0.0, 0);
    }

    /*--- Update the solution ---*/

    for (iPoint = 0; iPoint < nElemDomain; iPoint++) {
        Vol = geometry->elem[iPoint]->GetVolume();
        Delta = elem[iPoint]->GetDelta_Time() / Vol;

        Res_TruncError = elem[iPoint]->GetResTruncError();
        Residual = LinSysRes.GetBlock(iPoint);

        if (!adjoint) {
            for (iVar = 0; iVar < nVar; iVar++) {
                Res = Residual[iVar] + Res_TruncError[iVar];
                elem[iPoint]->AddSolution(iVar, -Res*Delta*RK_AlphaCoeff);
                AddRes_RMS(iVar, Res*Res);
                AddRes_Max(iVar, fabs(Res), geometry->elem[iPoint]->GetGlobalIndex(), geometry->elem[iPoint]->GetCG());
            }
        }

    }

    /*--- MPI solution ---*/

    Set_MPI_Solution(geometry, config);

    /*--- Compute the root mean square residual ---*/

    SetResidual_RMS(geometry, config);

}

void CEulerSolver::ExplicitEuler_Iteration(CGeometry *geometry, CSolver **solver_container, CConfig *config) {
    double *local_Residual, *local_Res_TruncError, Vol, Delta, Res;
    unsigned short iVar, iDim;
    unsigned long iPoint;

    bool adjoint = config->GetAdjoint();

    for (iVar = 0; iVar < nVar; iVar++) {
        SetRes_RMS(iVar, 0.0);
        SetRes_Max(iVar, 0.0, 0);
    }

    /*--- Update the solution ---*/

    for (iPoint = 0; iPoint < nElemDomain; iPoint++) {
        Vol = geometry->elem[iPoint]->GetVolume();
        Delta = elem[iPoint]->GetDelta_Time() / Vol;
        local_Res_TruncError = elem[iPoint]->GetResTruncError();
        local_Residual = LinSysRes.GetBlock(iPoint);

        if (!adjoint) {
            for (iVar = 0; iVar < nVar; iVar++) {
                Res = local_Residual[iVar] + local_Res_TruncError[iVar];
                elem[iPoint]->AddSolution(iVar, -Res*Delta);
                AddRes_RMS(iVar, Res*Res);
                AddRes_Max(iVar, fabs(Res), geometry->elem[iPoint]->GetGlobalIndex(), geometry->elem[iPoint]->GetCG());
            }
        }

    }

    /*--- MPI solution ---*/

    Set_MPI_Solution(geometry, config);

    /*--- Compute the root mean square residual ---*/

    SetResidual_RMS(geometry, config);

}

void CEulerSolver::ImplicitEuler_Iteration(CGeometry *geometry, CSolver **solver_container, CConfig *config) {
    int rank = MASTER_NODE;
#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif
    unsigned short iVar, jVar, iDim;
    unsigned long iPoint, total_index, IterLinSol = 0;
    double Delta, *local_Res_TruncError, Vol;

    bool adjoint = config->GetAdjoint();
    bool roe_turkel = config->GetKind_Upwind_Flow() == TURKEL;

    for (iVar = 0; iVar < nVar; iVar++) {
        SetRes_RMS(iVar, 0.0);
        SetRes_Max(iVar, 0.0, 0);
    }

    for (iPoint = 0; iPoint < nElemDomain; iPoint++) {
        local_Res_TruncError = elem[iPoint]->GetResTruncError();
        Vol = geometry->elem[iPoint]->GetVolume();

        if (elem[iPoint]->GetDelta_Time() != 0.0) {
            Delta = Vol / elem[iPoint]->GetDelta_Time();

            if (roe_turkel) {
                SetPreconditioner(config, iPoint);
                for (iVar = 0; iVar < nVar; iVar ++ )
                    for (jVar = 0; jVar < nVar; jVar ++ )
                        LowMach_Precontioner[iVar][jVar] = Delta*LowMach_Precontioner[iVar][jVar];
                Jacobian.AddBlock(iPoint, iPoint, LowMach_Precontioner);
            }
            else {
                Jacobian.AddVal2Diag(iPoint, Delta);
            }
        }
        else {
            Jacobian.SetVal2Diag(iPoint, 1.0);
            for (iVar = 0; iVar < nVar; iVar++) {
                total_index = iPoint*nVar + iVar;
                LinSysRes[total_index] = 0.0;
                local_Res_TruncError[iVar] = 0.0;
            }
        }

        for (iVar = 0; iVar < nVar; iVar++) {
            total_index = iPoint*nVar + iVar;
            LinSysRes[total_index] = -(LinSysRes[total_index] + local_Res_TruncError[iVar]);
            LinSysSol[total_index] = 0.0;
            AddRes_RMS(iVar, LinSysRes[total_index]*LinSysRes[total_index]);
            AddRes_Max(iVar, fabs(LinSysRes[total_index]), geometry->elem[iPoint]->GetGlobalIndex(), geometry->elem[iPoint]->GetCG());
        }
    }

    for (iPoint = nElemDomain; iPoint < nElem; iPoint++) {
        for (iVar = 0; iVar < nVar; iVar++) {
            total_index = iPoint*nVar + iVar;
            LinSysRes[total_index] = 0.0;
            LinSysSol[total_index] = 0.0;
        }
    }

    CSysSolve system;
    IterLinSol = system.Solve(Jacobian, LinSysRes, LinSysSol, geometry, config);
    SetIterLinSolver(IterLinSol);

    if (!adjoint) {
        for (iPoint = 0; iPoint < nElemDomain; iPoint++) {
            for (iVar = 0; iVar < nVar; iVar++) {
                elem[iPoint]->AddSolution(iVar, config->GetRelaxation_Factor_Flow()*LinSysSol[iPoint*nVar+iVar]);
            }
        }
    }

    Set_MPI_Solution(geometry, config);
    SetResidual_RMS(geometry, config);

    for(iVar = 0; iVar < nVar; iVar++){ Residual[iVar] = 0.0; Res_Conv[iVar] = 0.0;}

}

void CEulerSolver::SetPrimitive_Gradient_GG(CGeometry *geometry, CConfig *config) {

    unsigned long iPoint, jPoint, iFace, iVertex;
    unsigned short iDim, iVar, iMarker;
    double *PrimVar_Vertex, *PrimVar_i, *PrimVar_j, PrimVar_Average,
            Partial_Gradient, Partial_Res, Area;
    double *Normal = new double[nDim];
    double UnitNormal[3], Velocity_i[3], ProjVelocity_i;
    unsigned short Boundary;

    /*--- Gradient primitive variables compressible (temp, vx, vy, vz, P, rho)
       Gradient primitive variables incompressible (rho, vx, vy, vz, beta) ---*/
    PrimVar_Vertex = new double [nPrimVarGrad];
    PrimVar_i = new double [nPrimVarGrad];
    PrimVar_j = new double [nPrimVarGrad];

    /*--- Set Gradient_Primitive to zero ---*/
    for (iPoint = 0; iPoint < nElemDomain; iPoint++){
        elem[iPoint]->SetGradient_PrimitiveZero(nPrimVarGrad);
    }

    /*--- Loop interior edges ---*/
    for (iFace = 0; iFace < geometry->GetnFace(); iFace++) {
        iPoint = geometry->face[iFace]->GetElems(0);
        if(geometry->face[iFace]->GetElems(1) != -1){

            jPoint = geometry->face[iFace]->GetElems(1);
            Normal = geometry->face[iFace]->GetNormal_Face();

            for (iVar = 0; iVar < nPrimVarGrad; iVar++) {
                PrimVar_i[iVar] = elem[iPoint]->GetPrimitive(iVar);
                PrimVar_j[iVar] = elem[jPoint]->GetPrimitive(iVar);
            }

            for (iVar = 0; iVar < nPrimVarGrad; iVar++) {
                PrimVar_Average =  0.5 * ( PrimVar_i[iVar] + PrimVar_j[iVar] );
                for (iDim = 0; iDim < nDim; iDim++) {
                    Partial_Res = PrimVar_Average*Normal[iDim];
                    if (geometry->elem[iPoint]->GetDomain())
                        elem[iPoint]->AddGradient_Primitive(iVar, iDim, Partial_Res);
                    if (geometry->elem[jPoint]->GetDomain()){
                        elem[jPoint]->SubtractGradient_Primitive(iVar, iDim, Partial_Res);
                    }
                }
            }
        }
    }

    for (iMarker = 0; iMarker < geometry->GetnMarker(); iMarker++) {
        if(config->GetMarker_All_KindBC(iMarker) != SEND_RECEIVE){
            Boundary   = config->GetMarker_All_KindBC(iMarker);
            for (iVertex = 0; iVertex < geometry->GetnElem_Bound(iMarker); iVertex++) {

                iFace = geometry->bound[iMarker][iVertex]->GetGlobalFace();
                iPoint = geometry->face[iFace]->GetElems(0);
                Normal = geometry->face[iFace]->GetNormal_Face();

                Area = 0.0; for (iDim = 0; iDim < nDim; iDim++) Area += Normal[iDim]*Normal[iDim]; Area = sqrt(Area);
                for (iDim = 0; iDim < nDim; iDim++) UnitNormal[iDim] = Normal[iDim]/Area;


                for(iVar = 0; iVar < nPrimVarGrad; iVar++){
                    PrimVar_i[iVar] = elem[iPoint]->GetPrimitive(iVar);
                    PrimVar_j[iVar] = elem[iPoint]->GetPrimitive(iVar);
                }

                ProjVelocity_i = 0.0;
                for(iDim = 0; iDim < nDim; iDim++) {
                    Velocity_i[iDim] = elem[iPoint]->GetVelocity(iDim);
                    ProjVelocity_i += Velocity_i[iDim]*UnitNormal[iDim];
                }

                if(Boundary == EULER_WALL || Boundary == SYMMETRY_PLANE){
                    for(iDim = 0; iDim < nDim; iDim++) PrimVar_j[iDim+1] = PrimVar_i[iDim+1]-2.0*ProjVelocity_i * UnitNormal[iDim];
                }

                if(Boundary == HEAT_FLUX){
                    for(iDim = 0; iDim < nDim; iDim++) PrimVar_j[iDim+1] = -PrimVar_i[iDim+1];
                }

                if (geometry->elem[iPoint]->GetDomain()) {
                    for (iVar = 0; iVar < nPrimVarGrad; iVar++)
                        PrimVar_Vertex[iVar] = 0.5*(PrimVar_i[iVar]+PrimVar_j[iVar]);

                    for (iDim = 0; iDim < nDim; iDim++)
                        for (iVar = 0; iVar < nPrimVarGrad; iVar++)
                            for (iDim = 0; iDim < nDim; iDim++) {
                                Partial_Res = PrimVar_Vertex[iVar]*Normal[iDim];

                                elem[iPoint]->AddGradient_Primitive(iVar, iDim, Partial_Res);

                            }
                }
            }
        }
    }


    /*--- Update gradient value ---*/
    for (iPoint = 0; iPoint < nElemDomain; iPoint++) {
        for (iVar = 0; iVar < nPrimVarGrad; iVar++) {
            for (iDim = 0; iDim < nDim; iDim++) {
                Partial_Gradient = elem[iPoint]->GetGradient_Primitive(iVar,iDim) / (geometry->elem[iPoint]->GetVolume());
                elem[iPoint]->SetGradient_Primitive(iVar, iDim, Partial_Gradient);

            }

        }
    }

    delete [] PrimVar_Vertex;
    delete [] PrimVar_i;
    delete [] PrimVar_j;

    Set_MPI_Primitive_Gradient(geometry, config);

}

void CEulerSolver::SetPrimitive_Gradient_LS(CGeometry *geometry, CConfig *config) {

    //..This section will be revised soon..//

}

void CEulerSolver::SetPrimitive_Limiter(CGeometry *geometry, CConfig *config) {

    unsigned long iFace, iPoint, jPoint;
    unsigned short iVar, iDim;
    double **Gradient_i, **Gradient_j, *Coord_i, *Coord_j, *Primitive_i, *Primitive_j,
            dave, LimK, eps2, eps1, dm, dp, du, y, limiter;

    if (config->GetKind_SlopeLimit_Flow() == NO_LIMITER) {

        for (iPoint = 0; iPoint < geometry->GetnElem(); iPoint++) {
            for (iVar = 0; iVar < nPrimVarGrad; iVar++) {
                elem[iPoint]->SetLimiter_Primitive(iVar, 1.0);
            }
        }

    }

    else {

        for (iPoint = 0; iPoint < geometry->GetnElem(); iPoint++) {
            for (iVar = 0; iVar < nPrimVarGrad; iVar++) {
                elem[iPoint]->SetSolution_Max(iVar, -EPS);
                elem[iPoint]->SetSolution_Min(iVar, EPS);
                elem[iPoint]->SetLimiter_Primitive(iVar, 2.0);
            }
        }
    }


    for (iFace = 0; iFace < geometry->GetnFace(); iFace++) {
        iPoint = geometry->face[iFace]->GetElems(0);

        if(geometry->face[iFace]->GetElems(1) != -1){

            jPoint = geometry->face[iFace]->GetElems(1);
            Primitive_i = elem[iPoint]->GetPrimitive();
            Primitive_j = elem[jPoint]->GetPrimitive();

            for (iVar = 0; iVar < nPrimVarGrad; iVar++) {
                du = (Primitive_j[iVar] - Primitive_i[iVar]);
                elem[iPoint]->SetSolution_Min(iVar, min(elem[iPoint]->GetSolution_Min(iVar), du));
                elem[iPoint]->SetSolution_Max(iVar, max(elem[iPoint]->GetSolution_Max(iVar), du));
                elem[jPoint]->SetSolution_Min(iVar, min(elem[jPoint]->GetSolution_Min(iVar), -du));
                elem[jPoint]->SetSolution_Max(iVar, max(elem[jPoint]->GetSolution_Max(iVar), -du));
            }
        }
    }

    if (config->GetKind_SlopeLimit() == BARTH_JESPERSEN) {

        for (iFace = 0; iFace < geometry->GetnFace(); iFace++) {

            iPoint     = geometry->face[iFace]->GetElems(0);
            Gradient_i = elem[iPoint]->GetGradient_Primitive();
            Coord_i    = geometry->elem[iPoint]->GetCG();

            if(geometry->face[iFace]->GetElems(1) != -1){

                jPoint     = geometry->face[iFace]->GetElems(1);
                Gradient_j = elem[jPoint]->GetGradient_Primitive();
                Coord_j    = geometry->elem[jPoint]->GetCG();

                for (iVar = 0; iVar < nPrimVarGrad; iVar++) {

                    dm = 0.0;
                    for (iDim = 0; iDim < nDim; iDim++)
                        dm += 0.5*(Coord_j[iDim]-Coord_i[iDim])*Gradient_i[iVar][iDim];

                    if (dm == 0.0) { limiter = 2.0; }
                    else {
                        if ( dm > 0.0 ) dp = elem[iPoint]->GetSolution_Max(iVar);
                        else dp = elem[iPoint]->GetSolution_Min(iVar);
                        limiter = dp/dm;
                    }

                    if (limiter < elem[iPoint]->GetLimiter_Primitive(iVar))
                        elem[iPoint]->SetLimiter_Primitive(iVar, limiter);

                    dm = 0.0;
                    for (iDim = 0; iDim < nDim; iDim++)
                        dm += 0.5*(Coord_i[iDim]-Coord_j[iDim])*Gradient_j[iVar][iDim];

                    if (dm == 0.0) { limiter = 2.0; }
                    else {
                        if ( dm > 0.0 ) dp = elem[jPoint]->GetSolution_Max(iVar);
                        else dp = elem[jPoint]->GetSolution_Min(iVar);
                        limiter = dp/dm;
                    }

                    if (limiter < elem[jPoint]->GetLimiter_Primitive(iVar))
                        elem[jPoint]->SetLimiter_Primitive(iVar, limiter);

                }
            }
        }

        for (iPoint = 0; iPoint < geometry->GetnElem(); iPoint++) {
            for (iVar = 0; iVar < nPrimVarGrad; iVar++) {
                y =  elem[iPoint]->GetLimiter_Primitive(iVar);
                limiter = (y*y + 2.0*y) / (y*y + y + 2.0);
                elem[iPoint]->SetLimiter_Primitive(iVar, limiter);
            }
        }

    }

    if (config->GetKind_SlopeLimit() == VENKATAKRISHNAN) {
        dave = config->GetRefElemLength();
        LimK = config->GetVenkat_LimiterCoeff();
        eps1 = LimK*dave;
        eps2 = eps1*eps1*eps1;

        for (iFace = 0; iFace < geometry->GetnFace(); iFace++) {

            iPoint     = geometry->face[iFace]->GetElems(0);
            Gradient_i = elem[iPoint]->GetGradient_Primitive();
            Coord_i    = geometry->elem[iPoint]->GetCG();

            if(geometry->face[iFace]->GetElems(1) != -1){

                jPoint     = geometry->face[iFace]->GetElems(1);
                Gradient_j = elem[jPoint]->GetGradient_Primitive();
                Coord_j    = geometry->elem[jPoint]->GetCG();

                for (iVar = 0; iVar < nPrimVarGrad; iVar++) {

                    dm = 0.0;
                    for (iDim = 0; iDim < nDim; iDim++)
                        dm += 0.5*(Coord_j[iDim]-Coord_i[iDim])*Gradient_i[iVar][iDim];

                    if ( dm > 0.0 ) dp = elem[iPoint]->GetSolution_Max(iVar);
                    else dp = elem[iPoint]->GetSolution_Min(iVar);

                    limiter = ( dp*dp + 2.0*dp*dm + eps2 )/( dp*dp + dp*dm + 2.0*dm*dm + eps2);

                    if (limiter < elem[iPoint]->GetLimiter_Primitive(iVar))
                        elem[iPoint]->SetLimiter_Primitive(iVar, limiter);

                    dm = 0.0;
                    for (iDim = 0; iDim < nDim; iDim++)
                        dm += 0.5*(Coord_i[iDim]-Coord_j[iDim])*Gradient_j[iVar][iDim];

                    if ( dm > 0.0 ) dp = elem[jPoint]->GetSolution_Max(iVar);
                    else dp = elem[jPoint]->GetSolution_Min(iVar);

                    limiter = ( dp*dp + 2.0*dp*dm + eps2 )/( dp*dp + dp*dm + 2.0*dm*dm + eps2);

                    if (limiter < elem[jPoint]->GetLimiter_Primitive(iVar))
                        elem[jPoint]->SetLimiter_Primitive(iVar, limiter);

                }
            }

        }

    }

    Set_MPI_Primitive_Limiter(geometry, config);

}

void CEulerSolver::SetPreconditioner(CConfig *config, unsigned short iPoint) {
    unsigned short iDim, jDim, iVar, jVar;
    double Beta, local_Mach, Beta2, rho, enthalpy, soundspeed, sq_vel;
    double *U_i = NULL;
    double Beta_min = config->GetminTurkelBeta();
    double Beta_max = config->GetmaxTurkelBeta();


    /*--- Variables to calculate the preconditioner parameter Beta ---*/
    local_Mach = sqrt(elem[iPoint]->GetVelocity2())/elem[iPoint]->GetSoundSpeed();
    Beta 		    = max(Beta_min,min(local_Mach,Beta_max));
    Beta2 		    = Beta*Beta;

    U_i = elem[iPoint]->GetSolution();

    rho = U_i[0];
    enthalpy = elem[iPoint]->GetEnthalpy();
    soundspeed = elem[iPoint]->GetSoundSpeed();
    sq_vel = elem[iPoint]->GetVelocity2();

    /*---Calculating the inverse of the preconditioning matrix that multiplies the time derivative  */
    LowMach_Precontioner[0][0] = 0.5*sq_vel;
    LowMach_Precontioner[0][nVar-1] = 1.0;
    for (iDim = 0; iDim < nDim; iDim ++)
        LowMach_Precontioner[0][1+iDim] = -1.0*U_i[iDim+1]/rho;

    for (iDim = 0; iDim < nDim; iDim ++) {
        LowMach_Precontioner[iDim+1][0] = 0.5*sq_vel*U_i[iDim+1]/rho;
        LowMach_Precontioner[iDim+1][nVar-1] = U_i[iDim+1]/rho;
        for (jDim = 0; jDim < nDim; jDim ++) {
            LowMach_Precontioner[iDim+1][1+jDim] = -1.0*U_i[jDim+1]/rho*U_i[iDim+1]/rho;
        }
    }

    LowMach_Precontioner[nVar-1][0] = 0.5*sq_vel*enthalpy;
    LowMach_Precontioner[nVar-1][nVar-1] = enthalpy;
    for (iDim = 0; iDim < nDim; iDim ++)
        LowMach_Precontioner[nVar-1][1+iDim] = -1.0*U_i[iDim+1]/rho*enthalpy;


    for (iVar = 0; iVar < nVar; iVar ++ ) {
        for (jVar = 0; jVar < nVar; jVar ++ ) {
            LowMach_Precontioner[iVar][jVar] = (1.0/(Beta2+EPS) - 1.0) * (Gamma-1.0)/(soundspeed*soundspeed)*LowMach_Precontioner[iVar][jVar];
            if (iVar == jVar)
                LowMach_Precontioner[iVar][iVar] += 1.0;
        }
    }

}

void CEulerSolver::GetEngine_Properties(CGeometry *geometry, CConfig *config, unsigned short iMesh, bool Output) {

    //This Function will be Revised Soon!//

}

void CEulerSolver::GetActuatorDisk_Properties(CGeometry *geometry, CConfig *config, unsigned short iMesh, bool Output) {

    //This Function will be Revised Soon!//

}

void CEulerSolver::SetFarfield_AoA(CGeometry *geometry, CSolver **solver_container,
                                   CConfig *config, unsigned short iMesh, bool Output) {

    unsigned short iDim, iCounter;
    bool Update_AoA = false;
    double Target_CL, AoA_inc, AoA, Eps_Factor = 1e2;
    double DampingFactor = config->GetDamp_Fixed_CL();
    double Beta = config->GetAoS()*PI_NUMBER/180.0;
    double Vel_Infty[3], Vel_Infty_Mag;

    int rank = MASTER_NODE;
#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

    if (iMesh == MESH_0) {

        config->SetUpdate_AoA(false);

        if (config->GetExtIter() == 0) {

            Cauchy_Value = 0.0;
            Cauchy_Counter = 0;
            for (iCounter = 0; iCounter < config->GetCauchy_Elems(); iCounter++)
                Cauchy_Serie[iCounter] = 0.0;
            AoA_old = config->GetAoA()*PI_NUMBER/180.0;
        }

        Old_Func = New_Func;
        New_Func = Total_CLift;
        Cauchy_Func = fabs(New_Func - Old_Func);
        Cauchy_Serie[Cauchy_Counter] = Cauchy_Func;
        Cauchy_Counter++;
        if (Cauchy_Counter == config->GetCauchy_Elems()) Cauchy_Counter = 0;

        Cauchy_Value = 1;
        if (config->GetExtIter() >= config->GetCauchy_Elems()) {
            Cauchy_Value = 0;
            for (iCounter = 0; iCounter < config->GetCauchy_Elems(); iCounter++)
                Cauchy_Value += Cauchy_Serie[iCounter];
        }

        if (Cauchy_Value >= config->GetCauchy_Eps()*Eps_Factor) Update_AoA = false;
        else Update_AoA = true;

        if (config->GetExtIter() < config->GetStartConv_Iter()) {
            Update_AoA = false;
        }

        config->SetUpdate_AoA(Update_AoA);

    } else
        Update_AoA = config->GetUpdate_AoA();

    if (Update_AoA) {

        Target_CL = config->GetTarget_CL();
        AoA_old = config->GetAoA()*PI_NUMBER/180.0;
        AoA_inc = (1.0/(2.0*PI_NUMBER))*(Target_CL - Total_CLift);

        if (iMesh == MESH_0)
            AoA = (1.0 - DampingFactor)*AoA_old + DampingFactor * (AoA_old + AoA_inc);
        else
            AoA = config->GetAoA()*PI_NUMBER/180.0;

        for (iDim = 0; iDim < nDim; iDim++)
            Vel_Infty[iDim] = GetVelocity_Inf(iDim);

        Vel_Infty_Mag = 0;
        for (iDim = 0; iDim < nDim; iDim++)
            Vel_Infty_Mag += Vel_Infty[iDim]*Vel_Infty[iDim];
        Vel_Infty_Mag = sqrt(Vel_Infty_Mag);

        if (nDim == 2) {
            Vel_Infty[0] = cos(AoA)*Vel_Infty_Mag;
            Vel_Infty[1] = sin(AoA)*Vel_Infty_Mag;
        }
        if (nDim == 3) {
            Vel_Infty[0] = cos(AoA)*cos(Beta)*Vel_Infty_Mag;
            Vel_Infty[1] = sin(Beta)*Vel_Infty_Mag;
            Vel_Infty[2] = sin(AoA)*cos(Beta)*Vel_Infty_Mag;
        }

        for (iDim = 0; iDim < nDim; iDim++) {
            Velocity_Inf[iDim] = Vel_Infty[iDim];
        }

        if (iMesh == MESH_0) {
            for (iDim = 0; iDim < nDim; iDim++)
                config->SetVelocity_FreeStreamND(Vel_Infty[iDim], iDim);
            config->SetAoA(AoA*180.0/PI_NUMBER);
        }

        Cauchy_Value = 0.0;
        Cauchy_Counter = 0;
        for (iCounter = 0; iCounter < config->GetCauchy_Elems(); iCounter++)
            Cauchy_Serie[iCounter] = 0.0;
    }


    bool write_heads = (((config->GetExtIter() % (config->GetWrt_Con_Freq()*20)) == 0));
    if ((rank == MASTER_NODE) && (iMesh == MESH_0) && write_heads && Output) {
        cout.precision(7);
        cout.setf(ios::fixed,ios::floatfield);
        cout << endl << "----------------------------- Fixed CL Mode -----------------------------" << endl;
        cout << " Target CL: " << config->GetTarget_CL();
        cout << ", Current CL: " << Total_CLift;
        cout << ", Current AoA: " << config->GetAoA() << " deg" << endl;
        cout << "-------------------------------------------------------------------------" << endl;
    }
}

void CEulerSolver::SetUniformInlet(CConfig* config, unsigned short iMarker) {

    //This Function will be Revised Soon!//

}

void CEulerSolver::BC_Euler_Wall(CGeometry *geometry, CSolver **solver_container,
                                 CNumerics *numerics, CConfig *config, unsigned short val_marker) {
    int rank = MASTER_NODE;
#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif
    unsigned short iDim, iVar, jVar, kVar, jDim;
    unsigned long iPoint, iVertex, iFace;
    double *Normal = NULL,  Area, UnitNormal[3], NormalArea[3] = {0.0, 0.0, 0.0}, turb_ke;
    double Density_b, StaticEnergy_b, Enthalpy_b, *Velocity_b, Kappa_b, Chi_b, Energy_b, VelMagnitude2_b, Pressure_b;
    double Density_i, *Velocity_i, ProjVelocity_i = 0.0, Energy_i, VelMagnitude2_i;
    double **Jacobian_b, **DubDu;

    bool implicit = (config->GetKind_TimeIntScheme_Flow() == EULER_IMPLICIT);
    bool compressible = (config->GetKind_Regime() == COMPRESSIBLE);
    bool tkeNeeded = ((config->GetKind_Solver() == RANS) && (config->GetKind_Turb_Model() == SST));

    Normal = new double[nDim];
    Velocity_b = new double[nDim];
    Velocity_i = new double[nDim];
    Jacobian_b = new double*[nVar];
    DubDu = new double*[nVar];

    for (iVar = 0; iVar < nVar; iVar++) {
        Jacobian_b[iVar] = new double[nVar];
        DubDu[iVar] = new double[nVar];
    }

    for(iVertex = 0; iVertex < geometry->nElem_Bound[val_marker]; iVertex++) {

        iFace = geometry->bound[val_marker][iVertex]->GetGlobalFace();
        iPoint = geometry->face[iFace]->GetElems(0);

        if (geometry->elem[iPoint]->GetDomain()) {

            Normal = geometry->face[iFace]->GetNormal_Face();
            Area = 0.0;
            for (iDim = 0; iDim < nDim; iDim++) Area += Normal[iDim]*Normal[iDim];
            Area = sqrt (Area);

            for (iDim = 0; iDim < nDim; iDim++) {
                NormalArea[iDim] = Normal[iDim];
                UnitNormal[iDim] = NormalArea[iDim]/Area;
            }

            if (compressible) {

                VelMagnitude2_i = 0.0; ProjVelocity_i = 0.0;
                for(iDim = 0; iDim < nDim; iDim++) {
                    Velocity_i[iDim] = elem[iPoint]->GetVelocity(iDim);
                    ProjVelocity_i += Velocity_i[iDim]*UnitNormal[iDim];
                    VelMagnitude2_i += Velocity_i[iDim]*Velocity_i[iDim];
                }
                Density_i = elem[iPoint]->GetDensity();
                Energy_i = elem[iPoint]->GetEnergy();

                for (iDim = 0; iDim < nDim; iDim++){
                    Velocity_b[iDim] = Velocity_i[iDim] - ProjVelocity_i * UnitNormal[iDim];
                }

                VelMagnitude2_b = 0.0;
                for (iDim = 0; iDim < nDim; iDim++)
                    VelMagnitude2_b += Velocity_b[iDim] * Velocity_b[iDim];

                turb_ke = 0.0;
                if (tkeNeeded) turb_ke = solver_container[TURB_SOL]->elem[iPoint]->GetSolution(0);

                Density_b = Density_i;
                StaticEnergy_b = Energy_i - 0.5 * VelMagnitude2_i - turb_ke;
                Energy_b = StaticEnergy_b + 0.5 * VelMagnitude2_b + turb_ke;

                FluidModel->SetTDState_rhoe(Density_b, StaticEnergy_b);
                Kappa_b = FluidModel->GetdPde_rho() / Density_b;
                Chi_b = FluidModel->GetdPdrho_e() - Kappa_b * StaticEnergy_b;
                Pressure_b = FluidModel->GetPressure();
                Enthalpy_b = Energy_b + Pressure_b/Density_b;

                numerics->GetInviscidProjFlux(&Density_b, Velocity_b, &Pressure_b, &Enthalpy_b, NormalArea, Residual);

                //..Grid Movements are not included..//

                if (tkeNeeded) {
                    for(iDim = 0; iDim < nDim; iDim++)
                        Residual[iDim+1] += (2.0/3.0)*Density_b*turb_ke*NormalArea[iDim];
                }
            }

            //..Incompressible, Free Surface are not included..//

            LinSysRes.AddBlock(iPoint, Residual);

            if (implicit) {

                for (iVar = 0; iVar < nVar; iVar++) {
                    for (jVar = 0; jVar < nVar; jVar++)
                        Jacobian_i[iVar][jVar] = 0.0;
                }

                if (compressible) {

                    for (iVar = 0; iVar < nVar; iVar++) {
                        for (jVar = 0; jVar < nVar; jVar++)
                            DubDu[iVar][jVar]= 0.0;
                        DubDu[iVar][iVar]= 1.0;
                    }

                    for(iDim = 0; iDim<nDim; iDim++)
                        for(jDim = 0; jDim<nDim; jDim++)
                            DubDu[iDim+1][jDim+1] -= UnitNormal[iDim]*UnitNormal[jDim];
                    DubDu[nVar-1][0] += 0.5*ProjVelocity_i*ProjVelocity_i;
                    for(iDim = 0; iDim<nDim; iDim++) {
                        DubDu[nVar-1][iDim+1] -= ProjVelocity_i*UnitNormal[iDim];
                    }
                    numerics->GetInviscidProjJac(Velocity_b, &Enthalpy_b, &Chi_b, &Kappa_b, NormalArea, 1, Jacobian_b);

                    for(iVar = 0; iVar < nVar; iVar++)
                        for(jVar = 0; jVar < nVar; jVar++)
                            for(kVar = 0; kVar < nVar; kVar++)
                                Jacobian_i[iVar][jVar] += Jacobian_b[iVar][kVar] * DubDu[kVar][jVar];

                    Jacobian.AddBlock(iPoint,iPoint,Jacobian_i);

                }

                //..Incompressible, Free Surface are not included..//
            }
        }
    }
}

void CEulerSolver::BC_Far_Field(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics,
                                CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

#ifdef HAVE_MPI
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif
    unsigned short iDim, iVar;
    unsigned long iFace, iVertex, iPoint, Point_Normal;

    double *GridVel, **Face_Gradient, *V_i, *V_j, SUM1;
    double SUM_1, Area, UnitNormal[3];
    double Density, Pressure, Velocity[3], Energy;
    double Density_Bound, Pressure_Bound, Vel_Bound[3];
    double Density_Infty, Pressure_Infty, Vel_Infty[3];
    double SoundSpeed, Entropy, Velocity2, Vn;
    double SoundSpeed_Bound, Entropy_Bound, Vel2_Bound, Vn_Bound;
    double SoundSpeed_Infty, Entropy_Infty, Vel2_Infty, Vn_Infty, Qn_Infty;
    double RiemannPlus, RiemannMinus;
    double *V_infty, *V_domain;

    double Gas_Constant     = config->GetGas_ConstantND();

    bool implicit         = config->GetKind_TimeIntScheme_Flow() == EULER_IMPLICIT;
    bool compressible     = (config->GetKind_Regime() == COMPRESSIBLE);
    bool viscous          = config->GetViscous();
    bool tkeNeeded = ((config->GetKind_Solver() == RANS) && (config->GetKind_Turb_Model() == SST));
    double *Normal, *CGF, *CGI;
    Normal = new double[nDim];
    V_i = new double [nPrimVar];
    V_j = new double [nPrimVar];

    Face_Gradient = new double* [nPrimVar];
    for (iVar = 0; iVar < nPrimVar; iVar++) {
        Face_Gradient[iVar] = new double [nDim];
        for (iDim = 0; iDim < nDim; iDim++) {
            Face_Gradient[iVar][iDim] = 0.0;
        }
    }

    for (iVertex = 0; iVertex < geometry->nElem_Bound[val_marker]; iVertex++) {

        iFace = geometry->bound[val_marker][iVertex]->GetGlobalFace();
        iPoint = geometry->face[iFace]->GetElems(0);
        V_infty = GetCharacPrimVar(val_marker, iVertex);

        if (geometry->elem[iPoint]->GetDomain()) {

            Point_Normal = geometry->bound[val_marker][iVertex]->GetGlobalFace();
            iPoint = geometry->face[Point_Normal]->GetElems(0);

            Normal = geometry->face[Point_Normal]->GetNormal_Face();

            conv_numerics->SetNormal(Normal);

            V_domain = elem[iPoint]->GetPrimitive();

            if (compressible) {
                Area = 0.0;
                for (iDim = 0; iDim < nDim; iDim++) Area += Normal[iDim]*Normal[iDim];
                Area = sqrt(Area);

                CGF = geometry->face[iFace]->GetCG();
                CGI = geometry->elem[iPoint]->GetCG();

                SUM_1 = 0.0;
                for(iDim = 0; iDim < nDim; iDim++){
                    SUM_1 += Normal[iDim]*(CGF[iDim]-CGI[iDim]);
                }

                for (iDim = 0; iDim < nDim; iDim++){
                    UnitNormal[iDim] = Normal[iDim]/Area;
                }

                SUM1 = 0.0;
                for(iDim = 0; iDim < nDim; iDim++){
                    SUM1 +=(CGI[iDim]-CGF[iDim])*UnitNormal[iDim];
                }

                Density_Bound = V_domain[nDim+2];
                Vel2_Bound = 0.0; Vn_Bound = 0.0;

                for (iDim = 0; iDim < nDim; iDim++) {
                    Vel_Bound[iDim] = V_domain[iDim+1];
                    Vel2_Bound     += Vel_Bound[iDim]*Vel_Bound[iDim];
                    Vn_Bound       += Vel_Bound[iDim]*UnitNormal[iDim];
                }

                Pressure_Bound   = elem[iPoint]->GetPressure();
                SoundSpeed_Bound = sqrt(Gamma*Pressure_Bound/Density_Bound);
                Entropy_Bound    = pow(Density_Bound,Gamma)/Pressure_Bound;

                Density_Infty = GetDensity_Inf();
                Vel2_Infty = 0.0; Vn_Infty = 0.0;
                for (iDim = 0; iDim < nDim; iDim++) {
                    Vel_Infty[iDim] = GetVelocity_Inf(iDim);
                    Vel2_Infty     += Vel_Infty[iDim]*Vel_Infty[iDim];
                    Vn_Infty       += Vel_Infty[iDim]*UnitNormal[iDim];
                }

                Pressure_Infty   = GetPressure_Inf();
                SoundSpeed_Infty = sqrt(Gamma*Pressure_Infty/Density_Infty);
                Entropy_Infty    = pow(Density_Infty,Gamma)/Pressure_Infty;

                Qn_Infty = Vn_Infty;

                //..Grid Movements are not included..//

                if (Qn_Infty > -SoundSpeed_Infty) {
                    RiemannPlus = Vn_Bound + 2.0*SoundSpeed_Bound/Gamma_Minus_One;
                } else {
                    RiemannPlus = Vn_Infty + 2.0*SoundSpeed_Infty/Gamma_Minus_One;
                }

                if (Qn_Infty > SoundSpeed_Infty) {
                    RiemannMinus = Vn_Bound - 2.0*SoundSpeed_Bound/Gamma_Minus_One;
                } else {
                    RiemannMinus = Vn_Infty - 2.0*SoundSpeed_Infty/Gamma_Minus_One;
                }

                Vn = 0.5 * (RiemannPlus + RiemannMinus);
                SoundSpeed = 0.25 * (RiemannPlus - RiemannMinus)*Gamma_Minus_One;

                if (Qn_Infty > 0.0)   {

                    for (iDim = 0; iDim < nDim; iDim++)
                        Velocity[iDim] = Vel_Bound[iDim] + (Vn-Vn_Bound)*UnitNormal[iDim];
                    Entropy = Entropy_Bound;
                } else  {
                    for (iDim = 0; iDim < nDim; iDim++)
                        Velocity[iDim] = Vel_Infty[iDim] + (Vn-Vn_Infty)*UnitNormal[iDim];
                    Entropy = Entropy_Infty;
                }

                Density = pow(Entropy*SoundSpeed*SoundSpeed/Gamma,1.0/Gamma_Minus_One);
                Velocity2 = 0.0;
                for (iDim = 0; iDim < nDim; iDim++) {
                    Velocity2 += Velocity[iDim]*Velocity[iDim];
                }

                Pressure = Density*SoundSpeed*SoundSpeed/Gamma;
                Energy   = Pressure/(Gamma_Minus_One*Density) + 0.5*Velocity2;
                if (tkeNeeded) Energy += GetTke_Inf();

                V_infty[0] = Pressure/(Gas_Constant*Density);

                for (iDim = 0; iDim < nDim; iDim++)
                    V_infty[iDim+1] = Velocity[iDim];

                V_infty[nDim+1] = Pressure;
                V_infty[nDim+2] = Density;
                V_infty[nDim+3] = Energy + Pressure/Density;

            }

            //..Incompressible, Free Surface are not included..//

            conv_numerics->SetPrimitive(V_domain, V_infty);

            //..Grid Movements are not included..//

            conv_numerics->ComputeResidual(Residual, Jacobian_i, Jacobian_j, config);

            LinSysRes.AddBlock(iPoint, Residual);

            if (implicit)
                Jacobian.AddBlock(iPoint, iPoint, Jacobian_i);

            if (config->GetKind_Upwind() == TURKEL)
                elem[iPoint]->SetPreconditioner_Beta(conv_numerics->GetPrecond_Beta());

            if (viscous) {

                for(iVar = 0; iVar < nPrimVar; iVar++){
                    for(iDim = 0; iDim < nDim; iDim++){
                        Face_Gradient[iVar][iDim]= (1/(2.*fabs(SUM1)))*(V_infty[iVar]-V_domain[iVar])*UnitNormal[iDim];
                    }
                }

                if (compressible) {
                    V_infty[nDim+5] = elem[iPoint]->GetLaminarViscosity();
                    V_infty[nDim+6] = elem[iPoint]->GetEddyViscosity();
                }

                //..Incompressible, Free Surface are not included..//

                visc_numerics->SetNormal(Normal);
                visc_numerics->SetCoord(geometry->elem[iPoint]->GetCG(),
                                        geometry->face[Point_Normal]->GetCG());

                visc_numerics->SetPrimitive(V_domain, V_infty);
                visc_numerics->SetPrimVarGradient(elem[iPoint]->GetGradient_Primitive(),
                                                  elem[iPoint]->GetGradient_Primitive());

                if (config->GetKind_Turb_Model() == SST)
                    visc_numerics->SetTurbKineticEnergy(solver_container[TURB_SOL]->elem[iPoint]->GetSolution(0),
                                                        solver_container[TURB_SOL]->elem[iPoint]->GetSolution(0));

                visc_numerics->ComputeResidual(Residual, Jacobian_i, Jacobian_j, config);

                LinSysRes.SubtractBlock(iPoint, Residual);

                if (implicit)
                    Jacobian.SubtractBlock(iPoint, iPoint, Jacobian_i);

            }
        }
    }
}

void CEulerSolver::BC_Riemann(CGeometry *geometry, CSolver **solver_container,
                              CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    //This function will be revised soon!//

}

void CEulerSolver::BC_Inlet(CGeometry *geometry, CSolver **solver_container,
                            CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {
    unsigned short iDim;
    unsigned long iVertex, iPoint, Point_Normal, iFace;
    double P_Total, T_Total, Velocity[3], Velocity2, H_Total, Temperature, Riemann,
            Pressure, Density, Energy, *Flow_Dir, Mach2, SoundSpeed2, SoundSpeed_Total2, Vel_Mag,
            alpha, aa, bb, cc, dd, Area, UnitNormal[3], *Normal, NormalArea[3] = {0.0, 0.0, 0.0};
    double *V_inlet, *V_domain;

    bool implicit             = (config->GetKind_TimeIntScheme_Flow() == EULER_IMPLICIT);
    bool compressible = (config->GetKind_Regime() == COMPRESSIBLE);
    double Two_Gamma_M1       = 2.0/Gamma_Minus_One;
    double Gas_Constant       = config->GetGas_ConstantND();
    unsigned short Kind_Inlet = config->GetKind_Inlet();
    string Marker_Tag         = config->GetMarker_All_TagBound(val_marker);
    bool viscous              = config->GetViscous();
    bool gravity = (config->GetGravityForce());
    bool tkeNeeded = ((config->GetKind_Solver() == RANS) && (config->GetKind_Turb_Model() == SST));


    /*--- Loop over all the vertices on this boundary marker ---*/
    for (iVertex = 0; iVertex < geometry->nElem_Bound[val_marker]; iVertex++) {

        iFace = geometry->bound[val_marker][iVertex]->GetGlobalFace();
        iPoint = geometry->face[iFace]->GetElems(0);
        V_inlet = GetCharacPrimVar(val_marker, iVertex);

        if (geometry->elem[iPoint]->GetDomain()) {

            Point_Normal = geometry->bound[val_marker][iVertex]->GetGlobalFace();

            Normal = geometry->face[Point_Normal]->GetNormal_Face();
            for (iDim = 0; iDim < nDim; iDim++) NormalArea[iDim] = Normal[iDim];
            conv_numerics->SetNormal(NormalArea);

            Area = 0.0;
            for (iDim = 0; iDim < nDim; iDim++) Area += NormalArea[iDim]*NormalArea[iDim];
            Area = sqrt (Area);

            for (iDim = 0; iDim < nDim; iDim++)
                UnitNormal[iDim] = NormalArea[iDim]/Area;

            V_domain = elem[iPoint]->GetPrimitive();

            if (compressible) {

                /*--- Subsonic inflow: there is one outgoing characteristic (u-c),
             therefore we can specify all but one state variable at the inlet.
             The outgoing Riemann invariant provides the final piece of info.
             Adapted from an original implementation in the Stanford University
             multi-block (SUmb) solver in the routine bcSubsonicInflow.f90
             written by Edwin van der Weide, last modified 04-20-2009. ---*/

                switch (Kind_Inlet) {

                case TOTAL_CONDITIONS:
                    if (gravity) P_Total = config->GetInlet_Ptotal(Marker_Tag) - geometry->elem[iPoint]->GetCG(nDim-1)*STANDART_GRAVITY;
                    else P_Total  = config->GetInlet_Ptotal(Marker_Tag);
                    T_Total  = config->GetInlet_Ttotal(Marker_Tag);
                    Flow_Dir = config->GetInlet_FlowDir(Marker_Tag);

                    P_Total /= config->GetPressure_Ref();
                    T_Total /= config->GetTemperature_Ref();

                    Density = V_domain[nDim+2];
                    Velocity2 = 0.0;
                    for (iDim = 0; iDim < nDim; iDim++) {
                        Velocity[iDim] = V_domain[iDim+1];
                        Velocity2 += Velocity[iDim]*Velocity[iDim];
                    }
                    Energy      = V_domain[nDim+3] - V_domain[nDim+1]/V_domain[nDim+2];
                    Pressure    = V_domain[nDim+1];
                    H_Total     = (Gamma*Gas_Constant/Gamma_Minus_One)*T_Total;
                    SoundSpeed2 = Gamma*Pressure/Density;

                    Riemann   = 2.0*sqrt(SoundSpeed2)/Gamma_Minus_One;
                    for (iDim = 0; iDim < nDim; iDim++)
                        Riemann += Velocity[iDim]*UnitNormal[iDim];

                    SoundSpeed_Total2 = Gamma_Minus_One*(H_Total - (Energy + Pressure/Density)+0.5*Velocity2) + SoundSpeed2;

                    alpha = 0.0;
                    for (iDim = 0; iDim < nDim; iDim++)
                        alpha += UnitNormal[iDim]*Flow_Dir[iDim];

                    aa =  1.0 + 0.5*Gamma_Minus_One*alpha*alpha;
                    bb = -1.0*Gamma_Minus_One*alpha*Riemann;
                    cc =  0.5*Gamma_Minus_One*Riemann*Riemann
                            -2.0*SoundSpeed_Total2/Gamma_Minus_One;

                    dd = bb*bb - 4.0*aa*cc;
                    dd = sqrt(max(0.0,dd));
                    Vel_Mag   = (-bb + dd)/(2.0*aa);
                    Vel_Mag   = max(0.0,Vel_Mag);
                    Velocity2 = Vel_Mag*Vel_Mag;

                    SoundSpeed2 = SoundSpeed_Total2 - 0.5*Gamma_Minus_One*Velocity2;

                    Mach2 = Velocity2/SoundSpeed2;
                    Mach2 = min(1.0,Mach2);
                    Velocity2   = Mach2*SoundSpeed2;
                    Vel_Mag     = sqrt(Velocity2);
                    SoundSpeed2 = SoundSpeed_Total2 - 0.5*Gamma_Minus_One*Velocity2;

                    for (iDim = 0; iDim < nDim; iDim++)
                        Velocity[iDim] = Vel_Mag*Flow_Dir[iDim];

                    Temperature = SoundSpeed2/(Gamma*Gas_Constant);

                    Pressure = P_Total*pow((Temperature/T_Total),Gamma/Gamma_Minus_One);

                    Density = Pressure/(Gas_Constant*Temperature);

                    Energy = Pressure/(Density*Gamma_Minus_One) + 0.5*Velocity2;
                    if (tkeNeeded) Energy += GetTke_Inf();

                    V_inlet[0] = Temperature;
                    for (iDim = 0; iDim < nDim; iDim++)
                        V_inlet[iDim+1] = Velocity[iDim];
                    V_inlet[nDim+1] = Pressure;
                    V_inlet[nDim+2] = Density;
                    V_inlet[nDim+3] = Energy + Pressure/Density;

                    break;

                case MASS_FLOW:

                    Density  = config->GetInlet_Ttotal(Marker_Tag);
                    Vel_Mag  = config->GetInlet_Ptotal(Marker_Tag);
                    Flow_Dir = config->GetInlet_FlowDir(Marker_Tag);

                    Density /= config->GetDensity_Ref();
                    Vel_Mag /= config->GetVelocity_Ref();

                    for (iDim = 0; iDim < nDim; iDim++)
                        Velocity[iDim] = elem[iPoint]->GetVelocity(iDim);
                    Pressure    = elem[iPoint]->GetPressure();
                    SoundSpeed2 = Gamma*Pressure/V_domain[nDim+2];

                    Riemann = Two_Gamma_M1*sqrt(SoundSpeed2);
                    for (iDim = 0; iDim < nDim; iDim++)
                        Riemann += Velocity[iDim]*UnitNormal[iDim];

                    SoundSpeed2 = Riemann;
                    for (iDim = 0; iDim < nDim; iDim++)
                        SoundSpeed2 -= Vel_Mag*Flow_Dir[iDim]*UnitNormal[iDim];

                    SoundSpeed2 = max(0.0,0.5*Gamma_Minus_One*SoundSpeed2);
                    SoundSpeed2 = SoundSpeed2*SoundSpeed2;

                    Pressure = SoundSpeed2*Density/Gamma;

                    Energy = Pressure/(Density*Gamma_Minus_One) + 0.5*Vel_Mag*Vel_Mag;
                    if (tkeNeeded) Energy += GetTke_Inf();

                    V_inlet[0] = Pressure / ( Gas_Constant * Density);
                    for (iDim = 0; iDim < nDim; iDim++)
                        V_inlet[iDim+1] = Vel_Mag*Flow_Dir[iDim];
                    V_inlet[nDim+1] = Pressure;
                    V_inlet[nDim+2] = Density;
                    V_inlet[nDim+3] = Energy + Pressure/Density;

                    break;
                }
            }

            //..Incompressible, Free Surface are not included..//

            conv_numerics->SetPrimitive(V_domain, V_inlet);

            //..Grid Movements are not included..//

            conv_numerics->ComputeResidual(Residual, Jacobian_i, Jacobian_j, config);

            LinSysRes.AddBlock(iPoint, Residual);

            if (implicit)
                Jacobian.AddBlock(iPoint, iPoint, Jacobian_i);

            if (config->GetKind_Upwind() == TURKEL)
                elem[iPoint]->SetPreconditioner_Beta(conv_numerics->GetPrecond_Beta());

            if (viscous) {
                if (compressible) {
                    V_inlet[nDim+5] = elem[iPoint]->GetLaminarViscosity();
                    V_inlet[nDim+6] = elem[iPoint]->GetEddyViscosity();
                }

                //..Incompressible, Free Surface are not included..//

                visc_numerics->SetNormal(NormalArea);
                visc_numerics->SetCoord(geometry->elem[iPoint]->GetCG(), geometry->face[Point_Normal]->GetCG());

                visc_numerics->SetPrimitive(V_domain, V_inlet);
                visc_numerics->SetPrimVarGradient(elem[iPoint]->GetGradient_Primitive(), elem[iPoint]->GetGradient_Primitive());

                if (config->GetKind_Turb_Model() == SST)
                    visc_numerics->SetTurbKineticEnergy(solver_container[TURB_SOL]->elem[iPoint]->GetSolution(0), solver_container[TURB_SOL]->elem[iPoint]->GetSolution(0));

                visc_numerics->ComputeResidual(Residual, Jacobian_i, Jacobian_j, config);
                LinSysRes.SubtractBlock(iPoint, Residual);

                if (implicit)
                    Jacobian.SubtractBlock(iPoint, iPoint, Jacobian_i);

            }

        }
    }
    //  delete [] Normal;
}

void CEulerSolver::BC_Outlet(CGeometry *geometry, CSolver **solver_container,
                             CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {
    unsigned short iVar, iDim;
    unsigned long iVertex, iPoint, Point_Normal, iFace;
    double Pressure, P_Exit, Velocity[3],
            Velocity2, Entropy, Density, Energy, Riemann, Vn, SoundSpeed, Mach_Exit, Vn_Exit,
            Area, UnitNormal[3], *Normal, NormalArea[3] = {0.0, 0.0, 0.0};
    double *V_outlet, *V_domain;

    bool implicit           = (config->GetKind_TimeIntScheme_Flow() == EULER_IMPLICIT);
    double Gas_Constant     = config->GetGas_ConstantND();
    bool compressible = (config->GetKind_Regime() == COMPRESSIBLE);
    string Marker_Tag       = config->GetMarker_All_TagBound(val_marker);
    bool viscous              = config->GetViscous();
    bool gravity = (config->GetGravityForce());
    bool tkeNeeded = ((config->GetKind_Solver() == RANS) && (config->GetKind_Turb_Model() == SST));

    /*--- Loop over all the vertices on this boundary marker ---*/
    for (iVertex = 0; iVertex < geometry->nElem_Bound[val_marker]; iVertex++) {

        iFace = geometry->bound[val_marker][iVertex]->GetGlobalFace();
        iPoint = geometry->face[iFace]->GetElems(0);

        V_outlet = GetCharacPrimVar(val_marker, iVertex);

        if (geometry->elem[iPoint]->GetDomain()) {

            Point_Normal = geometry->bound[val_marker][iVertex]->GetGlobalFace();

            Normal = geometry->face[Point_Normal]->GetNormal_Face();

            for (iDim = 0; iDim < nDim; iDim++) NormalArea[iDim] = Normal[iDim];

            conv_numerics->SetNormal(NormalArea);

            Area = 0.0;
            for (iDim = 0; iDim < nDim; iDim++) Area += NormalArea[iDim]*NormalArea[iDim];
            Area = sqrt (Area);

            for (iDim = 0; iDim < nDim; iDim++)
                UnitNormal[iDim] = NormalArea[iDim]/Area;

            V_domain = elem[iPoint]->GetPrimitive();

            if (compressible) {

                if (gravity) P_Exit = config->GetOutlet_Pressure(Marker_Tag) - geometry->elem[iPoint]->GetCG(nDim-1)*STANDART_GRAVITY;
                else P_Exit = config->GetOutlet_Pressure(Marker_Tag);

                P_Exit = P_Exit/config->GetPressure_Ref();

                Density = V_domain[nDim+2];
                Velocity2 = 0.0; Vn = 0.0;
                for (iDim = 0; iDim < nDim; iDim++) {
                    Velocity[iDim] = V_domain[iDim+1];
                    Velocity2 += Velocity[iDim]*Velocity[iDim];
                    Vn += Velocity[iDim]*UnitNormal[iDim];
                }
                Pressure   = V_domain[nDim+1];
                SoundSpeed = sqrt(Gamma*Pressure/Density);
                Mach_Exit  = sqrt(Velocity2)/SoundSpeed;

                if (Mach_Exit >= 1.0) {

                    /*--- Supersonic exit flow: there are no incoming characteristics,
               so no boundary condition is necessary. Set outlet state to current
               state so that upwinding handles the direction of propagation. ---*/
                    for (iVar = 0; iVar < nPrimVar; iVar++) V_outlet[iVar] = V_domain[iVar];

                } else {

                    /*--- Subsonic exit flow: there is one incoming characteristic,
               therefore one variable can be specified (back pressure) and is used
               to update the conservative variables. Compute the entropy and the
               acoustic Riemann variable. These invariants, as well as the
               tangential velocity components, are extrapolated. Adapted from an
               original implementation in the Stanford University multi-block
               (SUmb) solver in the routine bcSubsonicOutflow.f90 by Edwin van
               der Weide, last modified 09-10-2007. ---*/

                    Entropy = Pressure*pow(1.0/Density,Gamma);
                    Riemann = Vn + 2.0*SoundSpeed/Gamma_Minus_One;

                    Density    = pow(P_Exit/Entropy,1.0/Gamma);
                    Pressure   = P_Exit;
                    SoundSpeed = sqrt(Gamma*P_Exit/Density);
                    Vn_Exit    = Riemann - 2.0*SoundSpeed/Gamma_Minus_One;
                    Velocity2  = 0.0;
                    for (iDim = 0; iDim < nDim; iDim++) {
                        Velocity[iDim] = Velocity[iDim] + (Vn_Exit-Vn)*UnitNormal[iDim];
                        Velocity2 += Velocity[iDim]*Velocity[iDim];
                    }
                    Energy = P_Exit/(Density*Gamma_Minus_One) + 0.5*Velocity2;
                    if (tkeNeeded) Energy += GetTke_Inf();

                    V_outlet[0] = Pressure / ( Gas_Constant * Density);
                    for (iDim = 0; iDim < nDim; iDim++)
                        V_outlet[iDim+1] = Velocity[iDim];
                    V_outlet[nDim+1] = Pressure;
                    V_outlet[nDim+2] = Density;
                    V_outlet[nDim+3] = Energy + Pressure/Density;

                }
            }

            //..Incompressible, Free Surface are not included..//

            conv_numerics->SetPrimitive(V_domain, V_outlet);

            //..Grid Movements are not included..//

            conv_numerics->ComputeResidual(Residual, Jacobian_i, Jacobian_j, config);

            LinSysRes.AddBlock(iPoint, Residual);

            if (implicit) {
                Jacobian.AddBlock(iPoint, iPoint, Jacobian_i);
            }

            if (config->GetKind_Upwind() == TURKEL)
                elem[iPoint]->SetPreconditioner_Beta(conv_numerics->GetPrecond_Beta());

            if (viscous) {

                if (compressible) {
                    V_outlet[nDim+5] = elem[iPoint]->GetLaminarViscosity();
                    V_outlet[nDim+6] = elem[iPoint]->GetEddyViscosity();
                }

                //..Incompressible, Free Surface are not included..//

                visc_numerics->SetNormal(NormalArea);
                visc_numerics->SetCoord(geometry->elem[iPoint]->GetCG(), geometry->face[Point_Normal]->GetCG());

                visc_numerics->SetPrimitive(V_domain, V_outlet);
                visc_numerics->SetPrimVarGradient(elem[iPoint]->GetGradient_Primitive(), elem[iPoint]->GetGradient_Primitive());

                if (config->GetKind_Turb_Model() == SST)
                    visc_numerics->SetTurbKineticEnergy(solver_container[TURB_SOL]->elem[iPoint]->GetSolution(0), solver_container[TURB_SOL]->elem[iPoint]->GetSolution(0));

                visc_numerics->ComputeResidual(Residual, Jacobian_i, Jacobian_j, config);
                LinSysRes.SubtractBlock(iPoint, Residual);

                if (implicit)
                    Jacobian.SubtractBlock(iPoint, iPoint, Jacobian_i);
            }

        }
    }
}

void CEulerSolver::BC_Supersonic_Inlet(CGeometry *geometry, CSolver **solver_container,
                                       CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {
    unsigned short iDim;
    unsigned long iVertex, iPoint, Point_Normal, iFace;
    double Area, UnitNormal[3];
    double *V_inlet, *V_domain;
    double *Normal = new double[nDim];

    double Density, Pressure, Temperature, Energy, *Velocity, Velocity2;
    double Gas_Constant = config->GetGas_ConstantND();

    bool implicit = (config->GetKind_TimeIntScheme_Flow() == EULER_IMPLICIT);
    bool viscous              = config->GetViscous();
    string Marker_Tag = config->GetMarker_All_TagBound(val_marker);
    bool tkeNeeded = ((config->GetKind_Solver() == RANS) && (config->GetKind_Turb_Model() == SST));

    /*--- Supersonic inlet flow: there are no outgoing characteristics,
       so all flow variables can be imposed at the inlet.
       First, retrieve the specified values for the primitive variables. ---*/

    Temperature = config->GetInlet_Temperature(Marker_Tag);
    Pressure    = config->GetInlet_Pressure(Marker_Tag);
    Velocity    = config->GetInlet_Velocity(Marker_Tag);

    Density = Pressure/(Gas_Constant*Temperature);

    Temperature = Temperature/config->GetTemperature_Ref();
    Pressure    = Pressure/config->GetPressure_Ref();
    Density     = Density/config->GetDensity_Ref();
    for (iDim = 0; iDim < nDim; iDim++)
        Velocity[iDim] = Velocity[iDim]/config->GetVelocity_Ref();

    Velocity2 = 0.0;
    for (iDim = 0; iDim < nDim; iDim++)
        Velocity2 += Velocity[iDim]*Velocity[iDim];
    Energy = Pressure/(Density*Gamma_Minus_One)+0.5*Velocity2;
    if (tkeNeeded) Energy += GetTke_Inf();

    /*--- Loop over all the vertices on this boundary marker ---*/

    for (iVertex = 0; iVertex < geometry->nElem_Bound[val_marker]; iVertex++) {

        iFace = geometry->bound[val_marker][iVertex]->GetGlobalFace();
        iPoint = geometry->face[iFace]->GetElems(0);

        Point_Normal = geometry->bound[val_marker][iVertex]->GetGlobalFace();
        iPoint = geometry->face[Point_Normal]->GetElems(0);

        V_inlet = GetCharacPrimVar(val_marker, iVertex);

        V_inlet[0] = Temperature;
        for (iDim = 0; iDim < nDim; iDim++)
            V_inlet[iDim+1] = Velocity[iDim];

        V_inlet[nDim+1] = Pressure;
        V_inlet[nDim+2] = Density;
        V_inlet[nDim+3] = Energy + Pressure/Density;

        if (geometry->elem[iPoint]->GetDomain()) {

            V_domain = elem[iPoint]->GetPrimitive();
            Normal = geometry->face[Point_Normal]->GetNormal_Face();

            Area = 0.0;
            for (iDim = 0; iDim < nDim; iDim++)
                Area += Normal[iDim]*Normal[iDim];
            Area = sqrt (Area);

            for (iDim = 0; iDim < nDim; iDim++)
                UnitNormal[iDim] = Normal[iDim]/Area;

            conv_numerics->SetNormal(Normal);
            conv_numerics->SetPrimitive(V_domain, V_inlet);

            //..Grid Movements are not included..//

            conv_numerics->ComputeResidual(Residual, Jacobian_i, Jacobian_j, config);
            LinSysRes.AddBlock(iPoint, Residual);

            if (implicit)
                Jacobian.AddBlock(iPoint, iPoint, Jacobian_i);

            if (viscous) {

                V_inlet[nDim+5] = elem[iPoint]->GetLaminarViscosity();
                V_inlet[nDim+6] = elem[iPoint]->GetEddyViscosity();

                visc_numerics->SetNormal(Normal);
                visc_numerics->SetCoord(geometry->elem[iPoint]->GetCG(),
                                        geometry->face[Point_Normal]->GetCG());

                visc_numerics->SetPrimitive(V_domain, V_inlet);
                visc_numerics->SetPrimVarGradient(elem[iPoint]->GetGradient_Primitive(), elem[iPoint]->GetGradient_Primitive());

                if (config->GetKind_Turb_Model() == SST)
                    visc_numerics->SetTurbKineticEnergy(solver_container[TURB_SOL]->elem[iPoint]->GetSolution(0), solver_container[TURB_SOL]->elem[iPoint]->GetSolution(0));

                visc_numerics->ComputeResidual(Residual, Jacobian_i, Jacobian_j, config);
                LinSysRes.SubtractBlock(iPoint, Residual);

                if (implicit)
                    Jacobian.SubtractBlock(iPoint, iPoint, Jacobian_i);
            }

        }
    }

    //  delete [] Normal;

}

void CEulerSolver::BC_Supersonic_Outlet(CGeometry *geometry, CSolver **solver_container,
                                        CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    //This function will be revised soon!//

}

void CEulerSolver::BC_Engine_Inflow(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    //This function will be revised soon!//

}

void CEulerSolver::BC_Engine_Exhaust(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    //This function will be revised soon!//

}

void CEulerSolver::BC_Engine_Bleed(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    //This function will be revised soon!//

}

void CEulerSolver::BC_Sym_Plane(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics,
                                CConfig *config, unsigned short val_marker) {

    BC_Euler_Wall(geometry, solver_container, conv_numerics, config, val_marker);

}

void CEulerSolver::BC_Interface_Boundary(CGeometry *geometry, CSolver **solver_container, CNumerics *numerics,
                                         CConfig *config, unsigned short val_marker) {

    //This function will be revised soon!//

}

void CEulerSolver::BC_NearField_Boundary(CGeometry *geometry, CSolver **solver_container, CNumerics *numerics,
                                         CConfig *config, unsigned short val_marker) {


    BC_Interface_Boundary(geometry, solver_container, numerics, config, val_marker);


}

void CEulerSolver::BC_ActDisk_Boundary(CGeometry *geometry, CSolver **solver_container, CNumerics *numerics,
                                       CConfig *config) {

    //This function will be revised soon!//

}

void CEulerSolver::BC_Dirichlet(CGeometry *geometry, CSolver **solver_container,
                                CConfig *config, unsigned short val_marker) { }

void CEulerSolver::BC_Custom(CGeometry *geometry, CSolver **solver_container, CNumerics *numerics, CConfig *config, unsigned short val_marker) { }

void CEulerSolver::SetResidual_DualTime(CGeometry *geometry, CSolver **solver_container, CConfig *config,
                                        unsigned short iRKStep, unsigned short iMesh, unsigned short RunTime_EqSystem) {

    unsigned short iVar, jVar, iMarker, iDim;
    unsigned long iPoint, jPoint, iFace, iVertex;

    double *U_time_nM1, *U_time_n, *U_time_nP1;
    double Volume_nM1, Volume_nP1, TimeStep;
    double *Normal = NULL, *GridVel_i = NULL, *GridVel_j = NULL, Residual_GCL;

    bool implicit       = (config->GetKind_TimeIntScheme_Flow() == EULER_IMPLICIT);
    bool grid_movement  = config->GetGrid_Movement();

    TimeStep = config->GetDelta_UnstTimeND();

    if (!grid_movement) {

        for (iPoint = 0; iPoint < nElemDomain; iPoint++) {

            U_time_nM1 = elem[iPoint]->GetSolution_time_n1();
            U_time_n   = elem[iPoint]->GetSolution_time_n();
            U_time_nP1 = elem[iPoint]->GetSolution();

            Volume_nP1 = geometry->elem[iPoint]->GetVolume();

            for (iVar = 0; iVar < nVar; iVar++) {
                if (config->GetUnsteady_Simulation() == DT_STEPPING_1ST)
                    Residual[iVar] = (U_time_nP1[iVar] - U_time_n[iVar])*Volume_nP1 / TimeStep;
                if (config->GetUnsteady_Simulation() == DT_STEPPING_2ND)
                    Residual[iVar] = ( 3.0*U_time_nP1[iVar] - 4.0*U_time_n[iVar]
                                       +1.0*U_time_nM1[iVar])*Volume_nP1 / (2.0*TimeStep);
            }

            //..Incompressible, Free Surface are not included..//

            LinSysRes.AddBlock(iPoint, Residual);
            if (implicit) {
                for (iVar = 0; iVar < nVar; iVar++) {
                    for (jVar = 0; jVar < nVar; jVar++) Jacobian_i[iVar][jVar] = 0.0;
                    if (config->GetUnsteady_Simulation() == DT_STEPPING_1ST)
                        Jacobian_i[iVar][iVar] = Volume_nP1 / TimeStep;
                    if (config->GetUnsteady_Simulation() == DT_STEPPING_2ND)
                        Jacobian_i[iVar][iVar] = (Volume_nP1*3.0)/(2.0*TimeStep);
                }

                //..Incompressible, Free Surface are not included..//

                Jacobian.AddBlock(iPoint, iPoint, Jacobian_i);
            }
        }

    }

    else {

        for(iFace = 0; iFace < geometry->GetnFace(); iFace++) {

            iPoint = geometry->face[iFace]->GetElems(0);

            if(geometry->face[iFace]->GetElems(1) != -1){

                jPoint = geometry->face[iFace]->GetElems(1);
                Normal = geometry->face[iFace]->GetNormal_Face();

                GridVel_i = geometry->elem[iPoint]->GetGridVel();
                GridVel_j = geometry->elem[jPoint]->GetGridVel();

                Residual_GCL = 0.0;
                for (iDim = 0; iDim < nDim; iDim++)
                    Residual_GCL += 0.5*(GridVel_i[iDim]+GridVel_j[iDim])*Normal[iDim];

                U_time_n = elem[iPoint]->GetSolution_time_n();
                for(iVar = 0; iVar < nVar; iVar++)
                    Residual[iVar] = U_time_n[iVar]*Residual_GCL;
                //..Incompressible, Free Surface are not included..//
                LinSysRes.AddBlock(iPoint, Residual);

                U_time_n = elem[jPoint]->GetSolution_time_n();
                for(iVar = 0; iVar < nVar; iVar++)
                    Residual[iVar] = U_time_n[iVar]*Residual_GCL;
                //..Incompressible, Free Surface are not included..//
                LinSysRes.SubtractBlock(jPoint, Residual);
            }
        }

        for (iMarker = 0; iMarker < geometry->GetnMarker(); iMarker++) {
            if(config->GetMarker_All_KindBC(iMarker) != SEND_RECEIVE){
                for (iVertex = 0; iVertex < geometry->GetnElem_Bound(iMarker); iVertex++) {

                    iFace = geometry->bound[iMarker][iVertex]->GetGlobalFace();
                    iPoint = geometry->face[iFace]->GetElems(0);
                    Normal = geometry->face[iFace]->GetNormal_Face();

                    GridVel_i = geometry->elem[iPoint]->GetGridVel();

                    Residual_GCL = 0.0;
                    for (iDim = 0; iDim < nDim; iDim++)
                        Residual_GCL -= 0.5*(GridVel_i[iDim]+GridVel_i[iDim])*Normal[iDim];

                    U_time_n = elem[iPoint]->GetSolution_time_n();
                    for(iVar = 0; iVar < nVar; iVar++)
                        Residual[iVar] = U_time_n[iVar]*Residual_GCL;
                    //..Incompressible, Free Surface are not included..//
                    LinSysRes.AddBlock(iPoint, Residual);
                }
            }
        }

        for (iPoint = 0; iPoint < nElemDomain; iPoint++) {

            U_time_nM1 = elem[iPoint]->GetSolution_time_n1();
            U_time_n   = elem[iPoint]->GetSolution_time_n();
            U_time_nP1 = elem[iPoint]->GetSolution();

            Volume_nM1 = geometry->elem[iPoint]->GetVolume_nM1();
            Volume_nP1 = geometry->elem[iPoint]->GetVolume();

            for(iVar = 0; iVar < nVar; iVar++) {
                if (config->GetUnsteady_Simulation() == DT_STEPPING_1ST)
                    Residual[iVar] = (U_time_nP1[iVar] - U_time_n[iVar])*(Volume_nP1/TimeStep);
                if (config->GetUnsteady_Simulation() == DT_STEPPING_2ND)
                    Residual[iVar] = (U_time_nP1[iVar] - U_time_n[iVar])*(3.0*Volume_nP1/(2.0*TimeStep))
                            + (U_time_nM1[iVar] - U_time_n[iVar])*(Volume_nM1/(2.0*TimeStep));
            }

            //..Incompressible, Free Surface are not included..//

            LinSysRes.AddBlock(iPoint, Residual);
            if (implicit) {
                for (iVar = 0; iVar < nVar; iVar++) {
                    for (jVar = 0; jVar < nVar; jVar++) Jacobian_i[iVar][jVar] = 0.0;
                    if (config->GetUnsteady_Simulation() == DT_STEPPING_1ST)
                        Jacobian_i[iVar][iVar] = Volume_nP1/TimeStep;
                    if (config->GetUnsteady_Simulation() == DT_STEPPING_2ND)
                        Jacobian_i[iVar][iVar] = (3.0*Volume_nP1)/(2.0*TimeStep);
                }
                //..Incompressible, Free Surface are not included..//
                Jacobian.AddBlock(iPoint, iPoint, Jacobian_i);
            }
        }
    }

}

void CEulerSolver::SetFlow_Displacement(CGeometry **flow_geometry, CVolumetricMovement *flow_grid_movement,
                                        CConfig *flow_config, CConfig *fea_config, CGeometry **fea_geometry, CSolver ***fea_solution) {

    //This function will be revised soon!//

}

void CEulerSolver::LoadRestart(CGeometry **geometry, CSolver ***solver, CConfig *config, int val_iter, bool val_update_geo) {

    //This function will be revised soon!//

}

void CEulerSolver::SetFreeSurface_Distance(CGeometry *geometry, CConfig *config) {

    //This function will be revised soon!//

}


CNSSolver::CNSSolver(void) : CEulerSolver() {

    CDrag_Visc = NULL;
    CLift_Visc = NULL;
    CSideForce_Visc = NULL;
    CEff_Visc = NULL;
    CFx_Visc = NULL;
    CFy_Visc = NULL;
    CFz_Visc = NULL;
    CMx_Visc = NULL;
    CMy_Visc = NULL;
    CMz_Visc = NULL;
    ForceViscous = NULL;
    MomentViscous = NULL;
    CSkinFriction = NULL;
    Surface_CLift_Visc = NULL;
    Surface_CDrag_Visc = NULL;
    Surface_CSideForce_Visc = NULL;
    Surface_CEff_Visc = NULL;
    Surface_CFx_Visc = NULL;
    Surface_CFy_Visc = NULL;
    Surface_CFz_Visc = NULL;
    Surface_CMx_Visc = NULL;
    Surface_CMy_Visc = NULL;
    Surface_CMz_Visc = NULL;
    CMerit_Visc = NULL;
    CT_Visc = NULL;
    CQ_Visc = NULL;

}

CNSSolver::CNSSolver(CGeometry *geometry, CConfig *config, unsigned short iMesh) : CEulerSolver() {

    unsigned long iPoint, counter_local = 0, counter_global = 0, iVertex;
    unsigned short iVar, iDim, iMarker, nLineLets;
    double Density, Velocity2, Pressure, Temperature;

    int rank = MASTER_NODE;
#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

    bool compressible = (config->GetKind_Regime() == COMPRESSIBLE);
    bool incompressible = (config->GetKind_Regime() == INCOMPRESSIBLE);
    bool roe_turkel = (config->GetKind_Upwind_Flow() == TURKEL);
    bool low_mach_prec = config->Low_Mach_Preconditioning();

    CDrag_Visc = NULL; CLift_Visc = NULL; CSideForce_Visc = NULL; CEff_Visc = NULL;
    CFx_Visc = NULL;   CFy_Visc = NULL; CFz_Visc = NULL;
    CMx_Visc = NULL;   CMy_Visc = NULL; CMz_Visc = NULL;
    Surface_CLift_Visc = NULL; Surface_CDrag_Visc = NULL; Surface_CSideForce_Visc = NULL; Surface_CEff_Visc = NULL;
    Surface_CFx_Visc = NULL;   Surface_CFy_Visc = NULL; Surface_CFz_Visc = NULL;
    Surface_CMx_Visc = NULL;   Surface_CMy_Visc = NULL; Surface_CMz_Visc = NULL;
    CMerit_Visc = NULL;      CT_Visc = NULL;      CQ_Visc = NULL;
    MaxHeatFlux_Visc = NULL; ForceViscous = NULL; MomentViscous = NULL;
    CSkinFriction = NULL;    Cauchy_Serie = NULL; Heat_Visc = NULL;

    //..Initializing quantities for the average process for internal flow are not included..//
    //..Initializing primitive quantities for turboperformace are not included..//
    //..Initializing quantities for Giles BC are not included..//

    Gamma = config->GetGamma();
    Gamma_Minus_One = Gamma - 1.0;

    nDim = 3;//geometry->GetnDim();
    if (incompressible) { nVar = nDim+1; nPrimVar = nDim+5; nPrimVarGrad = nDim+3; }
    if (compressible)   { nVar = nDim+2;
        nPrimVar = nDim+9; nPrimVarGrad = nDim+4;
        nSecondaryVar = 8; nSecondaryVarGrad = 2;
    }

    nVarGrad = nPrimVarGrad;

    nMarker      = config->GetnMarker_All();
    nElem       = geometry->GetnElem();
    nElemDomain = geometry->GetnElemDomain();

    nElem_Bound = new unsigned long[nMarker];
    for (iMarker = 0; iMarker < nMarker; iMarker++)
        nElem_Bound[iMarker] = geometry->nElem_Bound[iMarker];

    SetNondimensionalization(geometry, config, iMesh);

    elem = new CVariable*[nElem];

    Residual      = new double[nVar]; for (iVar = 0; iVar < nVar; iVar++) Residual[iVar]      = 0.0;
    Residual_RMS  = new double[nVar]; for (iVar = 0; iVar < nVar; iVar++) Residual_RMS[iVar]  = 0.0;
    Residual_Max  = new double[nVar]; for (iVar = 0; iVar < nVar; iVar++) Residual_Max[iVar]  = 0.0;
    Residual_i    = new double[nVar]; for (iVar = 0; iVar < nVar; iVar++) Residual_i[iVar]    = 0.0;
    Residual_j    = new double[nVar]; for (iVar = 0; iVar < nVar; iVar++) Residual_j[iVar]    = 0.0;
    Res_Conv      = new double[nVar]; for (iVar = 0; iVar < nVar; iVar++) Res_Conv[iVar]      = 0.0;
    Res_Visc      = new double[nVar]; for (iVar = 0; iVar < nVar; iVar++) Res_Visc[iVar]      = 0.0;
    Res_Sour      = new double[nVar]; for (iVar = 0; iVar < nVar; iVar++) Res_Sour[iVar]      = 0.0;

    Point_Max     = new unsigned long[nVar];  for (iVar = 0; iVar < nVar; iVar++) Point_Max[iVar] = 0;

    Point_Max_Coord = new double*[nVar];
    for (iVar = 0; iVar < nVar; iVar++) {
        Point_Max_Coord[iVar] = new double[nDim];
        for (iDim = 0; iDim < nDim; iDim++) Point_Max_Coord[iVar][iDim] = 0.0;
    }

    Solution   = new double[nVar]; for (iVar = 0; iVar < nVar; iVar++) Solution[iVar]   = 0.0;
    Solution_i = new double[nVar]; for (iVar = 0; iVar < nVar; iVar++) Solution_i[iVar] = 0.0;
    Solution_j = new double[nVar]; for (iVar = 0; iVar < nVar; iVar++) Solution_j[iVar] = 0.0;
    Vector   = new double[nDim]; for (iDim = 0; iDim < nDim; iDim++) Vector[iDim]   = 0.0;
    Vector_i = new double[nDim]; for (iDim = 0; iDim < nDim; iDim++) Vector_i[iDim] = 0.0;
    Vector_j = new double[nDim]; for (iDim = 0; iDim < nDim; iDim++) Vector_j[iDim] = 0.0;
    Primitive   = new double[nPrimVar]; for (iVar = 0; iVar < nPrimVar; iVar++) Primitive[iVar]   = 0.0;
    Primitive_Face   = new double[nPrimVar]; for (iVar = 0; iVar < nPrimVar; iVar++) Primitive_Face[iVar]   = 0.0;
    Primitive_i = new double[nPrimVar]; for (iVar = 0; iVar < nPrimVar; iVar++) Primitive_i[iVar] = 0.0;
    Primitive_j = new double[nPrimVar]; for (iVar = 0; iVar < nPrimVar; iVar++) Primitive_j[iVar] = 0.0;
    Secondary_i = new double[nSecondaryVar]; for (iVar = 0; iVar < nSecondaryVar; iVar++) Secondary_i[iVar] = 0.0;
    Secondary_j = new double[nSecondaryVar]; for (iVar = 0; iVar < nSecondaryVar; iVar++) Secondary_j[iVar] = 0.0;

    if (config->GetKind_ConvNumScheme_Flow() == SPACE_CENTERED) {
        iPoint_UndLapl = new double [nElem];
        jPoint_UndLapl = new double [nElem];
    }

    if (roe_turkel || low_mach_prec) {
        LowMach_Precontioner = new double* [nVar];
        for (iVar = 0; iVar < nVar; iVar ++)
            LowMach_Precontioner[iVar] = new double[nVar];
    }

    LinSysSol.Initialize(nElem, nElemDomain, nVar, 0.0);
    LinSysRes.Initialize(nElem, nElemDomain, nVar, 0.0);

    if (config->GetKind_TimeIntScheme_Flow() == EULER_IMPLICIT) {

        Jacobian_i = new double* [nVar];
        Jacobian_j = new double* [nVar];
        for (iVar = 0; iVar < nVar; iVar++) {
            Jacobian_i[iVar] = new double [nVar];
            Jacobian_j[iVar] = new double [nVar];
        }

        if (rank == MASTER_NODE) cout << "Initialize Jacobian structure (Navier-Stokes). MG level: " << iMesh <<"." << endl;
        Jacobian.Initialize(nElem, nElemDomain, nVar, nVar, true, geometry, config);

        if ((config->GetKind_Linear_Solver_Prec() == LINELET) ||
                (config->GetKind_Linear_Solver() == SMOOTHER_LINELET)) {
            nLineLets = Jacobian.BuildLineletPreconditioner(geometry, config);
            if (rank == MASTER_NODE) cout << "Compute linelet structure. " << nLineLets << " elements in each line (average)." << endl;
        }

    } else {
        if (rank == MASTER_NODE)
            cout << "Explicit scheme. No Jacobian structure (Navier-Stokes). MG level: " << iMesh <<"." << endl;
    }

    if (config->GetKind_Gradient_Method() == WEIGHTED_LEAST_SQUARES) {

        Smatrix = new double* [nDim];
        for (iDim = 0; iDim < nDim; iDim++)
            Smatrix[iDim] = new double [nDim];

        cvector = new double* [nPrimVarGrad];
        for (iVar = 0; iVar < nPrimVarGrad; iVar++)
            cvector[iVar] = new double [nDim];
    }

    CharacPrimVar = new double** [nMarker];
    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        CharacPrimVar[iMarker] = new double* [geometry->nElem_Bound[iMarker]];
        for (iVertex = 0; iVertex < geometry->nElem_Bound[iMarker]; iVertex++) {
            CharacPrimVar[iMarker][iVertex] = new double [nPrimVar];
            for (iVar = 0; iVar < nPrimVar; iVar++) {
                CharacPrimVar[iMarker][iVertex][iVar] = 0.0;
            }
        }
    }

    //..Allocation for DonorPrimVar, HeatConjugateVar, DonorGlobalIndex, ActDisk_DeltaP, ActDisk_DeltaT, Inlet_Ttotal, Inlet_Ptotal, Inlet_FlowDir are not included..//

    CPressure = new double* [nMarker];
    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        CPressure[iMarker] = new double [geometry->nElem_Bound[iMarker]];
        for (iVertex = 0; iVertex < geometry->nElem_Bound[iMarker]; iVertex++) {
            CPressure[iMarker][iVertex] = 0.0;
        }
    }

    CPressureTarget = new double* [nMarker];
    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        CPressureTarget[iMarker] = new double [geometry->nElem_Bound[iMarker]];
        for (iVertex = 0; iVertex < geometry->nElem_Bound[iMarker]; iVertex++) {
            CPressureTarget[iMarker][iVertex] = 0.0;
        }
    }

    HeatFlux = new double* [nMarker];
    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        HeatFlux[iMarker] = new double [geometry->nElem_Bound[iMarker]];
        for (iVertex = 0; iVertex < geometry->nElem_Bound[iMarker]; iVertex++) {
            HeatFlux[iMarker][iVertex] = 0.0;
        }
    }

    HeatFluxTarget = new double* [nMarker];
    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        HeatFluxTarget[iMarker] = new double [geometry->nElem_Bound[iMarker]];
        for (iVertex = 0; iVertex < geometry->nElem_Bound[iMarker]; iVertex++) {
            HeatFluxTarget[iMarker][iVertex] = 0.0;
        }
    }

    YPlus = new double* [nMarker];
    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        YPlus[iMarker] = new double [geometry->nElem_Bound[iMarker]];
        for (iVertex = 0; iVertex < geometry->nElem_Bound[iMarker]; iVertex++) {
            YPlus[iMarker][iVertex] = 0.0;
        }
    }

    CSkinFriction = new double* [nMarker];
    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        CSkinFriction[iMarker] = new double [geometry->nElem_Bound[iMarker]];
        for (iVertex = 0; iVertex < geometry->nElem_Bound[iMarker]; iVertex++) {
            CSkinFriction[iMarker][iVertex] = 0.0;
        }
    }

    ForceInviscid  = new double[3];
    MomentInviscid = new double[3];
    CDrag_Inv      = new double[nMarker];
    CLift_Inv      = new double[nMarker];
    CSideForce_Inv = new double[nMarker];
    CEff_Inv       = new double[nMarker];
    CFx_Inv        = new double[nMarker];
    CFy_Inv        = new double[nMarker];
    CFz_Inv        = new double[nMarker];
    CMx_Inv        = new double[nMarker];
    CMy_Inv        = new double[nMarker];
    CMz_Inv        = new double[nMarker];
    ForceViscous     = new double[3];
    MomentViscous    = new double[3];
    CDrag_Visc       = new double[nMarker];
    CLift_Visc       = new double[nMarker];
    CSideForce_Visc  = new double[nMarker];
    CMx_Visc         = new double[nMarker];
    CMy_Visc         = new double[nMarker];
    CMz_Visc         = new double[nMarker];
    CEff_Visc        = new double[nMarker];
    CFx_Visc         = new double[nMarker];
    CFy_Visc         = new double[nMarker];
    CFz_Visc         = new double[nMarker];
    CMerit_Visc      = new double[nMarker];
    CT_Visc          = new double[nMarker];
    CQ_Visc          = new double[nMarker];
    Heat_Visc        = new double[nMarker];
    MaxHeatFlux_Visc = new double[nMarker];
    Surface_CLift_Inv      = new double[config->GetnMarker_Monitoring()];
    Surface_CDrag_Inv      = new double[config->GetnMarker_Monitoring()];
    Surface_CSideForce_Inv = new double[config->GetnMarker_Monitoring()];
    Surface_CEff_Inv       = new double[config->GetnMarker_Monitoring()];
    Surface_CFx_Inv        = new double[config->GetnMarker_Monitoring()];
    Surface_CFy_Inv        = new double[config->GetnMarker_Monitoring()];
    Surface_CFz_Inv        = new double[config->GetnMarker_Monitoring()];
    Surface_CMx_Inv        = new double[config->GetnMarker_Monitoring()];
    Surface_CMy_Inv        = new double[config->GetnMarker_Monitoring()];
    Surface_CMz_Inv        = new double[config->GetnMarker_Monitoring()];
    Surface_CLift          = new double[config->GetnMarker_Monitoring()];
    Surface_CDrag          = new double[config->GetnMarker_Monitoring()];
    Surface_CSideForce     = new double[config->GetnMarker_Monitoring()];
    Surface_CEff           = new double[config->GetnMarker_Monitoring()];
    Surface_CFx            = new double[config->GetnMarker_Monitoring()];
    Surface_CFy            = new double[config->GetnMarker_Monitoring()];
    Surface_CFz            = new double[config->GetnMarker_Monitoring()];
    Surface_CMx            = new double[config->GetnMarker_Monitoring()];
    Surface_CMy            = new double[config->GetnMarker_Monitoring()];
    Surface_CMz            = new double[config->GetnMarker_Monitoring()];
    Surface_CLift_Visc      = new double[config->GetnMarker_Monitoring()];
    Surface_CDrag_Visc      = new double[config->GetnMarker_Monitoring()];
    Surface_CSideForce_Visc = new double[config->GetnMarker_Monitoring()];
    Surface_CEff_Visc       = new double[config->GetnMarker_Monitoring()];
    Surface_CFx_Visc        = new double[config->GetnMarker_Monitoring()];
    Surface_CFy_Visc        = new double[config->GetnMarker_Monitoring()];
    Surface_CFz_Visc        = new double[config->GetnMarker_Monitoring()];
    Surface_CMx_Visc        = new double[config->GetnMarker_Monitoring()];
    Surface_CMy_Visc        = new double[config->GetnMarker_Monitoring()];
    Surface_CMz_Visc        = new double[config->GetnMarker_Monitoring()];
    CMerit_Inv = new double[nMarker];
    CT_Inv     = new double[nMarker];
    CQ_Inv     = new double[nMarker];
    CMerit_Visc = new double[nMarker];
    CT_Visc     = new double[nMarker];
    CQ_Visc     = new double[nMarker];
    CNearFieldOF_Inv = new double[nMarker];

    //..Allocations for Engine Simulation are not included..//

    Total_CDrag   = 0.0;	Total_CLift       = 0.0;  Total_CSideForce   = 0.0;
    Total_CMx     = 0.0;	Total_CMy         = 0.0;  Total_CMz          = 0.0;
    Total_CEff    = 0.0;	Total_CNearFieldOF = 0.0;
    Total_CFx     = 0.0;	Total_CFy         = 0.0;  Total_CFz          = 0.0;
    Total_CT      = 0.0;	Total_CQ          = 0.0;  Total_CMerit       = 0.0;
    Total_MaxHeat = 0.0;  Total_Heat        = 0.0;
    Total_CpDiff  = 0.0;  Total_HeatFluxDiff    = 0.0;
    Density_Inf     = config->GetDensity_FreeStreamND();
    Pressure_Inf    = config->GetPressure_FreeStreamND();
    Velocity_Inf    = config->GetVelocity_FreeStreamND();
    Energy_Inf      = config->GetEnergy_FreeStreamND();
    Temperature_Inf = config->GetTemperature_FreeStreamND();
    Viscosity_Inf   = config->GetViscosity_FreeStreamND();
    Mach_Inf        = config->GetMach();
    Prandtl_Lam     = config->GetPrandtl_Lam();
    Prandtl_Turb    = config->GetPrandtl_Turb();
    Tke_Inf         = config->GetTke_FreeStreamND();

    //..Initializing the secondary values for direct derivative approxiations are not included..//
    //..Initializing fan face pressure, fan face mach number, and mass flow rate are not included..//
    //..Initializing quantities for SlidingMesh Interface are not included..//

    for (iPoint = 0; iPoint < nElem; iPoint++)
        elem[iPoint] = new CNSVariable(Density_Inf, Velocity_Inf, Energy_Inf, nDim, nVar, config);

    if (compressible) {
        counter_local = 0;
        for (iPoint = 0; iPoint < nElem; iPoint++) {
            Density = elem[iPoint]->GetSolution(0);
            Velocity2 = 0.0;
            for (iDim = 0; iDim < nDim; iDim++)
                Velocity2 += (elem[iPoint]->GetSolution(iDim+1)/Density)*(elem[iPoint]->GetSolution(iDim+1)/Density);
            double StaticEnergy= elem[iPoint]->GetSolution(nDim+1)/Density-0.5*Velocity2;
            FluidModel->SetTDState_rhoe(Density, StaticEnergy);
            Pressure= FluidModel->GetPressure();
            Temperature= FluidModel->GetTemperature();
            if ((Pressure < 0.0) || (Temperature < 0.0)) {
                Solution[0] = Density_Inf;
                for (iDim = 0; iDim < nDim; iDim++)
                    Solution[iDim+1] = Velocity_Inf[iDim]*Density_Inf;
                Solution[nDim+1] = Energy_Inf*Density_Inf;
                elem[iPoint]->SetSolution(Solution);
                elem[iPoint]->SetSolution_Old(Solution);
                counter_local++;
            }
        }

        if (config->GetConsole_Output_Verb() == VERB_HIGH) {

#ifdef HAVE_MPI
            MPI_Reduce(&counter_local, &counter_global, 1, MPI_UNSIGNED_LONG, MPI_SUM, MASTER_NODE, MPI_COMM_WORLD);
#else
            counter_global = counter_local;
#endif

            if ((rank == MASTER_NODE) && (counter_global != 0))
                cout << "Warning. The original solution contains "<< counter_global << " points that are not physical." << endl;
        }

    }

    if (incompressible) {
        for (iPoint = 0; iPoint < nElem; iPoint++) {
            elem[iPoint]->SetDensityInc(Density_Inf);
            elem[iPoint]->SetLaminarViscosityInc(Viscosity_Inf);
        }
    }

    if (config->GetKind_ConvNumScheme_Flow() == SPACE_CENTERED)
        space_centered = true;
    else space_centered = false;

    if (config->GetKind_TimeIntScheme_Flow() == EULER_IMPLICIT) euler_implicit = true;
    else euler_implicit = false;

    if (config->GetKind_Gradient_Method() == WEIGHTED_LEAST_SQUARES) least_squares = true;
    else least_squares = false;

    Set_MPI_Solution(geometry, config);

}

CNSSolver::~CNSSolver(void) {

    unsigned short iMarker;

    if (CDrag_Visc != NULL)       delete [] CDrag_Visc;
    if (CLift_Visc != NULL)       delete [] CLift_Visc;
    if (CSideForce_Visc != NULL)  delete [] CSideForce_Visc;
    if (CFx_Visc != NULL)         delete [] CFx_Visc;
    if (CFy_Visc != NULL)         delete [] CFy_Visc;
    if (CFz_Visc != NULL)         delete [] CFz_Visc;
    if (CMx_Visc != NULL)         delete [] CMx_Visc;
    if (CMy_Visc != NULL)         delete [] CMy_Visc;
    if (CMz_Visc != NULL)         delete [] CMz_Visc;
    if (CEff_Visc != NULL)        delete [] CEff_Visc;
    if (CMerit_Visc != NULL)      delete [] CMerit_Visc;
    if (CT_Visc != NULL)          delete [] CT_Visc;
    if (CQ_Visc != NULL)          delete [] CQ_Visc;
    if (Heat_Visc != NULL)        delete [] Heat_Visc;
    if (MaxHeatFlux_Visc != NULL) delete [] MaxHeatFlux_Visc;
    if (ForceViscous != NULL)     delete [] ForceViscous;
    if (MomentViscous != NULL)    delete [] MomentViscous;
    if (Surface_CLift_Visc != NULL)      delete [] Surface_CLift_Visc;
    if (Surface_CDrag_Visc != NULL)      delete [] Surface_CDrag_Visc;
    if (Surface_CSideForce_Visc != NULL) delete [] Surface_CSideForce_Visc;
    if (Surface_CEff_Visc != NULL)       delete [] Surface_CEff_Visc;
    if (Surface_CFx_Visc != NULL)        delete [] Surface_CFx_Visc;
    if (Surface_CFy_Visc != NULL)        delete [] Surface_CFy_Visc;
    if (Surface_CFz_Visc != NULL)        delete [] Surface_CFz_Visc;
    if (Surface_CMx_Visc != NULL)        delete [] Surface_CMx_Visc;
    if (Surface_CMy_Visc != NULL)        delete [] Surface_CMy_Visc;
    if (Surface_CMz_Visc != NULL)        delete [] Surface_CMz_Visc;
    if (Cauchy_Serie != NULL) delete [] Cauchy_Serie;

    if (CSkinFriction != NULL) {
        for (iMarker = 0; iMarker < nMarker; iMarker++) {
            delete CSkinFriction[iMarker];
        }
        delete [] CSkinFriction;
    }

    if (nElem_Bound != NULL)  delete [] nElem_Bound;

}

void CNSSolver::Preprocessing(CGeometry *geometry, CSolver **solver_container, CConfig *config, unsigned short iMesh, unsigned short iRKStep, unsigned short RunTime_EqSystem, bool Output) {

    unsigned long iPoint=0, ErrorCounter = 0;
    double StrainMag = 0.0, Omega = 0.0, *Vorticity=NULL;
    bool RightSol = true;

#ifdef HAVE_MPI
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

    unsigned long ExtIter     = config->GetExtIter();
    unsigned short turb_model = config->GetKind_Turb_Model();
    bool implicit             = (config->GetKind_TimeIntScheme_Flow() == EULER_IMPLICIT);
    bool center               = (config->GetKind_ConvNumScheme_Flow() == SPACE_CENTERED); //|| (cont_adjoint && config->GetKind_ConvNumScheme_AdjFlow() == SPACE_CENTERED);
    bool center_jst           = center && config->GetKind_Centered_Flow() == JST;
    bool limiter_flow         = ((config->GetKind_SlopeLimit_Flow() != NO_LIMITER) && (ExtIter <= config->GetLimiterIter()));// && !(disc_adjoint && config->GetFrozen_Limiter_Disc()));
    bool limiter_turb         = ((config->GetKind_SlopeLimit_Turb() != NO_LIMITER) && (ExtIter <= config->GetLimiterIter()));// && !(disc_adjoint && config->GetFrozen_Limiter_Disc()));
    bool fixed_cl             = config->GetFixed_CL_Mode();
    bool van_albada           = config->GetKind_SlopeLimit_Flow() == VAN_ALBADA_EDGE;
    bool tkeNeeded            = (turb_model == SST);
    bool limiter_visc         = config->GetViscous_Limiter_Flow();
    unsigned short kind_row_dissipation = config->GetKind_RoeLowDiss();
    bool roe_low_dissipation  = (kind_row_dissipation != NO_ROELOWDISS) && (config->GetKind_Upwind_Flow() == ROE);
    double eddy_visc = 0.0, turb_ke = 0.0, DES_LengthScale = 0.0;

    if (fixed_cl) { SetFarfield_AoA(geometry, solver_container, config, iMesh, Output); }

    for (iPoint = 0; iPoint < nElem; iPoint ++) {
        if (turb_model != NONE) {
            eddy_visc = solver_container[TURB_SOL]->elem[iPoint]->GetmuT();
            if (tkeNeeded) turb_ke = solver_container[TURB_SOL]->elem[iPoint]->GetSolution(0);

            if (config->GetKind_HybridRANSLES() != NO_HYBRIDRANSLES){
                DES_LengthScale = solver_container[TURB_SOL]->elem[iPoint]->GetDES_LengthScale();
            }
        }

        elem[iPoint]->SetNon_Physical(false);
        RightSol = elem[iPoint]->SetPrimVar_Compressible(eddy_visc, turb_ke, FluidModel);
        elem[iPoint]->SetSecondaryVar_Compressible(FluidModel);

        if (!RightSol) { elem[iPoint]->SetNon_Physical(true); ErrorCounter++; }

        elem[iPoint]->SetDES_LengthScale(DES_LengthScale);

        if (!Output) LinSysRes.SetBlock_Zero(iPoint);
    }

    //..the enging and actuator disk computations are not included..//

    if (center && !Output) {
      SetMax_Eigenvalue(geometry, config);
      if ((center_jst) && (iMesh == MESH_0)) {
        SetCentered_Dissipation_Sensor(geometry, config);
        SetUndivided_Laplacian(geometry, config);
      }
    }

    if (roe_low_dissipation){
      SetRoe_Dissipation(geometry, config);
      if (kind_row_dissipation == FD_DUCROS || kind_row_dissipation == NTS_DUCROS){
        SetUpwind_Ducros_Sensor(geometry, config);
      }
    }

    if (config->GetKind_Gradient_Method() == GREEN_GAUSS) {
        SetPrimitive_Gradient_GG(geometry, config);
    }

    if (config->GetKind_Gradient_Method() == WEIGHTED_LEAST_SQUARES) {
        SetPrimitive_Gradient_LS(geometry, config);
    }

    if ((iMesh == MESH_0) && (limiter_flow || limiter_turb)
            && !Output && !van_albada) { SetPrimitive_Limiter(geometry, config); }

    StrainMag_Max = 0.0; Omega_Max = 0.0;
    for (iPoint = 0; iPoint < nElem; iPoint++) {
        solver_container[FLOW_SOL]->elem[iPoint]->SetVorticity(limiter_visc);
        solver_container[FLOW_SOL]->elem[iPoint]->SetStrainMag(limiter_visc);

        StrainMag = solver_container[FLOW_SOL]->elem[iPoint]->GetStrainMag();
        Vorticity = solver_container[FLOW_SOL]->elem[iPoint]->GetVorticity();
        Omega = sqrt(Vorticity[0]*Vorticity[0]+ Vorticity[1]*Vorticity[1]+ Vorticity[2]*Vorticity[2]);

        StrainMag_Max = max(StrainMag_Max, StrainMag);
        Omega_Max = max(Omega_Max, Omega);
    }

    if (implicit) Jacobian.SetValZero();

    if (config->GetConsole_Output_Verb() == VERB_HIGH) {

#ifdef HAVE_MPI
        unsigned long MyErrorCounter = ErrorCounter; ErrorCounter = 0;
        double MyOmega_Max = Omega_Max; Omega_Max = 0.0;
        double MyStrainMag_Max = StrainMag_Max; StrainMag_Max = 0.0;

        MPI_Allreduce(&MyErrorCounter, &ErrorCounter, 1, MPI_UNSIGNED_LONG, MPI_SUM, MPI_COMM_WORLD);
        MPI_Allreduce(&MyStrainMag_Max, &StrainMag_Max, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
        MPI_Allreduce(&MyOmega_Max, &Omega_Max, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
#endif

        if (iMesh == MESH_0) {
            config->SetNonphysical_Points(ErrorCounter);
            solver_container[FLOW_SOL]->SetStrainMag_Max(StrainMag_Max);
            solver_container[FLOW_SOL]->SetOmega_Max(Omega_Max);
        }
    }
}

unsigned long CNSSolver::SetPrimitive_Variables(CSolver **solver_container, CConfig *config, bool Output) {

    //..This section will not be required any more..//

}


void CNSSolver::SetTime_Step(CGeometry *geometry, CSolver **solver_container, CConfig *config, unsigned short iMesh, unsigned long Iteration) {

    int rank = MASTER_NODE;
#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

    double Area, Vol, Mean_SoundSpeed = 0.0, Mean_ProjVel = 0.0, Lambda, Local_Delta_Time, Local_Delta_Time_Visc,
            Global_Delta_Time = 1E6, Mean_LaminarVisc = 0.0, Mean_EddyVisc = 0.0, Mean_Density = 0.0, Lambda_1, Lambda_2, K_v = 0.25, Global_Delta_UnstTimeND, *Normal;
    unsigned long iFace, iVertex, iPoint = 0, jPoint = 0;
    unsigned short iDim, iMarker;
    double ProjVel, ProjVel_i, ProjVel_j;

    bool implicit = (config->GetKind_TimeIntScheme_Flow() == EULER_IMPLICIT);
    bool compressible = (config->GetKind_Regime() == COMPRESSIBLE);
    bool dual_time = ((config->GetUnsteady_Simulation() == DT_STEPPING_1ST) ||
                      (config->GetUnsteady_Simulation() == DT_STEPPING_2ND));

    Min_Delta_Time = 1.E6; Max_Delta_Time = 0.0;

    for (iPoint = 0; iPoint < nElemDomain; iPoint++) {
        elem[iPoint]->SetMax_Lambda_Inv(0.0);
        elem[iPoint]->SetMax_Lambda_Visc(0.0);
    }

    for (iFace = 0; iFace < geometry->GetnFace(); iFace++) {
        iPoint = geometry->face[iFace]->GetElems(0);
        Normal = geometry->face[iFace]->GetNormal_Face();
        Area = 0.0; for (iDim = 0; iDim < nDim; iDim++) Area += Normal[iDim]*Normal[iDim]; Area = sqrt(Area);

        if(geometry->face[iFace]->GetElems(1) != -1){
            jPoint = geometry->face[iFace]->GetElems(1);

            if (compressible) {
                Mean_ProjVel = 0.5 * (elem[iPoint]->GetProjVel(Normal) + elem[jPoint]->GetProjVel(Normal));
                Mean_SoundSpeed = 0.5 * (elem[iPoint]->GetSoundSpeed() + elem[jPoint]->GetSoundSpeed()) * Area;
            }

            //..Incompressible, Free Surface and Grid Movements are not included..//

            Lambda = fabs(Mean_ProjVel) + Mean_SoundSpeed ;
            if (geometry->elem[iPoint]->GetDomain()) elem[iPoint]->AddMax_Lambda_Inv(Lambda);
            if (geometry->elem[jPoint]->GetDomain()) elem[jPoint]->AddMax_Lambda_Inv(Lambda);

            if (compressible) {
                Mean_LaminarVisc = 0.5*(elem[iPoint]->GetLaminarViscosity() + elem[jPoint]->GetLaminarViscosity());
                Mean_EddyVisc    = 0.5*(elem[iPoint]->GetEddyViscosity() + elem[jPoint]->GetEddyViscosity());
                Mean_Density     = 0.5*(elem[iPoint]->GetSolution(0) + elem[jPoint]->GetSolution(0));
            }

            //..Incompressible, Free surface are not included..//

            Lambda_1 = (4.0/3.0)*(Mean_LaminarVisc + Mean_EddyVisc);
            Lambda_2 = (1.0 + (Prandtl_Lam/Prandtl_Turb)*(Mean_EddyVisc/Mean_LaminarVisc))*(Gamma*Mean_LaminarVisc/Prandtl_Lam);
            Lambda = (Lambda_1 + Lambda_2)*Area*Area/Mean_Density;

            if (geometry->elem[iPoint]->GetDomain()) elem[iPoint]->AddMax_Lambda_Visc(Lambda);
            if (geometry->elem[jPoint]->GetDomain()) elem[jPoint]->AddMax_Lambda_Visc(Lambda);

        }
    }

    for (iMarker = 0; iMarker < geometry->GetnMarker(); iMarker++) {

        if(config->GetMarker_All_KindBC(iMarker) != SEND_RECEIVE){
            for (iVertex = 0; iVertex < geometry->GetnElem_Bound(iMarker); iVertex++) {

                iFace = geometry->bound[iMarker][iVertex]->GetGlobalFace();
                iPoint = geometry->face[iFace]->GetElems(0);
                Normal = geometry->face[iFace]->GetNormal_Face();
                Area = 0.0; for (iDim = 0; iDim < nDim; iDim++) Area += Normal[iDim]*Normal[iDim]; Area = sqrt(Area);

                if (compressible) {
                    Mean_ProjVel = elem[iPoint]->GetProjVel(Normal);
                    Mean_SoundSpeed = elem[iPoint]->GetSoundSpeed() * Area;
                }

                //..Incompressible, Free Surface and Grid Movements are not included..//

                Lambda = fabs(Mean_ProjVel) + Mean_SoundSpeed;
                if (geometry->elem[iPoint]->GetDomain()) {
                    elem[iPoint]->AddMax_Lambda_Inv(Lambda);
                }

                if (compressible) {
                    Mean_LaminarVisc = elem[iPoint]->GetLaminarViscosity();
                    Mean_EddyVisc    = elem[iPoint]->GetEddyViscosity();
                    Mean_Density     = elem[iPoint]->GetSolution(0);
                }

                //..Incompressible, Free surface are not included..//

                Lambda_1 = (4.0/3.0)*(Mean_LaminarVisc + Mean_EddyVisc);
                Lambda_2 = (1.0 + (Prandtl_Lam/Prandtl_Turb)*(Mean_EddyVisc/Mean_LaminarVisc))*(Gamma*Mean_LaminarVisc/Prandtl_Lam);
                Lambda = (Lambda_1 + Lambda_2)*Area*Area/Mean_Density;
                if (geometry->elem[iPoint]->GetDomain()) elem[iPoint]->AddMax_Lambda_Visc(Lambda);
            }
        }
    }

    for (iPoint = 0; iPoint < nElemDomain; iPoint++) {
        Vol = geometry->elem[iPoint]->GetVolume();
        if (Vol != 0.0) {
            Local_Delta_Time = config->GetCFL(iMesh)*Vol / elem[iPoint]->GetMax_Lambda_Inv();
            Local_Delta_Time_Visc = config->GetCFL(iMesh)*K_v*Vol*Vol/ elem[iPoint]->GetMax_Lambda_Visc();
            Local_Delta_Time = min(Local_Delta_Time, Local_Delta_Time_Visc);
            Global_Delta_Time = min(Global_Delta_Time, Local_Delta_Time);
            Min_Delta_Time = min(Min_Delta_Time, Local_Delta_Time);
            Max_Delta_Time = max(Max_Delta_Time, Local_Delta_Time);

            if (Local_Delta_Time > config->GetMax_DeltaTime())
                Local_Delta_Time = config->GetMax_DeltaTime();

            elem[iPoint]->SetDelta_Time(Local_Delta_Time);
        }
        else {
            elem[iPoint]->SetDelta_Time(0.0);
        }

    }

    if (config->GetConsole_Output_Verb() == VERB_HIGH) {
#ifdef HAVE_MPI
        double rbuf_time, sbuf_time;
        sbuf_time = Min_Delta_Time;
        MPI_Reduce(&sbuf_time, &rbuf_time, 1, MPI_DOUBLE, MPI_MIN, MASTER_NODE, MPI_COMM_WORLD);
        MPI_Bcast(&rbuf_time, 1, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
        Min_Delta_Time = rbuf_time;

        sbuf_time = Max_Delta_Time;
        MPI_Reduce(&sbuf_time, &rbuf_time, 1, MPI_DOUBLE, MPI_MAX, MASTER_NODE, MPI_COMM_WORLD);
        MPI_Bcast(&rbuf_time, 1, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
        Max_Delta_Time = rbuf_time;
#endif
    }

    if (config->GetUnsteady_Simulation() == TIME_STEPPING) {
#ifdef HAVE_MPI
        double rbuf_time, sbuf_time;
        sbuf_time = Global_Delta_Time;
        MPI_Reduce(&sbuf_time, &rbuf_time, 1, MPI_DOUBLE, MPI_MIN, MASTER_NODE, MPI_COMM_WORLD);
        MPI_Bcast(&rbuf_time, 1, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
        Global_Delta_Time = rbuf_time;
#endif
        for(iPoint = 0; iPoint < nElemDomain; iPoint++)
            elem[iPoint]->SetDelta_Time(Global_Delta_Time);
    }

    if ((dual_time) && (Iteration == 0) && (config->GetUnst_CFL() != 0.0) && (iMesh == MESH_0)) {
        Global_Delta_UnstTimeND = config->GetUnst_CFL()*Global_Delta_Time/config->GetCFL(iMesh);

#ifdef HAVE_MPI
        double rbuf_time, sbuf_time;
        sbuf_time = Global_Delta_UnstTimeND;
        MPI_Reduce(&sbuf_time, &rbuf_time, 1, MPI_DOUBLE, MPI_MIN, MASTER_NODE, MPI_COMM_WORLD);
        MPI_Bcast(&rbuf_time, 1, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
        Global_Delta_UnstTimeND = rbuf_time;
#endif
        config->SetDelta_UnstTimeND(Global_Delta_UnstTimeND);
    }

    if (dual_time)
        for (iPoint = 0; iPoint < nElemDomain; iPoint++) {
            if (!implicit) {
                Local_Delta_Time = min((2.0/3.0)*config->GetDelta_UnstTimeND(), elem[iPoint]->GetDelta_Time());
                elem[iPoint]->SetDelta_Time(Local_Delta_Time);
            }
        }
}

void CNSSolver::Viscous_Residual(CGeometry *geometry, CSolver **solver_container, CNumerics *numerics,
                                 CConfig *config, unsigned short iMesh, unsigned short iRKStep) {

#ifdef HAVE_MPI
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif
    unsigned short iVar, iDim;
    unsigned long iPoint, jPoint, iFace;

    bool implicit = (config->GetKind_TimeIntScheme_Flow() == EULER_IMPLICIT);

    for (iFace = 0; iFace < geometry->GetnFace(); iFace++) {
        iPoint = geometry->face[iFace]->GetElems(0);

        if(geometry->face[iFace]->GetElems(1) != -1){

            jPoint = geometry->face[iFace]->GetElems(1);

            numerics->SetCoord(geometry->elem[iPoint]->GetCG(), geometry->elem[jPoint]->GetCG());

            numerics->SetNormal(geometry->face[iFace]->GetNormal_Face());

            numerics->SetPrimitive(elem[iPoint]->GetPrimitive(), elem[jPoint]->GetPrimitive());

            numerics->SetSecondary(elem[iPoint]->GetSecondary(), elem[jPoint]->GetSecondary());

            numerics->SetPrimVarGradient(elem[iPoint]->GetGradient_Primitive(), elem[jPoint]->GetGradient_Primitive());

            if (config->GetKind_Turb_Model() == SST)
                numerics->SetTurbKineticEnergy(solver_container[TURB_SOL]->elem[iPoint]->GetSolution(0),
                                               solver_container[TURB_SOL]->elem[jPoint]->GetSolution(0));

            numerics->ComputeResidual(Res_Visc, Jacobian_i, Jacobian_j, config);

            LinSysRes.SubtractBlock(iPoint, Res_Visc);
            LinSysRes.AddBlock(jPoint, Res_Visc);

            if (implicit) {
                Jacobian.SubtractBlock(iPoint, iPoint, Jacobian_i);
                Jacobian.SubtractBlock(iPoint, jPoint, Jacobian_j);
                Jacobian.AddBlock(jPoint, iPoint, Jacobian_i);
                Jacobian.AddBlock(jPoint, jPoint, Jacobian_j);
            }

        }
    }
}

void CNSSolver::Viscous_Forces(CGeometry *geometry, CConfig *config) {


    unsigned long iVertex, iPoint, iPointNormal;
    unsigned short Boundary, Monitoring, iMarker, iMarker_Monitoring, iDim, jDim;
    double Viscosity = 0.0, div_vel, MomentDist[3] = {0.0, 0.0, 0.0}, WallDist[3] = {0.0, 0.0, 0.0},
            *Coord, *Coord_Normal, Area, WallShearStress, TauNormal, factor, RefTemp, RefVel2,
            RefDensity, GradTemperature, Density = 0.0, WallDistMod, FrictionVel,
            UnitNormal[3] = {0.0, 0.0, 0.0}, TauElem[3] = {0.0, 0.0, 0.0}, TauTangent[3] = {0.0, 0.0, 0.0},
            Tau[3][3] = {{0.0, 0.0, 0.0},{0.0, 0.0, 0.0},{0.0, 0.0, 0.0}}, Force[3] = {0.0, 0.0, 0.0}, Cp, thermal_conductivity, MaxNorm = 8.0,
            Grad_Vel[3][3] = {{0.0, 0.0, 0.0},{0.0, 0.0, 0.0},{0.0, 0.0, 0.0}}, Grad_Temp[3] = {0.0, 0.0, 0.0},
            delta[3][3] = {{1.0, 0.0, 0.0},{0.0,1.0,0.0},{0.0,0.0,1.0}}, *Normal;

#ifdef HAVE_MPI
    double MyAllBound_CDrag_Visc, MyAllBound_CLift_Visc, MyAllBound_CSideForce_Visc, MyAllBound_CEff_Visc, MyAllBound_CMx_Visc, MyAllBound_CMy_Visc, MyAllBound_CMz_Visc, MyAllBound_CFx_Visc, MyAllBound_CFy_Visc, MyAllBound_CFz_Visc, MyAllBound_CT_Visc, MyAllBound_CQ_Visc, MyAllBound_CMerit_Visc, MyAllBound_HeatFlux_Visc, MyAllBound_MaxHeatFlux_Visc, *MySurface_CLift_Visc = NULL, *MySurface_CDrag_Visc = NULL, *MySurface_CSideForce_Visc = NULL, *MySurface_CEff_Visc = NULL, *MySurface_CFx_Visc = NULL, *MySurface_CFy_Visc = NULL, *MySurface_CFz_Visc = NULL, *MySurface_CMx_Visc = NULL, *MySurface_CMy_Visc = NULL, *MySurface_CMz_Visc = NULL;
#endif

    string Marker_Tag, Monitoring_Tag;

    double Alpha            = config->GetAoA()*PI_NUMBER/180.0;
    double Beta             = config->GetAoS()*PI_NUMBER/180.0;
    double RefAreaCoeff     = config->GetRefAreaCoeff();
    double RefLengthMoment  = config->GetRefLengthMoment();
    double Gas_Constant     = config->GetGas_ConstantND();
    double *Origin          = config->GetRefOriginMoment(0);
    bool compressible       = (config->GetKind_Regime() == COMPRESSIBLE);
    double Prandtl_Lam      = config->GetPrandtl_Lam();

    RefTemp    = Temperature_Inf;
    RefDensity = Density_Inf;

    //..grid movements are not included..//

        RefVel2 = 0.0;
        for (iDim = 0; iDim < nDim; iDim++)
            RefVel2  += Velocity_Inf[iDim]*Velocity_Inf[iDim];

    factor = 1.0 / (0.5*RefDensity*RefAreaCoeff*RefVel2);

    AllBound_CDrag_Visc = 0.0;    AllBound_CLift_Visc = 0.0;       AllBound_CSideForce_Visc = 0.0;
    AllBound_CMx_Visc = 0.0;      AllBound_CMy_Visc = 0.0;         AllBound_CMz_Visc = 0.0;
    AllBound_CFx_Visc = 0.0;      AllBound_CFy_Visc = 0.0;         AllBound_CFz_Visc = 0.0;
    AllBound_CT_Visc = 0.0;       AllBound_CQ_Visc = 0.0;          AllBound_CMerit_Visc = 0.0;
    AllBound_HeatFlux_Visc = 0.0; AllBound_MaxHeatFlux_Visc = 0.0; AllBound_CEff_Visc = 0.0;

    for (iMarker_Monitoring = 0; iMarker_Monitoring < config->GetnMarker_Monitoring(); iMarker_Monitoring++) {
        Surface_CLift_Visc[iMarker_Monitoring]      = 0.0; Surface_CDrag_Visc[iMarker_Monitoring]      = 0.0;
        Surface_CSideForce_Visc[iMarker_Monitoring] = 0.0; Surface_CEff_Visc[iMarker_Monitoring]       = 0.0;
        Surface_CFx_Visc[iMarker_Monitoring]        = 0.0; Surface_CFy_Visc[iMarker_Monitoring]        = 0.0;
        Surface_CFz_Visc[iMarker_Monitoring]        = 0.0; Surface_CMx_Visc[iMarker_Monitoring]        = 0.0;
        Surface_CMy_Visc[iMarker_Monitoring]        = 0.0; Surface_CMz_Visc[iMarker_Monitoring]        = 0.0;
    }

    for (iMarker = 0; iMarker < nMarker; iMarker++) {

        Boundary = config->GetMarker_All_KindBC(iMarker);
        Monitoring = config->GetMarker_All_Monitoring(iMarker);

        if (Monitoring == YES) {
            for (iMarker_Monitoring = 0; iMarker_Monitoring < config->GetnMarker_Monitoring(); iMarker_Monitoring++) {
                Monitoring_Tag = config->GetMarker_Monitoring(iMarker_Monitoring);
                Marker_Tag = config->GetMarker_All_TagBound(iMarker);
                if (Marker_Tag == Monitoring_Tag)
                    Origin = config->GetRefOriginMoment(iMarker_Monitoring);
            }
        }

        if ((Boundary == HEAT_FLUX) || (Boundary == ISOTHERMAL)) {

            CDrag_Visc[iMarker] = 0.0; CLift_Visc[iMarker] = 0.0;       CSideForce_Visc[iMarker] = 0.0;
            CMx_Visc[iMarker] = 0.0;   CMy_Visc[iMarker] = 0.0;         CMz_Visc[iMarker] = 0.0;
            CFx_Visc[iMarker] = 0.0;   CFy_Visc[iMarker] = 0.0;         CFz_Visc[iMarker] = 0.0;
            CT_Visc[iMarker] = 0.0;    CQ_Visc[iMarker] = 0.0;          CMerit_Visc[iMarker] = 0.0;
            Heat_Visc[iMarker] = 0.0;  MaxHeatFlux_Visc[iMarker] = 0.0; CEff_Visc[iMarker] = 0.0;

            for (iDim = 0; iDim < nDim; iDim++) ForceViscous[iDim] = 0.0;

            MomentViscous[0] = 0.0; MomentViscous[1] = 0.0; MomentViscous[2] = 0.0;

            for (iVertex = 0; iVertex < geometry->nElem_Bound[iMarker]; iVertex++) {

                iPointNormal = geometry->bound[iMarker][iVertex]->GetGlobalFace();
                iPoint = geometry->face[iPointNormal]->GetElems(0);
                Coord = geometry->elem[iPoint]->GetCG();
                Coord_Normal = geometry->face[iPointNormal]->GetCG();
                Normal = geometry->face[iPointNormal]->GetNormal_Face();
                Area = 0.0; for (iDim = 0; iDim < nDim; iDim++) Area += Normal[iDim]*Normal[iDim]; Area = sqrt(Area);

                for (iDim = 0; iDim < nDim; iDim++) {
                    UnitNormal[iDim] = Normal[iDim]/Area;
                    MomentDist[iDim] = Coord_Normal[iDim] - Origin[iDim];
                }

                for(iDim = 0; iDim < nDim; iDim++){
                    for(jDim = 0; jDim < nDim; jDim++){
                        Grad_Vel[iDim][jDim]=elem[iPoint]->GetGradient_Primitive(iDim+1, jDim);
                    }
                }

                for (iDim = 0; iDim < nDim; iDim++) {
                    Grad_Temp[jDim] = elem[iPoint]->GetGradient_Primitive(0, jDim);
                }

                if (compressible) {
                    Viscosity = elem[iPoint]->GetLaminarViscosity();
                    Density = elem[iPoint]->GetDensity();
                }

                //..Incompressible, Free surface are not included..//

                div_vel = 0.0; for (iDim = 0; iDim < nDim; iDim++) div_vel += Grad_Vel[iDim][iDim];

                for (iDim = 0; iDim < nDim; iDim++) {
                    for (jDim = 0 ; jDim < nDim; jDim++) {
                        Tau[iDim][jDim] = Viscosity*(Grad_Vel[jDim][iDim] + Grad_Vel[iDim][jDim]) - TWO3*Viscosity*div_vel*delta[iDim][jDim];
                    }
                }

                for (iDim = 0; iDim < nDim; iDim++) {
                    TauElem[iDim] = 0.0;
                    for (jDim = 0; jDim < nDim; jDim++) {
                        TauElem[iDim] += Tau[iDim][jDim]*UnitNormal[jDim];
                    }
                    //cout<<iDim<<"   "<<TauElem[iDim]<<endl;
                }

                TauNormal = 0.0; for (iDim = 0; iDim < nDim; iDim++) TauNormal += TauElem[iDim] * UnitNormal[iDim];

                for (iDim = 0; iDim < nDim; iDim++) TauTangent[iDim] = TauElem[iDim] - TauNormal * UnitNormal[iDim];

                WallShearStress = 0.0; for (iDim = 0; iDim < nDim; iDim++) WallShearStress += TauTangent[iDim]*TauTangent[iDim];
                WallShearStress = sqrt(WallShearStress);

                for (iDim = 0; iDim < nDim; iDim++) WallDist[iDim] = (Coord[iDim] - Coord_Normal[iDim]);

                      WallDistMod = 0.0; for (iDim = 0; iDim < nDim; iDim++) WallDistMod += WallDist[iDim]*WallDist[iDim]; WallDistMod = sqrt(WallDistMod);

                CSkinFriction[iMarker][iVertex] = WallShearStress / (0.5*RefDensity*RefVel2);

                FrictionVel = sqrt(fabs(WallShearStress)/Density);
                YPlus[iMarker][iVertex] = WallDistMod*FrictionVel/(Viscosity/Density);

                if (compressible) {
                    GradTemperature = 0.0;

                    for (iDim = 0; iDim < nDim; iDim++)
                        GradTemperature -= Grad_Temp[iDim]*UnitNormal[iDim];

                    Cp = (Gamma / Gamma_Minus_One) * Gas_Constant;
                    thermal_conductivity = Cp * Viscosity/Prandtl_Lam;
                    HeatFlux[iMarker][iVertex] = -thermal_conductivity*GradTemperature;
                    Heat_Visc[iMarker] += HeatFlux[iMarker][iVertex]*Area;
                    MaxHeatFlux_Visc[iMarker] += pow(HeatFlux[iMarker][iVertex], MaxNorm);

                }

                //..Incompressible, Free surface are not included..//

                if ((geometry->elem[iPoint]->GetDomain()) && (Monitoring == YES)) {

                    for (iDim = 0; iDim < nDim; iDim++) {
                        Force[iDim] = TauElem[iDim]*Area*factor;
                        ForceViscous[iDim] += Force[iDim];
                    }

                    if (nDim == 3) {
                        MomentViscous[0] += (Force[2]*MomentDist[1] - Force[1]*MomentDist[2])/RefLengthMoment;
                        MomentViscous[1] += (Force[0]*MomentDist[2] - Force[2]*MomentDist[0])/RefLengthMoment;
                    }
                    MomentViscous[2] += (Force[1]*MomentDist[0] - Force[0]*MomentDist[1])/RefLengthMoment;

                }

            }

            if  (Monitoring == YES) {
                if (nDim == 2) {
                    CDrag_Visc[iMarker]       =  ForceViscous[0]*cos(Alpha) + ForceViscous[1]*sin(Alpha);
                    CLift_Visc[iMarker]       = -ForceViscous[0]*sin(Alpha) + ForceViscous[1]*cos(Alpha);
                    CEff_Visc[iMarker]        = CLift_Visc[iMarker] / (CDrag_Visc[iMarker]+EPS);
                    CMz_Visc[iMarker]         = MomentViscous[2];
                    CFx_Visc[iMarker]         = ForceViscous[0];
                    CFy_Visc[iMarker]         = ForceViscous[1];
                    CT_Visc[iMarker]          = -CFx_Visc[iMarker];
                    CQ_Visc[iMarker]          = -CMz_Visc[iMarker];
                    CMerit_Visc[iMarker]      = CT_Visc[iMarker] / (CQ_Visc[iMarker]+EPS);
                    MaxHeatFlux_Visc[iMarker] = pow(MaxHeatFlux_Visc[iMarker], 1.0/MaxNorm);
                }
                if (nDim == 3) {
                    CDrag_Visc[iMarker]       =  -(ForceViscous[0]*cos(Alpha)*cos(Beta) + ForceViscous[1]*sin(Beta) + ForceViscous[2]*sin(Alpha)*cos(Beta));
                    CLift_Visc[iMarker]       = -(-ForceViscous[0]*sin(Alpha) + ForceViscous[2]*cos(Alpha));
                    CSideForce_Visc[iMarker]  = -ForceViscous[0]*sin(Beta)*cos(Alpha) + ForceViscous[1]*cos(Beta) - ForceViscous[2]*sin(Beta)*sin(Alpha);
                    CEff_Visc[iMarker]        = CLift_Visc[iMarker]/(CDrag_Visc[iMarker] + EPS);
                    CMx_Visc[iMarker]         = MomentViscous[0];
                    CMy_Visc[iMarker]         = MomentViscous[1];
                    CMz_Visc[iMarker]         = MomentViscous[2];
                    CFx_Visc[iMarker]         = ForceViscous[0];
                    CFy_Visc[iMarker]         = ForceViscous[1];
                    CFz_Visc[iMarker]         = ForceViscous[2];
                    CT_Visc[iMarker]          = -CFz_Visc[iMarker];
                    CQ_Visc[iMarker]          = -CMz_Visc[iMarker];
                    CMerit_Visc[iMarker]      = CT_Visc[iMarker] / (CQ_Visc[iMarker] + EPS);
                    MaxHeatFlux_Visc[iMarker] = pow(MaxHeatFlux_Visc[iMarker], 1.0/MaxNorm);
                }

                AllBound_CDrag_Visc       += CDrag_Visc[iMarker];
                AllBound_CLift_Visc       += CLift_Visc[iMarker];
                AllBound_CSideForce_Visc  += CSideForce_Visc[iMarker];
                AllBound_CMx_Visc         += CMx_Visc[iMarker];
                AllBound_CMy_Visc         += CMy_Visc[iMarker];
                AllBound_CMz_Visc         += CMz_Visc[iMarker];
                AllBound_CFx_Visc         += CFx_Visc[iMarker];
                AllBound_CFy_Visc         += CFy_Visc[iMarker];
                AllBound_CFz_Visc         += CFz_Visc[iMarker];
                AllBound_CT_Visc          += CT_Visc[iMarker];
                AllBound_CQ_Visc          += CQ_Visc[iMarker];
                AllBound_HeatFlux_Visc    += Heat_Visc[iMarker];
                AllBound_MaxHeatFlux_Visc += pow(MaxHeatFlux_Visc[iMarker], MaxNorm);

                for (iMarker_Monitoring = 0; iMarker_Monitoring < config->GetnMarker_Monitoring(); iMarker_Monitoring++) {
                    Monitoring_Tag = config->GetMarker_Monitoring(iMarker_Monitoring);
                    Marker_Tag = config->GetMarker_All_TagBound(iMarker);
                    if (Marker_Tag == Monitoring_Tag) {
                        Surface_CLift_Visc[iMarker_Monitoring]      += CLift_Visc[iMarker];
                        Surface_CDrag_Visc[iMarker_Monitoring]      += CDrag_Visc[iMarker];
                        Surface_CSideForce_Visc[iMarker_Monitoring] += CSideForce_Visc[iMarker];
                        Surface_CEff_Visc[iMarker_Monitoring]       += CEff_Visc[iMarker];
                        Surface_CFx_Visc[iMarker_Monitoring]        += CFx_Visc[iMarker];
                        Surface_CFy_Visc[iMarker_Monitoring]        += CFy_Visc[iMarker];
                        Surface_CFz_Visc[iMarker_Monitoring]        += CFz_Visc[iMarker];
                        Surface_CMx_Visc[iMarker_Monitoring]        += CMx_Visc[iMarker];
                        Surface_CMy_Visc[iMarker_Monitoring]        += CMy_Visc[iMarker];
                        Surface_CMz_Visc[iMarker_Monitoring]        += CMz_Visc[iMarker];
                    }
                }

            }

        }
    }

    AllBound_CEff_Visc = AllBound_CLift_Visc / (AllBound_CDrag_Visc + EPS);
    AllBound_CMerit_Visc = AllBound_CT_Visc / (AllBound_CQ_Visc + EPS);
    AllBound_MaxHeatFlux_Visc = pow(AllBound_MaxHeatFlux_Visc, 1.0/MaxNorm);


#ifdef HAVE_MPI

    /*--- Add AllBound information using all the nodes ---*/

    MyAllBound_CDrag_Visc        = AllBound_CDrag_Visc;                      AllBound_CDrag_Visc = 0.0;
    MyAllBound_CLift_Visc        = AllBound_CLift_Visc;                      AllBound_CLift_Visc = 0.0;
    MyAllBound_CSideForce_Visc   = AllBound_CSideForce_Visc;                 AllBound_CSideForce_Visc = 0.0;
    MyAllBound_CEff_Visc         = AllBound_CEff_Visc;                       AllBound_CEff_Visc = 0.0;
    MyAllBound_CMx_Visc          = AllBound_CMx_Visc;                        AllBound_CMx_Visc = 0.0;
    MyAllBound_CMy_Visc          = AllBound_CMy_Visc;                        AllBound_CMy_Visc = 0.0;
    MyAllBound_CMz_Visc          = AllBound_CMz_Visc;                        AllBound_CMz_Visc = 0.0;
    MyAllBound_CFx_Visc          = AllBound_CFx_Visc;                        AllBound_CFx_Visc = 0.0;
    MyAllBound_CFy_Visc          = AllBound_CFy_Visc;                        AllBound_CFy_Visc = 0.0;
    MyAllBound_CFz_Visc          = AllBound_CFz_Visc;                        AllBound_CFz_Visc = 0.0;
    MyAllBound_CT_Visc           = AllBound_CT_Visc;                         AllBound_CT_Visc = 0.0;
    MyAllBound_CQ_Visc           = AllBound_CQ_Visc;                         AllBound_CQ_Visc = 0.0;
    MyAllBound_CMerit_Visc       = AllBound_CMerit_Visc;                     AllBound_CMerit_Visc = 0.0;
    MyAllBound_HeatFlux_Visc     = AllBound_HeatFlux_Visc;                   AllBound_HeatFlux_Visc = 0.0;
    MyAllBound_MaxHeatFlux_Visc  = pow(AllBound_MaxHeatFlux_Visc, MaxNorm);  AllBound_MaxHeatFlux_Visc = 0.0;

    MPI_Allreduce(&MyAllBound_CDrag_Visc, &AllBound_CDrag_Visc, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&MyAllBound_CLift_Visc, &AllBound_CLift_Visc, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&MyAllBound_CSideForce_Visc, &AllBound_CSideForce_Visc, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    AllBound_CEff_Visc = AllBound_CLift_Visc / (AllBound_CDrag_Visc + EPS);
    MPI_Allreduce(&MyAllBound_CMx_Visc, &AllBound_CMx_Visc, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&MyAllBound_CMy_Visc, &AllBound_CMy_Visc, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&MyAllBound_CMz_Visc, &AllBound_CMz_Visc, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&MyAllBound_CFx_Visc, &AllBound_CFx_Visc, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&MyAllBound_CFy_Visc, &AllBound_CFy_Visc, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&MyAllBound_CFz_Visc, &AllBound_CFz_Visc, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&MyAllBound_CT_Visc, &AllBound_CT_Visc, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&MyAllBound_CQ_Visc, &AllBound_CQ_Visc, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    AllBound_CMerit_Visc = AllBound_CT_Visc / (AllBound_CQ_Visc + EPS);
    MPI_Allreduce(&MyAllBound_HeatFlux_Visc, &AllBound_HeatFlux_Visc, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&MyAllBound_MaxHeatFlux_Visc, &AllBound_MaxHeatFlux_Visc, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    AllBound_MaxHeatFlux_Visc = pow(AllBound_MaxHeatFlux_Visc, 1.0/MaxNorm);

    /*--- Add the forces on the surfaces using all the nodes ---*/

    MySurface_CLift_Visc      = new double[config->GetnMarker_Monitoring()];
    MySurface_CDrag_Visc      = new double[config->GetnMarker_Monitoring()];
    MySurface_CSideForce_Visc = new double[config->GetnMarker_Monitoring()];
    MySurface_CEff_Visc       = new double[config->GetnMarker_Monitoring()];
    MySurface_CFx_Visc        = new double[config->GetnMarker_Monitoring()];
    MySurface_CFy_Visc        = new double[config->GetnMarker_Monitoring()];
    MySurface_CFz_Visc        = new double[config->GetnMarker_Monitoring()];
    MySurface_CMx_Visc        = new double[config->GetnMarker_Monitoring()];
    MySurface_CMy_Visc        = new double[config->GetnMarker_Monitoring()];
    MySurface_CMz_Visc        = new double[config->GetnMarker_Monitoring()];

    for (iMarker_Monitoring = 0; iMarker_Monitoring < config->GetnMarker_Monitoring(); iMarker_Monitoring++) {

        MySurface_CLift_Visc[iMarker_Monitoring]      = Surface_CLift_Visc[iMarker_Monitoring];
        MySurface_CDrag_Visc[iMarker_Monitoring]      = Surface_CDrag_Visc[iMarker_Monitoring];
        MySurface_CSideForce_Visc[iMarker_Monitoring] = Surface_CSideForce_Visc[iMarker_Monitoring];
        MySurface_CEff_Visc[iMarker_Monitoring]       = Surface_CEff_Visc[iMarker_Monitoring];
        MySurface_CFx_Visc[iMarker_Monitoring]        = Surface_CFx_Visc[iMarker_Monitoring];
        MySurface_CFy_Visc[iMarker_Monitoring]        = Surface_CFy_Visc[iMarker_Monitoring];
        MySurface_CFz_Visc[iMarker_Monitoring]        = Surface_CFz_Visc[iMarker_Monitoring];
        MySurface_CMx_Visc[iMarker_Monitoring]        = Surface_CMx_Visc[iMarker_Monitoring];
        MySurface_CMy_Visc[iMarker_Monitoring]        = Surface_CMy_Visc[iMarker_Monitoring];
        MySurface_CMz_Visc[iMarker_Monitoring]        = Surface_CMz_Visc[iMarker_Monitoring];

        Surface_CLift_Visc[iMarker_Monitoring]      = 0.0;
        Surface_CDrag_Visc[iMarker_Monitoring]      = 0.0;
        Surface_CSideForce_Visc[iMarker_Monitoring] = 0.0;
        Surface_CEff_Visc[iMarker_Monitoring]       = 0.0;
        Surface_CFx_Visc[iMarker_Monitoring]        = 0.0;
        Surface_CFy_Visc[iMarker_Monitoring]        = 0.0;
        Surface_CFz_Visc[iMarker_Monitoring]        = 0.0;
        Surface_CMx_Visc[iMarker_Monitoring]        = 0.0;
        Surface_CMy_Visc[iMarker_Monitoring]        = 0.0;
        Surface_CMz_Visc[iMarker_Monitoring]        = 0.0;
    }

    MPI_Allreduce(MySurface_CLift_Visc, Surface_CLift_Visc, config->GetnMarker_Monitoring(), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(MySurface_CDrag_Visc, Surface_CDrag_Visc, config->GetnMarker_Monitoring(), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(MySurface_CSideForce_Visc, Surface_CSideForce_Visc, config->GetnMarker_Monitoring(), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    for (iMarker_Monitoring = 0; iMarker_Monitoring < config->GetnMarker_Monitoring(); iMarker_Monitoring++)
        Surface_CEff_Visc[iMarker_Monitoring] = Surface_CLift_Visc[iMarker_Monitoring] / (Surface_CDrag_Visc[iMarker_Monitoring] + EPS);
    MPI_Allreduce(MySurface_CFx_Visc, Surface_CFx_Visc, config->GetnMarker_Monitoring(), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(MySurface_CFy_Visc, Surface_CFy_Visc, config->GetnMarker_Monitoring(), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(MySurface_CFz_Visc, Surface_CFz_Visc, config->GetnMarker_Monitoring(), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(MySurface_CMx_Visc, Surface_CMx_Visc, config->GetnMarker_Monitoring(), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(MySurface_CMy_Visc, Surface_CMy_Visc, config->GetnMarker_Monitoring(), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(MySurface_CMz_Visc, Surface_CMz_Visc, config->GetnMarker_Monitoring(), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);

    delete [] MySurface_CLift_Visc; delete [] MySurface_CDrag_Visc; delete [] MySurface_CSideForce_Visc;
    delete [] MySurface_CEff_Visc;
    delete [] MySurface_CFx_Visc;   delete [] MySurface_CFy_Visc;
    delete [] MySurface_CFz_Visc;   delete [] MySurface_CMx_Visc;   delete [] MySurface_CMy_Visc;
    delete [] MySurface_CMz_Visc;

#endif

    Total_CDrag       += AllBound_CDrag_Visc;
    Total_CLift       += AllBound_CLift_Visc;
    Total_CSideForce  += AllBound_CSideForce_Visc;
    Total_CEff        = Total_CLift / (Total_CDrag + EPS);
    Total_CMx         += AllBound_CMx_Visc;
    Total_CMy         += AllBound_CMy_Visc;
    Total_CMz         += AllBound_CMz_Visc;
    Total_CFx         += AllBound_CFx_Visc;
    Total_CFy         += AllBound_CFy_Visc;
    Total_CFz         += AllBound_CFz_Visc;
    Total_CT          += AllBound_CT_Visc;
    Total_CQ          += AllBound_CQ_Visc;
    Total_CMerit       = AllBound_CT_Visc / (AllBound_CQ_Visc + EPS);
    Total_Heat        = AllBound_HeatFlux_Visc;
    Total_MaxHeat     = AllBound_MaxHeatFlux_Visc;

    for (iMarker_Monitoring = 0; iMarker_Monitoring < config->GetnMarker_Monitoring(); iMarker_Monitoring++) {
        Surface_CLift[iMarker_Monitoring]      += Surface_CLift_Visc[iMarker_Monitoring];
        Surface_CDrag[iMarker_Monitoring]      += Surface_CDrag_Visc[iMarker_Monitoring];
        Surface_CSideForce[iMarker_Monitoring] += Surface_CSideForce_Visc[iMarker_Monitoring];
        Surface_CEff[iMarker_Monitoring]       = Surface_CLift[iMarker_Monitoring] / (Surface_CDrag[iMarker_Monitoring] + EPS);
        Surface_CFx[iMarker_Monitoring]        += Surface_CFx_Visc[iMarker_Monitoring];
        Surface_CFy[iMarker_Monitoring]        += Surface_CFy_Visc[iMarker_Monitoring];
        Surface_CFz[iMarker_Monitoring]        += Surface_CFz_Visc[iMarker_Monitoring];
        Surface_CMx[iMarker_Monitoring]        += Surface_CMx_Visc[iMarker_Monitoring];
        Surface_CMy[iMarker_Monitoring]        += Surface_CMy_Visc[iMarker_Monitoring];
        Surface_CMz[iMarker_Monitoring]        += Surface_CMz_Visc[iMarker_Monitoring];
    }

}

void CNSSolver::BC_HeatFlux_Wall(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    unsigned short iDim, iVar;
    unsigned long iVertex, iPoint, iFace;
    double *Normal, *V_i, *V_j, UnitNormal[3], *S_i, *S_j, *CG_i, *CG_j, *CG_f, Area;
    bool implicit       = (config->GetKind_TimeIntScheme_Flow() == EULER_IMPLICIT);

    CG_j = new double [nDim];
    V_i = new double [nPrimVar];
    V_j = new double [nPrimVar];

    for(iVertex = 0; iVertex < geometry->nElem_Bound[val_marker]; iVertex++) {
        iFace = geometry->bound[val_marker][iVertex]->GetGlobalFace();
        iPoint = geometry->face[iFace]->GetElems(0);
        if (geometry->elem[iPoint]->GetDomain()) {

            Normal = geometry->face[iFace]->GetNormal_Face();

            Area = 0.0;
            for (iDim = 0; iDim < nDim; iDim++)
                Area += Normal[iDim]*Normal[iDim];
            Area = sqrt (Area);

            for (iDim = 0; iDim < nDim; iDim++)
                UnitNormal[iDim] = Normal[iDim]/Area;

            for(iVar = 0; iVar < nPrimVar; iVar++){
                V_i[iVar] = elem[iPoint]->GetPrimitive(iVar);
                V_j[iVar] = elem[iPoint]->GetPrimitive(iVar);
            }

            for(iDim = 0; iDim < nDim; iDim++) V_j[iDim+1] = -V_i[iDim+1];

            S_i = elem[iPoint]->GetSecondary(); S_j = S_i;

            conv_numerics->SetNormal(Normal);
            conv_numerics->SetPrimitive(V_i, V_j);
            conv_numerics->SetSecondary(S_i, S_j);
            conv_numerics->ComputeResidual(Residual, Jacobian_i, Jacobian_j, config);

            LinSysRes.AddBlock(iPoint, Residual);

            if (implicit)
                Jacobian.AddBlock(iPoint, iPoint, Jacobian_i);

            CG_i = geometry->elem[iPoint]->GetCG();
            CG_f = geometry->face[iFace]->GetCG();

            for(iDim = 0; iDim < nDim; iDim++) CG_j[iDim] = 2.*CG_f[iDim]-CG_i[iDim];

            visc_numerics->SetCoord(CG_i, CG_j);
            visc_numerics->SetNormal(Normal);
            visc_numerics->SetPrimitive(V_i, V_j);
            visc_numerics->SetSecondary(S_i, S_j);
            visc_numerics->SetPrimVarGradient(elem[iPoint]->GetGradient_Primitive(), elem[iPoint]->GetGradient_Primitive());

            if (config->GetKind_Turb_Model() == SST)
                visc_numerics->SetTurbKineticEnergy(solver_container[TURB_SOL]->elem[iPoint]->GetSolution(0),
                                                    solver_container[TURB_SOL]->elem[iPoint]->GetSolution(0));

            visc_numerics->ComputeResidual(Res_Visc, Jacobian_i, Jacobian_j, config);

            LinSysRes.SubtractBlock(iPoint, Res_Visc);

            if (implicit)
                Jacobian.SubtractBlock(iPoint, iPoint, Jacobian_i);

        }
    }
}

void CNSSolver::BC_Isothermal_Wall(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    //This function will be revised later.//

}

void CNSSolver::SetRoe_Dissipation(CGeometry *geometry, CConfig *config){

    unsigned long iPoint;
    double wall_distance;

    unsigned short kind_roe_dissipation = config->GetKind_RoeLowDiss();

    for (iPoint = 0; iPoint < nElem; iPoint++){
        if (kind_roe_dissipation == FD || kind_roe_dissipation == FD_DUCROS){
            if (config->GetKind_HybridRANSLES() == NO_HYBRIDRANSLES){
                wall_distance = geometry->elem[iPoint]->GetWall_Distance();
            } else {
                wall_distance = elem[iPoint]->GetDES_LengthScale();
            }

            elem[iPoint]->SetRoe_Dissipation_FD(wall_distance);
        }

        if (kind_roe_dissipation == NTS || kind_roe_dissipation == NTS_DUCROS){
            /*--- XXX: This grid length does not match the original paper.
       * Here we use the volume-based grid length,
       *    delta = (delta_x * delta_y * delta_z)^(1/3)
       * as an approximation for Travin's max-based grid length,
       *    delta = max(delta_x, delta_y, delta_z)
       * Since the volume is already computed, using the volume is much faster.
       * ---*/
            const double delta = pow(geometry->elem[iPoint]->GetVolume(), 1.0/3);
            elem[iPoint]->SetRoe_Dissipation_NTS(delta, config->GetConst_DES());
        }
    }
}
