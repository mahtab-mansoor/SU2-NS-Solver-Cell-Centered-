/*!
 * \file solution_direct_turbulent.cpp
 * \brief Main subrotuines for solving direct problems
 * \author F. Palacios, A. Bueno
 * \version 3.2.8 "eagle"
 *
 * SU2 Lead Developers: Dr. Francisco Palacios (fpalacios@stanford.edu).
 *                      Dr. Thomas D. Economon (economon@stanford.edu).
 *
 * SU2 Developers: Prof. Juan J. Alonso's group at Stanford University.
 *                 Prof. Piero Colonna's group at Delft University of Technology.
 *                 Prof. Nicolas R. Gauger's group at Kaiserslautern University of Technology.
 *                 Prof. Alberto Guardone's group at Polytechnic University of Milan.
 *                 Prof. Rafael Palacios' group at Imperial College London.
 *
 * Copyright (C) 2012-2015 SU2, the open-source CFD code.
 *
 * SU2 is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * SU2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with SU2. If not, see <http://www.gnu.org/licenses/>.
 */

#include "../include/solver_structure.hpp"

CTurbSolver::CTurbSolver(void) : CSolver() {

    FlowPrimVar_i = NULL;
    FlowPrimVar_j = NULL;
    lowerlimit    = NULL;
    upperlimit    = NULL;
}

CTurbSolver::CTurbSolver(CConfig *config) : CSolver() {

    Gamma = config->GetGamma();
    Gamma_Minus_One = Gamma - 1.0;

    FlowPrimVar_i = NULL;
    FlowPrimVar_j = NULL;
    lowerlimit    = NULL;
    upperlimit    = NULL;
}

CTurbSolver::~CTurbSolver(void) {

    if (FlowPrimVar_i != NULL) delete [] FlowPrimVar_i;
    if (FlowPrimVar_j != NULL) delete [] FlowPrimVar_j;
    if (lowerlimit != NULL) delete [] lowerlimit;
    if (upperlimit != NULL) delete [] upperlimit;

}

void CTurbSolver::Set_MPI_Solution(CGeometry *geometry, CConfig *config) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSolver::Set_MPI_Solution_Old(CGeometry *geometry, CConfig *config) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSolver::Set_MPI_Solution_Gradient(CGeometry *geometry, CConfig *config) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSolver::Set_MPI_Solution_Limiter(CGeometry *geometry, CConfig *config) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSolver::Upwind_Residual(CGeometry *geometry, CSolver **solver_container, CNumerics *numerics, CConfig *config, unsigned short iMesh) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSolver::Viscous_Residual(CGeometry *geometry, CSolver **solver_container, CNumerics *numerics,
                                   CConfig *config, unsigned short iMesh, unsigned short iRKStep) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSolver::BC_Sym_Plane(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    /*--- Convective fluxes across symmetry plane are equal to zero. ---*/

    BC_Euler_Wall(geometry, solver_container, conv_numerics, config, val_marker);


}

void CTurbSolver::BC_Euler_Wall(CGeometry *geometry, CSolver **solver_container,
                                CNumerics *numerics, CConfig *config, unsigned short val_marker) {

    /*--- Convective fluxes across euler wall are equal to zero. ---*/

}

void CTurbSolver::ImplicitEuler_Iteration(CGeometry *geometry, CSolver **solver_container, CConfig *config) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSolver::SetResidual_DualTime(CGeometry *geometry, CSolver **solver_container, CConfig *config,
                                       unsigned short iRKStep, unsigned short iMesh, unsigned short RunTime_EqSystem) {

    //this function will be revised for cc-turbulent.//

}

CTurbSASolver::CTurbSASolver(void) : CTurbSolver() {

}

CTurbSASolver::CTurbSASolver(CGeometry *geometry, CConfig *config, unsigned short iMesh, CFluidModel* FluidModel) : CTurbSolver() {

    //this function will be revised for cc-turbulent.//

}

CTurbSASolver::~CTurbSASolver(void) {

}

void CTurbSASolver::Preprocessing(CGeometry *geometry, CSolver **solver_container, CConfig *config, unsigned short iMesh, unsigned short iRKStep, unsigned short RunTime_EqSystem, bool Output) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSASolver::Postprocessing(CGeometry *geometry, CSolver **solver_container, CConfig *config, unsigned short iMesh) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSASolver::Source_Residual(CGeometry *geometry, CSolver **solver_container, CNumerics *numerics, CNumerics *second_numerics,
                                    CConfig *config, unsigned short iMesh) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSASolver::Source_Template(CGeometry *geometry, CSolver **solver_container, CNumerics *numerics,
                                    CConfig *config, unsigned short iMesh) {

}

void CTurbSASolver::BC_HeatFlux_Wall(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSASolver::BC_Isothermal_Wall(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config,
                                       unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSASolver::BC_Far_Field(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//
}

void CTurbSASolver::BC_Inlet(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSASolver::BC_Outlet(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics,
                              CConfig *config, unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//
}

void CTurbSASolver::BC_Engine_Inflow(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSASolver::BC_Engine_Exhaust(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSASolver::BC_Engine_Bleed(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSASolver::BC_Interface_Boundary(CGeometry *geometry, CSolver **solver_container, CNumerics *numerics,
                                          CConfig *config, unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//

}
void CTurbSASolver::SetDES_LengthScale(CSolver **solver, CGeometry *geometry, CConfig *config){

    //this function will be revised for cc-turbulent.//

}

void CTurbSASolver::SetUniformInlet(CConfig* config, unsigned short iMarker) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSASolver::BC_NearField_Boundary(CGeometry *geometry, CSolver **solver_container, CNumerics *numerics,
                                          CConfig *config, unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSASolver::LoadRestart(CGeometry **geometry, CSolver ***solver, CConfig *config, int val_iter, bool val_update_geo) {

    //this function will be revised for cc-turbulent.//

}

CTurbSSTSolver::CTurbSSTSolver(void) : CTurbSolver() {

    /*--- Array initialization ---*/
    constants = NULL;

}

CTurbSSTSolver::CTurbSSTSolver(CGeometry *geometry, CConfig *config, unsigned short iMesh) : CTurbSolver() {

    //this function will be revised for cc-turbulent.//

}

CTurbSSTSolver::~CTurbSSTSolver(void) {

    if (constants != NULL) delete [] constants;

}

void CTurbSSTSolver::Preprocessing(CGeometry *geometry, CSolver **solver_container, CConfig *config, unsigned short iMesh, unsigned short iRKStep, unsigned short RunTime_EqSystem, bool Output) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSSTSolver::Postprocessing(CGeometry *geometry, CSolver **solver_container, CConfig *config, unsigned short iMesh) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSSTSolver::Source_Residual(CGeometry *geometry, CSolver **solver_container, CNumerics *numerics, CNumerics *second_numerics, CConfig *config, unsigned short iMesh) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSSTSolver::Source_Template(CGeometry *geometry, CSolver **solver_container, CNumerics *numerics,
                                     CConfig *config, unsigned short iMesh) {

}

void CTurbSSTSolver::BC_HeatFlux_Wall(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSSTSolver::BC_Isothermal_Wall(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config,
                                        unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSSTSolver::BC_Far_Field(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSSTSolver::BC_Inlet(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config,
                              unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSSTSolver::BC_Outlet(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//

}

double* CTurbSSTSolver::GetConstants() {
    return constants;
}

CTurbMLSolver::CTurbMLSolver(void) : CTurbSolver() { }

CTurbMLSolver::CTurbMLSolver(CGeometry *geometry, CConfig *config, unsigned short iMesh) : CTurbSolver() {

    //this function will be revised for cc-turbulent.//

}

CTurbMLSolver::~CTurbMLSolver(void) {

}

void CTurbMLSolver::Preprocessing(CGeometry *geometry, CSolver **solver_container, CConfig *config, unsigned short iMesh, unsigned short iRKStep, unsigned short RunTime_EqSystem, bool Output) {

    //this function will be revised for cc-turbulent.//

}

void CTurbMLSolver::Postprocessing(CGeometry *geometry, CSolver **solver_container, CConfig *config, unsigned short iMesh) {

    //this function will be revised for cc-turbulent.//

}

void CTurbMLSolver::Source_Residual(CGeometry *geometry, CSolver **solver_container, CNumerics *numerics, CNumerics *second_numerics,
                                    CConfig *config, unsigned short iMesh) {

    //this function will be revised for cc-turbulent.//

}


void CTurbMLSolver::Source_Template(CGeometry *geometry, CSolver **solver_container, CNumerics *numerics,
                                    CConfig *config, unsigned short iMesh) {

}

void CTurbMLSolver::BC_HeatFlux_Wall(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//

}

void CTurbMLSolver::BC_Isothermal_Wall(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config,
                                       unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//

}

void CTurbMLSolver::BC_Far_Field(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//

}

void CTurbMLSolver::BC_Inlet(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics, CConfig *config, unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//
}

void CTurbMLSolver::BC_Outlet(CGeometry *geometry, CSolver **solver_container, CNumerics *conv_numerics, CNumerics *visc_numerics,
                              CConfig *config, unsigned short val_marker) {

    //this function will be revised for cc-turbulent.//

}

void CTurbMLSolver::LoadRestart(CGeometry **geometry, CSolver ***solver, CConfig *config, int val_iter, bool val_update_geo) {

    //this function will be revised for cc-turbulent.//

}

void CTurbSSTSolver::SetUniformInlet(CConfig* config, unsigned short iMarker) {

    //this function will be revised for cc-turbulent.//

}

