# SU2/opt/__init__.py

from project import Project
from scipy_tools import scipy_slsqp as SLSQP