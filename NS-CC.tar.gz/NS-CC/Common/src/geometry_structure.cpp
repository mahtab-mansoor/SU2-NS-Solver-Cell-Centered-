/*!
 * \file geometry_structure.cpp
 * \brief Main subroutines for creating the primal grid and multigrid structure.
 * \author F. Palacios
 * \version 3.2.8 "eagle"
 *
 * SU2 Lead Developers: Dr. Francisco Palacios (fpalacios@stanford.edu).
 *                      Dr. Thomas D. Economon (economon@stanford.edu).
 *
 * SU2 Developers: Prof. Juan J. Alonso's group at Stanford University.
 *                 Prof. Piero Colonna's group at Delft University of Technology.
 *                 Prof. Nicolas R. Gauger's group at Kaiserslautern University of Technology.
 *                 Prof. Alberto Guardone's group at Polytechnic University of Milan.
 *                 Prof. Rafael Palacios' group at Imperial College London.
 *
 * Copyright (C) 2012-2015 SU2, the open-source CFD code.
 *
 * SU2 is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * SU2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with SU2. If not, see <http://www.gnu.org/licenses/>.
 */

#include "../include/geometry_structure.hpp"

CGeometry::CGeometry(void) {

    nPoint = 0;
    nElem = 0;
    nFace = 0;

    nElem_Bound = NULL;
    Tag_to_Marker = NULL;
    elem = NULL;
    face = NULL;
    bound = NULL;
    node = NULL;
    Marker_All_SendRecv = NULL;
    Start_Face = NULL;

}

CGeometry::~CGeometry(void) {
    cout<<"Geometry Destructor..."<<endl;
    unsigned long iElem, iElem_Bound, iPoint, iFace, iVertex, iEdge;
    unsigned short iMarker;

    if (elem != NULL) {
        for (iElem = 0; iElem < nElem; iElem++)
            if (elem[iElem] != NULL) delete elem[iElem];
        delete[] elem; elem = NULL;
    }

    if (bound != NULL) {
        for (iMarker = 0; iMarker < nMarker; iMarker++) {
            for (iElem_Bound = 0; iElem_Bound < nElem_Bound[iMarker]; iElem_Bound++) {
                if (bound[iMarker][iElem_Bound] != NULL) delete bound[iMarker][iElem_Bound];
            }
        }
        delete[] bound; bound = NULL;
    }

    if (face != NULL) {
        for (iFace = 0; iFace < nFace; iFace ++)
            if (face[iFace] != NULL) delete face[iFace];
        delete[] face; face = NULL;
    }

    if (node != NULL) {
        for (iPoint = 0; iPoint < nPoint; iPoint ++)
            if (node[iPoint] != NULL) delete node[iPoint];
        delete[] node; node = NULL;
    }


    if (nElem_Bound != NULL) delete[] nElem_Bound; nElem_Bound = NULL;
    if (Marker_All_SendRecv != NULL) delete[] Marker_All_SendRecv; Marker_All_SendRecv = NULL;
    if (Tag_to_Marker != NULL) delete[] Tag_to_Marker; Tag_to_Marker = NULL;
    if (Start_Face != NULL) delete[] Start_Face; Start_Face = NULL;

}

double CGeometry::Point2Plane_Distance(double *Coord, double *iCoord, double *jCoord, double *kCoord) {
    double CrossProduct[3], iVector[3], jVector[3], distance, modulus;
    unsigned short iDim;

    for (iDim = 0; iDim < 3; iDim ++) {
        iVector[iDim] = jCoord[iDim] - iCoord[iDim];
        jVector[iDim] = kCoord[iDim] - iCoord[iDim];
    }

    CrossProduct[0] = iVector[1]*jVector[2] - iVector[2]*jVector[1];
    CrossProduct[1] = iVector[2]*jVector[0] - iVector[0]*jVector[2];
    CrossProduct[2] = iVector[0]*jVector[1] - iVector[1]*jVector[0];

    modulus = sqrt(CrossProduct[0]*CrossProduct[0]+CrossProduct[1]*CrossProduct[1]+CrossProduct[2]*CrossProduct[2]);

    distance = 0.0;
    for (iDim = 0; iDim < 3; iDim ++)
        distance += CrossProduct[iDim]*(Coord[iDim]-iCoord[iDim]);
    distance /= modulus;

    return distance;

}

long CGeometry::FindEdge(unsigned long first_point, unsigned long second_point) {

}

bool CGeometry::CheckEdge(unsigned long first_point, unsigned long second_point) {

}

void CGeometry::SetEdges(void) {

}

void CGeometry::SetFaces(void) {

}

void CGeometry::TestGeometry(void) {

}

void CGeometry::SetSpline(vector<double> &x, vector<double> &y, unsigned long n, double yp1, double ypn, vector<double> &y2) {
    unsigned long i, k;
    double p, qn, sig, un, *u;

    u = new double [n];

    if (yp1 > 0.99e30)			// The lower boundary condition is set either to be "nat
        y2[0]=u[0]=0.0;			  // -ural"
    else {									// or else to have a specified first derivative.
        y2[0] = -0.5;
        u[0]=(3.0/(x[1]-x[0]))*((y[1]-y[0])/(x[1]-x[0])-yp1);
    }

    for (i=2; i<=n-1; i++) {									//  This is the decomposition loop of the tridiagonal al-
        sig=(x[i-1]-x[i-2])/(x[i]-x[i-2]);		//	gorithm. y2 and u are used for tem-
        p=sig*y2[i-2]+2.0;										//	porary storage of the decomposed
        y2[i-1]=(sig-1.0)/p;										//	factors.

        double a1 = (y[i]-y[i-1])/(x[i]-x[i-1]); if (x[i] == x[i-1]) a1 = 1.0;
        double a2 = (y[i-1]-y[i-2])/(x[i-1]-x[i-2]); if (x[i-1] == x[i-2]) a2 = 1.0;
        u[i-1]= a1 - a2;
        u[i-1]=(6.0*u[i-1]/(x[i]-x[i-2])-sig*u[i-2])/p;

    }

    if (ypn > 0.99e30)						// The upper boundary condition is set either to be
        qn=un=0.0;									// "natural"
    else {												// or else to have a specified first derivative.
        qn=0.5;
        un=(3.0/(x[n-1]-x[n-2]))*(ypn-(y[n-1]-y[n-2])/(x[n-1]-x[n-2]));
    }
    y2[n-1]=(un-qn*u[n-2])/(qn*y2[n-2]+1.0);
    for (k=n-1; k>=1; k--)					// This is the backsubstitution loop of the tridiagonal
        y2[k-1]=y2[k-1]*y2[k]+u[k-1];	  // algorithm.

    delete[] u;

}

double CGeometry::GetSpline(vector<double>&xa, vector<double>&ya, vector<double>&y2a, unsigned long n, double x) {
    unsigned long klo, khi, k;
    double h, b, a, y;

    if (x < xa[0]) x = xa[0];       // Clip max and min values
    if (x > xa[n-1]) x = xa[n-1];

    klo = 1;										// We will find the right place in the table by means of
    khi = n;										// bisection. This is optimal if sequential calls to this
    while (khi-klo > 1) {			// routine are at random values of x. If sequential calls
        k = (khi+klo) >> 1;				// are in order, and closely spaced, one would do better
        if (xa[k-1] > x) khi = k;		// to store previous values of klo and khi and test if
        else klo=k;							// they remain appropriate on the next call.
    }								// klo and khi now bracket the input value of x
    h = xa[khi-1] - xa[klo-1];
    if (h == 0.0) h = EPS; // cout << "Bad xa input to routine splint" << endl;	// The xa’s must be distinct.
    a = (xa[khi-1]-x)/h;
    b = (x-xa[klo-1])/h;				// Cubic spline polynomial is now evaluated.
    y = a*ya[klo-1]+b*ya[khi-1]+((a*a*a-a)*y2a[klo-1]+(b*b*b-b)*y2a[khi-1])*(h*h)/6.0;

    return y;
}

unsigned short CGeometry::ComputeSegmentPlane_Intersection(double *Segment_P0, double *Segment_P1, double Variable_P0, double Variable_P1,
                                                           double *Plane_P0, double *Plane_Normal, double *Intersection, double &Variable_Interp) {
    double u[3], v[3], Denominator, Numerator, Aux, ModU;
    unsigned short iDim;

    for (iDim = 0; iDim < 3; iDim++) {
        u[iDim] = Segment_P1[iDim] - Segment_P0[iDim];
        v[iDim] = Plane_P0[iDim] - Segment_P0[iDim];
    }

    ModU = sqrt(u[0]*u[0]+u[1]*u[1]+u[2]*u[2]);

    Numerator = Plane_Normal[0]*v[0] + Plane_Normal[1]*v[1] + Plane_Normal[2]*v[2];
    Denominator = Plane_Normal[0]*u[0] + Plane_Normal[1]*u[1] + Plane_Normal[2]*u[2];

    if (fabs(Denominator) <= 0.0) return 0; // No intersection.

    Aux = Numerator / Denominator;

    if (Aux < 0.0 || Aux > 1.0) return 0; // No intersection.

    for (iDim = 0; iDim < 3; iDim++)
        Intersection[iDim] = Segment_P0[iDim] + Aux * u[iDim];


    /*--- Check that the intersection is in the segment ---*/
    for (iDim = 0; iDim < 3; iDim++) {
        u[iDim] = Segment_P0[iDim] - Intersection[iDim];
        v[iDim] = Segment_P1[iDim] - Intersection[iDim];
    }

    Variable_Interp = Variable_P0 + (Variable_P1 - Variable_P0)*sqrt(u[0]*u[0]+u[1]*u[1]+u[2]*u[2])/ModU;

    Denominator = Plane_Normal[0]*u[0] + Plane_Normal[1]*u[1] + Plane_Normal[2]*u[2];
    Numerator = Plane_Normal[0]*v[0] + Plane_Normal[1]*v[1] + Plane_Normal[2]*v[2];

    Aux = Numerator * Denominator;

    if (Aux > 0.0) return 3; // Intersection outside the segment.
    else return 1;

}

void CGeometry::ComputeAirfoil_Section(double *Plane_P0, double *Plane_Normal,
                                       double MinXCoord, double MaxXCoord, double *FlowVariable,
                                       vector<double> &Xcoord_Airfoil, vector<double> &Ycoord_Airfoil,
                                       vector<double> &Zcoord_Airfoil, vector<double> &Variable_Airfoil,
                                       bool original_surface, CConfig *config) {


}

void CGeometry::ComputeSurf_Curvature(CConfig *config) {

}

CPhysicalGeometry::CPhysicalGeometry() : CGeometry() {

    Global_to_Local_Point = NULL;
    Local_to_Global_Point = NULL;
    Local_to_Global_Marker = NULL;
    Global_to_Local_Face = NULL;
    Local_to_Global_Face = NULL;
    Global_to_Local_Elem = NULL;
    Local_to_Global_Elem = NULL;
}

CPhysicalGeometry::CPhysicalGeometry(CConfig *config, unsigned short val_iZone, unsigned short val_nZone) : CGeometry() {

    Global_to_Local_Point = NULL;
    Local_to_Global_Point = NULL;
    Local_to_Global_Marker = NULL;
    Global_to_Local_Face = NULL;
    Local_to_Global_Face = NULL;
    Global_to_Local_Elem = NULL;
    Local_to_Global_Elem = NULL;

    unsigned short iMarker;
    unsigned long iElem_Surface;
    double Mesh_Scale_Change = 1.0, *NewCoord;
    int rank = MASTER_NODE;
    nZone = val_nZone;

    string val_mesh_filename = config->GetMesh_FileName();

    string val_mesh_filename1 = config->GetMesh_FileName1();
    string val_mesh_filename2 = config->GetMesh_FileName2();
    string val_mesh_filename3 = config->GetMesh_FileName3();
    string val_mesh_filename4 = config->GetMesh_FileName4();
    string val_mesh_filename5 = config->GetMesh_FileName5();

    unsigned short val_format = config->GetMesh_FileFormat();

    NewCoord = new double [nDim];

#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

    if (rank == MASTER_NODE)
        cout << endl <<"---------------------- Read Grid File Information -----------------------" << endl;

    switch (val_format) {
    case SU2:
        Read_SU2_Format(config, val_mesh_filename, val_iZone, val_nZone);
        break;
    case OPENFOAM:
        Read_OpenFOAM_Format(config, val_mesh_filename1, val_mesh_filename2, val_mesh_filename3, val_mesh_filename4,
                             val_mesh_filename5, val_iZone, val_nZone);
        break;
    case CGNS:
        Read_CGNS_Format(config, val_mesh_filename, val_iZone, val_nZone);
        break;
    case NETCDF_ASCII:
        Read_NETCDF_Format(config, val_mesh_filename, val_iZone, val_nZone);
        break;
    default:
        cout << "Unrecognized mesh format specified!!" << endl;
#ifndef HAVE_MPI
        exit(EXIT_FAILURE);
#else
        MPI_Abort(MPI_COMM_WORLD,1);
        MPI_Finalize();
#endif
        break;
    }

    unsigned long iFace, iElem;
    for (iMarker = 0; iMarker < nMarker; iMarker++){
        for (iElem_Surface = 0; iElem_Surface < nElem_Bound[iMarker]; iElem_Surface++){
            iFace = bound[iMarker][iElem_Surface]->GetGlobalFace();
            iElem = face[iFace]->GetElems(0);
            elem[iElem]->SetBoundary(nMarker);
            if (config->GetMarker_All_KindBC(iMarker) != SEND_RECEIVE &&
                    config->GetMarker_All_KindBC(iMarker) != INTERFACE_BOUNDARY &&
                    config->GetMarker_All_KindBC(iMarker) != NEARFIELD_BOUNDARY &&
                    config->GetMarker_All_KindBC(iMarker) != PERIODIC_BOUNDARY)
                elem[iElem]->SetPhysicalBoundary(true);

            if (config->GetMarker_All_KindBC(iMarker) == EULER_WALL ||
                    config->GetMarker_All_KindBC(iMarker) == HEAT_FLUX ||
                    config->GetMarker_All_KindBC(iMarker) == ISOTHERMAL)
                elem[iElem]->SetSolidBoundary(true);
        }
    }

    if (config->GetKind_SU2() == SU2_CFD) {

        Mesh_Scale_Change = config->GetMesh_Scale_Change();

    }

}
/*---By Mahtab---*/
CPhysicalGeometry::CPhysicalGeometry(CGeometry *geometry, CConfig *config) {
    Local_to_Global_Point = NULL;
    Local_to_Global_Marker = NULL;
    Local_to_Global_Face = NULL;
    Local_to_Global_Elem = NULL;

    unsigned long iter,  iPoint, iFace, jFace, kFace, iElem, jElem, iVertex, iVertexDomain, iElem_Bound;
    unsigned long nFaceTotal = 0, nElemTotal = 0, nElemDomainTotal = 0, nElemGhost = 0, nPointTotal = 0, nFaceThreeNode = 0, nFaceFourNode = 0,
            nFaceFiveNode = 0, nFaceSixNode = 0, nFaceSevenNode = 0, nFaceEightNode = 0, nElemiiNeigh = 0,
            nElemiiiNeigh = 0, nElemivNeigh = 0, nElemvNeigh = 0, nElemviNeigh = 0,
            nElemviiNeigh = 0, nElemviiiNeigh = 0, nVertexDomainTotal = 0;

    unsigned long iOwner, iNeighbor, iFaceTotal, iElemTotal, iElemDomain, iElemGhost, iPointTotal, iFaceThreeNode, iFaceFourNode, iFaceFiveNode,
            iFaceSixNode, iFaceSevenNode, iFaceEightNode,
            iElemiiNeigh, iElemiiiNeigh, iElemivNeigh, iElemvNeigh, iElemviNeigh, iElemviiNeigh, iElemviiiNeigh, iVertexDomainTotal;

    unsigned long *nFace_Color = NULL, **Face_Color = NULL, Max_nFace_Color = 0;
    unsigned long Buffer_Send_nFaceTotal = 0, Buffer_Send_nFaceThreeNode = 0, Buffer_Send_nFaceFourNode = 0, Buffer_Send_nFaceFiveNode = 0, Buffer_Send_nFaceSixNode = 0,
            Buffer_Send_nFaceSevenNode = 0, Buffer_Send_nFaceEightNode = 0, Buffer_Send_nElemTotal = 0,
            Buffer_Send_nElemDomainTotal = 0, Buffer_Send_nElemGhost = 0, Buffer_Send_nElemiiNeigh = 0, Buffer_Send_nElemiiiNeigh = 0, Buffer_Send_nElemivNeigh = 0,
            Buffer_Send_nElemvNeigh = 0, Buffer_Send_nElemviNeigh = 0, Buffer_Send_nElemviiNeigh = 0, Buffer_Send_nElemviiiNeigh = 0,
            Buffer_Send_nPointTotal = 0, Buffer_Send_nVertexDomainTotal;

    unsigned short i, j, iNode, iDim, iMarker, nMarkerDomain = 0, iMarkerDomain;
    unsigned short nDomain = 0, iDomain, jDomain, kDomain, overhead = 4, Buffer_Send_nMarkerDomain = 0, Buffer_Send_nDim = 0,
            Buffer_Send_nZone = 0;
    bool *MarkerIn = NULL, *DomainIn = NULL, CheckDomain;
    long vnodes_local[8];
    long *Global_to_Local_Elem = NULL, *Global_to_Local_Face = NULL, *Global_to_Local_Point = NULL, *Global_to_Local_Neigh = NULL;
    vector<long> DomainList;
    short *Marker_All_SendRecv_Copy = NULL;
    string *Marker_All_TagBound_Copy = NULL;
    unsigned short nMarker_Max = config->GetnMarker_Max();

    int rank = MASTER_NODE;
    int size = SINGLE_NODE;

    unsigned long *nVertexDomain = new unsigned long[nMarker_Max];
    unsigned long *Buffer_Send_nVertexDomain = new unsigned long[nMarker_Max];
    short *Buffer_Send_Marker_All_SendRecv = new short[nMarker_Max];
    char *Marker_All_TagBound = new char[nMarker_Max*MAX_STRING_SIZE];
    char *Buffer_Send_Marker_All_TagBound = new char[nMarker_Max*MAX_STRING_SIZE];

#ifdef HAVE_MPI

    MPI_Status status;
    MPI_Comm_size(MPI_COMM_WORLD,&size);
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);

    MPI_Status send_stat[43], recv_stat[43];
    MPI_Request send_req[43], recv_req[43];

#endif

    //Part1# MPI is Initialized. MPI status and request arrays for non-blocking communications is set.//

    double        *Buffer_Send_CGF = NULL,               *Buffer_Receive_CGF = NULL;
    unsigned long *Buffer_Send_GlobalFaceIndex = NULL,   *Buffer_Receive_GlobalFaceIndex = NULL;
    unsigned long *Buffer_Send_nNeighborNode = NULL,     *Buffer_Receive_nNeighborNode = NULL;
    unsigned long *Buffer_Send_FaceThreeNode = NULL,     *Buffer_Receive_FaceThreeNode = NULL;
    unsigned long *Buffer_Send_FaceFourNode = NULL,      *Buffer_Receive_FaceFourNode = NULL;
    unsigned long *Buffer_Send_FaceFiveNode = NULL,      *Buffer_Receive_FaceFiveNode = NULL;
    unsigned long *Buffer_Send_FaceSixNode = NULL,       *Buffer_Receive_FaceSixNode = NULL;
    unsigned long *Buffer_Send_FaceSevenNode = NULL,     *Buffer_Receive_FaceSevenNode = NULL;
    unsigned long *Buffer_Send_FaceEightNode = NULL,     *Buffer_Receive_FaceEightNode = NULL;
    unsigned long *Buffer_Send_Faceiii = NULL,           *Buffer_Receive_Faceiii = NULL;
    unsigned long *Buffer_Send_Faceiv = NULL,            *Buffer_Receive_Faceiv = NULL;
    unsigned long *Buffer_Send_Facev = NULL,             *Buffer_Receive_Facev = NULL;
    unsigned long *Buffer_Send_Facevi = NULL,            *Buffer_Receive_Facevi = NULL;
    unsigned long *Buffer_Send_Facevii = NULL,           *Buffer_Receive_Facevii = NULL;
    unsigned long *Buffer_Send_Faceviii = NULL,          *Buffer_Receive_Faceviii = NULL;
    double        *Buffer_Send_CGE = NULL,               *Buffer_Receive_CGE = NULL;
    unsigned long *Buffer_Send_Color = NULL,             *Buffer_Receive_Color = NULL;
    unsigned long *Buffer_Send_GlobalElemIndex = NULL,   *Buffer_Receive_GlobalElemIndex = NULL;
    unsigned long *Buffer_Send_nNeighborFace = NULL,     *Buffer_Receive_nNeighborFace = NULL;
    unsigned long *Buffer_Send_nNeighborCell = NULL,     *Buffer_Receive_nNeighborCell = NULL;
    long *Buffer_Send_ElemiiNeigh = NULL,                *Buffer_Receive_ElemiiNeigh = NULL;
    unsigned long *Buffer_Send_Elemii = NULL,            *Buffer_Receive_Elemii = NULL;
    long *Buffer_Send_ElemiiiNeigh = NULL,               *Buffer_Receive_ElemiiiNeigh = NULL;
    unsigned long *Buffer_Send_Elemiii = NULL,           *Buffer_Receive_Elemiii = NULL;
    long *Buffer_Send_ElemivNeigh = NULL,                *Buffer_Receive_ElemivNeigh = NULL;
    unsigned long *Buffer_Send_Elemiv = NULL,            *Buffer_Receive_Elemiv = NULL;
    long *Buffer_Send_ElemvNeigh = NULL,                 *Buffer_Receive_ElemvNeigh = NULL;
    unsigned long *Buffer_Send_Elemv = NULL,             *Buffer_Receive_Elemv = NULL;
    long *Buffer_Send_ElemviNeigh = NULL,                *Buffer_Receive_ElemviNeigh = NULL;
    unsigned long *Buffer_Send_Elemvi = NULL,            *Buffer_Receive_Elemvi = NULL;
    long *Buffer_Send_ElemviiNeigh = NULL,               *Buffer_Receive_ElemviiNeigh = NULL;
    unsigned long *Buffer_Send_Elemvii = NULL,           *Buffer_Receive_Elemvii = NULL;
    long *Buffer_Send_ElemviiiNeigh = NULL,              *Buffer_Receive_ElemviiiNeigh = NULL;
    unsigned long *Buffer_Send_Elemviii = NULL,          *Buffer_Receive_Elemviii = NULL;
    long *Buffer_Send_OwnerCell = NULL,        *Buffer_Receive_OwnerCell = NULL;
    long *Buffer_Send_NeighborCell = NULL,     *Buffer_Receive_NeighborCell = NULL;
    double        *Buffer_Send_Coord = NULL,            *Buffer_Receive_Coord = NULL;
    unsigned long *Buffer_Send_GlobalPointIndex = NULL, *Buffer_Receive_GlobalPointIndex = NULL;
    double *Buffer_Send_Volume = NULL,     *Buffer_Receive_Volume = NULL;
    double *Buffer_Send_Normal = NULL,     *Buffer_Receive_Normal = NULL;
    long *Buffer_Send_StartFace = NULL,            *Buffer_Receive_StartFace = NULL;
    unsigned long *Buffer_Send_Local2Global_Marker = NULL,  *Buffer_Receive_Local2Global_Marker = NULL;
    unsigned long *Buffer_Send_Bound = NULL,  *Buffer_Receive_Bound = NULL;

    nDomain = size;
    Marker_All_SendRecv = new short[nMarker_Max];

    if (rank == MASTER_NODE) {

        MarkerIn = new bool [geometry->GetnMarker()];

        DomainIn = new bool [size];

        Global_to_Local_Face =  new long[geometry->GetnFace()];
        Global_to_Local_Elem =  new long[geometry->GetnElem()];
        Global_to_Local_Point =  new long[geometry->GetnPoint()];
        Global_to_Local_Neigh =  new long[geometry->GetnElem()];

        Buffer_Send_nDim = 3;
        Buffer_Send_nZone = 1;

        nFace_Color = new unsigned long[nDomain];
        for(iDomain = 0; iDomain < nDomain; iDomain++) nFace_Color[iDomain] = 0;

        for(iDomain = 0; iDomain < nDomain; iDomain++) DomainIn[iDomain] = false;

        for (iFace = 0; iFace < geometry->GetnFace(); iFace++) {

            DomainList.clear();

            for(i=0; i < 2; i++){
                if(geometry->face[iFace]->GetElems(i) != -1){
                    iElem = geometry->face[iFace]->GetElems(i);
                    iDomain = geometry->elem[iElem]->GetColor();

                    CheckDomain = true;
                    for (jDomain = 0; jDomain < DomainList.size(); jDomain++) {
                        if (DomainList[jDomain] == iDomain) { CheckDomain = false; break; }
                    }

                    if (CheckDomain) {
                        DomainList.push_back(iDomain);
                        nFace_Color[iDomain]++;
                    }

                    for(kFace = 0; kFace < geometry->elem[iElem]->GetnNeighbor_Face(); kFace++){
                        jFace = geometry->elem[iElem]->GetNeighbor_Face(kFace);
                        if(jFace != iFace){
                            for(j = 0; j < 2; j++){
                                if(geometry->face[jFace]->GetElems(j) != -1) jElem = geometry->face[jFace]->GetElems(j);
                                if(jElem != iElem){
                                    kDomain = geometry->elem[jElem]->GetColor();
                                    if(kDomain != iDomain) DomainIn[kDomain] = true;
                                    if(DomainIn[kDomain] = true){
                                        CheckDomain = true;

                                        for (jDomain = 0; jDomain < DomainList.size(); jDomain++) {
                                            if (DomainList[jDomain] == kDomain) { CheckDomain = false; break; }
                                        }

                                        if (CheckDomain) {
                                            DomainList.push_back(kDomain);
                                            nFace_Color[kDomain]++;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        Max_nFace_Color = 0;
        for (iDomain = 0; iDomain < nDomain; iDomain++) {
            if (nFace_Color[iDomain] > Max_nFace_Color) Max_nFace_Color = nFace_Color[iDomain];
        }

        //PART2# nFac_Color[iDomain] and Max_nFace_Color are calculated in the master node.//

        for(iDomain = 0; iDomain < nDomain; iDomain++) nFace_Color[iDomain] = 0;

        for(iDomain = 0; iDomain < nDomain; iDomain++) DomainIn[iDomain] = false;

        Face_Color = new unsigned long* [nDomain];
        for (iDomain = 0; iDomain < nDomain; iDomain++) {
            Face_Color[iDomain] =  new unsigned long[Max_nFace_Color];
            nFace_Color[iDomain] = 0;
        }

        for (iFace = 0; iFace < geometry->GetnFace(); iFace++) {

            DomainList.clear();

            for(i=0; i < 2; i++){
                if(geometry->face[iFace]->GetElems(i) != -1){

                    iElem = geometry->face[iFace]->GetElems(i);
                    iDomain = geometry->elem[iElem]->GetColor();

                    CheckDomain = true;
                    for (jDomain = 0; jDomain < DomainList.size(); jDomain++) {
                        if (DomainList[jDomain] == iDomain) { CheckDomain = false; break; }
                    }

                    if (CheckDomain) {
                        DomainList.push_back(iDomain);
                        Face_Color[iDomain][nFace_Color[iDomain]] = iFace;

                        nFace_Color[iDomain]++;
                    }

                    for(kFace = 0; kFace < geometry->elem[iElem]->GetnNeighbor_Face(); kFace++){
                        jFace = geometry->elem[iElem]->GetNeighbor_Face(kFace);
                        if(jFace != iFace){
                            for(j = 0; j < 2; j++){
                                if(geometry->face[jFace]->GetElems(j) != -1) jElem = geometry->face[jFace]->GetElems(j);
                                if(jElem != iElem){
                                    kDomain = geometry->elem[jElem]->GetColor();
                                    if(kDomain != iDomain) DomainIn[kDomain] = true;
                                    if(DomainIn[kDomain] = true){
                                        CheckDomain = true;

                                        for (jDomain = 0; jDomain < DomainList.size(); jDomain++) {
                                            if (DomainList[jDomain] == kDomain) { CheckDomain = false; break; }
                                        }

                                        if (CheckDomain) {
                                            DomainList.push_back(kDomain);
                                            Face_Color[kDomain][nFace_Color[kDomain]] = iFace;
                                            nFace_Color[kDomain]++;
                                        }

                                    }
                                }
                            }
                        }
                    }
                }
            }
        }


        Marker_All_SendRecv_Copy = new short [geometry->GetnMarker()];
        Marker_All_TagBound_Copy   = new string[geometry->GetnMarker()];

        for (iMarker = 0; iMarker < geometry->GetnMarker(); iMarker++) {
            Marker_All_SendRecv_Copy[iMarker] = config->GetMarker_All_SendRecv(iMarker);
            Marker_All_TagBound_Copy[iMarker] = config->GetMarker_All_TagBound(iMarker);
        }
        //PART3# Face_Color[iDomain][nFace_Color[iDomain]] and Marker_All_SendRecv_Copy[iMarker] are calculated in the master node.//
    }

    for (iDomain = 0; iDomain < nDomain; iDomain++) {

        if (rank == MASTER_NODE) {

            Buffer_Send_nFaceTotal = 0;
            Buffer_Send_nFaceThreeNode = 0; Buffer_Send_nFaceFourNode = 0;
            Buffer_Send_nFaceFiveNode = 0; Buffer_Send_nFaceSixNode = 0;
            Buffer_Send_nFaceSevenNode = 0; Buffer_Send_nFaceEightNode = 0;
            Buffer_Send_nElemTotal = 0; Buffer_Send_nElemDomainTotal = 0;
            Buffer_Send_nElemGhost = 0; Buffer_Send_nElemiiNeigh = 0;
            Buffer_Send_nElemiiiNeigh = 0; Buffer_Send_nElemivNeigh = 0;
            Buffer_Send_nElemvNeigh = 0; Buffer_Send_nElemviNeigh = 0;
            Buffer_Send_nElemviiNeigh = 0; Buffer_Send_nElemviiiNeigh = 0;
            Buffer_Send_nPointTotal = 0; Buffer_Send_nVertexDomainTotal = 0;

            for (iFace = 0; iFace < geometry->GetnFace(); iFace++) Global_to_Local_Face[iFace] = -1;
            for (iElem = 0; iElem < geometry->GetnElem(); iElem++) Global_to_Local_Elem[iElem] = -1;
            for (iPoint = 0; iPoint < geometry->GetnPoint(); iPoint++) Global_to_Local_Point[iPoint] = -1;


            for (jFace = 0; jFace < nFace_Color[iDomain]; jFace++) {
                iFace = Face_Color[iDomain][jFace];

                if(Global_to_Local_Face[iFace] == -1){
                    Global_to_Local_Face[iFace] = 1;

                    if(geometry->face[iFace]->GetnNodes_Face() == 3) Buffer_Send_nFaceThreeNode++;
                    if(geometry->face[iFace]->GetnNodes_Face() == 4) Buffer_Send_nFaceFourNode++;
                    if(geometry->face[iFace]->GetnNodes_Face() == 5) Buffer_Send_nFaceFiveNode++;
                    if(geometry->face[iFace]->GetnNodes_Face() == 6) Buffer_Send_nFaceSixNode++;
                    if(geometry->face[iFace]->GetnNodes_Face() == 7) Buffer_Send_nFaceSevenNode++;
                    if(geometry->face[iFace]->GetnNodes_Face() == 8) Buffer_Send_nFaceEightNode++;

                    for(iNode = 0; iNode < geometry->face[iFace]->GetnNodes_Face(); iNode++){
                        iPoint = geometry->face[iFace]->GetNode_Face(iNode);
                        if(Global_to_Local_Point[iPoint] == -1){
                            Global_to_Local_Point[iPoint] = 1;
                            Buffer_Send_nPointTotal++;
                        }
                    }
                    Buffer_Send_nFaceTotal++;
                }
            }

            for (jFace = 0; jFace < nFace_Color[iDomain]; jFace++) {
                iFace = Face_Color[iDomain][jFace];
                for(i = 0; i < 2; i++){
                    if(geometry->face[iFace]->GetElems(i) != -1){
                        iElem = geometry->face[iFace]->GetElems(i);
                        if(Global_to_Local_Elem[iElem] == -1){
                            Global_to_Local_Elem[iElem] = 1;
                            if(geometry->elem[iElem]->GetnNeighbor_Cell() == 2)  Buffer_Send_nElemiiNeigh++;
                            if(geometry->elem[iElem]->GetnNeighbor_Cell() == 3)  Buffer_Send_nElemiiiNeigh++;
                            if(geometry->elem[iElem]->GetnNeighbor_Cell() == 4)  Buffer_Send_nElemivNeigh++;
                            if(geometry->elem[iElem]->GetnNeighbor_Cell() == 5)  Buffer_Send_nElemvNeigh++;
                            if(geometry->elem[iElem]->GetnNeighbor_Cell() == 6)  Buffer_Send_nElemviNeigh++;
                            if(geometry->elem[iElem]->GetnNeighbor_Cell() == 7)  Buffer_Send_nElemviiNeigh++;
                            if(geometry->elem[iElem]->GetnNeighbor_Cell() == 8)  Buffer_Send_nElemviiiNeigh++;

                            if(geometry->elem[iElem]->GetColor() == iDomain)Buffer_Send_nElemDomainTotal++;
                            else Buffer_Send_nElemGhost++;

                            Buffer_Send_nElemTotal++;

                        }
                    }
                }
            }

            Buffer_Send_nMarkerDomain = 0;
            for (iMarker = 0; iMarker < geometry->GetnMarker(); iMarker++) {
                Buffer_Send_nVertexDomain[iMarker] = 0;
                Buffer_Send_Marker_All_SendRecv[iMarker] = Marker_All_SendRecv_Copy[iMarker];
                sprintf(&Buffer_Send_Marker_All_TagBound[iMarker*MAX_STRING_SIZE], "%s", Marker_All_TagBound_Copy[iMarker].c_str());
            }

            for (iMarker = 0; iMarker < geometry->GetnMarker(); iMarker++) {
                if (config->GetMarker_All_KindBC(iMarker) != SEND_RECEIVE) {
                    MarkerIn[iMarker] = false; Buffer_Send_nVertexDomain[Buffer_Send_nMarkerDomain] = 0;

                    for (iVertex = 0; iVertex < geometry->GetnElem_Bound(iMarker); iVertex++) {
                        iFace = geometry->bound[iMarker][iVertex]->GetGlobalFace();
                        iElem = geometry->face[iFace]->GetElems(0);
                        if(Global_to_Local_Face[iFace] != -1){
                            Buffer_Send_nVertexDomain[Buffer_Send_nMarkerDomain] ++;
                            Buffer_Send_nVertexDomainTotal++;
                            MarkerIn[iMarker] = true;
                        }
                    }
                    if (MarkerIn[iMarker]) {Buffer_Send_nMarkerDomain++; }
                }
            }

            //PART4# for each domain, in the master node, Buffer_Send_nFaceTotal, nElemTotal, nElemGhost, nElemDomainTotal, nPointTotal,
            //, nFaceThree..Node, nElemFour...Face, nVertexDomain, nMarkerDomain are created.//

            Buffer_Send_CGF              =    new double [Buffer_Send_nFaceTotal*Buffer_Send_nDim];
            Buffer_Send_GlobalFaceIndex  =    new unsigned long [Buffer_Send_nFaceTotal];
            Buffer_Send_nNeighborNode    =    new unsigned long [Buffer_Send_nFaceTotal];
            Buffer_Send_FaceThreeNode     =    new unsigned long [Buffer_Send_nFaceThreeNode*3];
            Buffer_Send_Faceiii          =    new unsigned long [Buffer_Send_nFaceThreeNode];
            Buffer_Send_FaceFourNode     =    new unsigned long [Buffer_Send_nFaceFourNode*4];
            Buffer_Send_Faceiv           =    new unsigned long [Buffer_Send_nFaceFourNode];
            Buffer_Send_FaceFiveNode     =    new unsigned long [Buffer_Send_nFaceFiveNode*5];
            Buffer_Send_Facev            =    new unsigned long [Buffer_Send_nFaceFiveNode];
            Buffer_Send_FaceSixNode      =    new unsigned long [Buffer_Send_nFaceSixNode*6];
            Buffer_Send_Facevi           =    new unsigned long [Buffer_Send_nFaceSixNode];
            Buffer_Send_FaceSevenNode    =    new unsigned long [Buffer_Send_nFaceSevenNode*7];
            Buffer_Send_Facevii          =    new unsigned long [Buffer_Send_nFaceSevenNode];
            Buffer_Send_FaceEightNode    =    new unsigned long [Buffer_Send_nFaceEightNode*8];
            Buffer_Send_Faceviii         =    new unsigned long [Buffer_Send_nFaceEightNode];

            Buffer_Send_CGE              =    new double [Buffer_Send_nElemTotal*Buffer_Send_nDim];
            Buffer_Send_GlobalElemIndex  =    new unsigned long [Buffer_Send_nElemTotal];
            Buffer_Send_Color            =    new unsigned long [Buffer_Send_nElemTotal];
            Buffer_Send_nNeighborFace    =    new unsigned long [Buffer_Send_nElemTotal];
            Buffer_Send_nNeighborCell    =    new unsigned long [Buffer_Send_nElemTotal];
            Buffer_Send_ElemiiNeigh      =    new long [Buffer_Send_nElemiiNeigh*2];
            Buffer_Send_Elemii           =    new unsigned long [Buffer_Send_nElemiiNeigh];
            Buffer_Send_ElemiiiNeigh     =    new long [Buffer_Send_nElemiiiNeigh*3];
            Buffer_Send_Elemiii          =    new unsigned long [Buffer_Send_nElemiiiNeigh];
            Buffer_Send_ElemivNeigh      =    new long [Buffer_Send_nElemivNeigh*4];
            Buffer_Send_Elemiv           =    new unsigned long [Buffer_Send_nElemivNeigh];
            Buffer_Send_ElemvNeigh       =    new long [Buffer_Send_nElemvNeigh*5];
            Buffer_Send_Elemv            =    new unsigned long [Buffer_Send_nElemvNeigh];
            Buffer_Send_ElemviNeigh      =    new long [Buffer_Send_nElemviNeigh*6];
            Buffer_Send_Elemvi           =    new unsigned long [Buffer_Send_nElemviNeigh];
            Buffer_Send_ElemviiNeigh     =    new long [Buffer_Send_nElemviiNeigh*7];
            Buffer_Send_Elemvii          =    new unsigned long [Buffer_Send_nElemviiNeigh];
            Buffer_Send_ElemviiiNeigh    =    new long [Buffer_Send_nElemviiiNeigh*8];
            Buffer_Send_Elemviii         =    new unsigned long [Buffer_Send_nElemviiiNeigh];
            Buffer_Send_OwnerCell =          new long [Buffer_Send_nFaceTotal];
            Buffer_Send_NeighborCell =       new long [Buffer_Send_nFaceTotal];
            Buffer_Send_Coord =              new double [Buffer_Send_nPointTotal*Buffer_Send_nDim];
            Buffer_Send_GlobalPointIndex =   new unsigned long [Buffer_Send_nPointTotal];
            Buffer_Send_Volume            =  new double [Buffer_Send_nElemTotal];
            Buffer_Send_Normal            =  new double [Buffer_Send_nFaceTotal*Buffer_Send_nDim];
            Buffer_Send_StartFace =          new long [Buffer_Send_nMarkerDomain];
            Buffer_Send_Local2Global_Marker= new unsigned long [Buffer_Send_nMarkerDomain];
            Buffer_Send_Bound =               new unsigned long [Buffer_Send_nVertexDomainTotal];

            if (iDomain != MASTER_NODE) {

#ifdef HAVE_MPI

                MPI_Isend(&Buffer_Send_nDim,               1,  MPI_UNSIGNED_SHORT,  iDomain, 0,  MPI_COMM_WORLD, &send_req[0]);
                MPI_Isend(&Buffer_Send_nZone,              1,  MPI_UNSIGNED_SHORT,  iDomain, 1,  MPI_COMM_WORLD, &send_req[1]);
                MPI_Isend(&Buffer_Send_nFaceTotal,         1,  MPI_UNSIGNED_LONG,   iDomain, 2,  MPI_COMM_WORLD, &send_req[2]);
                MPI_Isend(&Buffer_Send_nFaceThreeNode,     1,  MPI_UNSIGNED_LONG,   iDomain, 3,  MPI_COMM_WORLD, &send_req[3]);
                MPI_Isend(&Buffer_Send_nFaceFourNode,      1,  MPI_UNSIGNED_LONG,   iDomain, 4,  MPI_COMM_WORLD, &send_req[4]);
                MPI_Isend(&Buffer_Send_nFaceFiveNode,      1,  MPI_UNSIGNED_LONG,   iDomain, 5,  MPI_COMM_WORLD, &send_req[5]);
                MPI_Isend(&Buffer_Send_nFaceSixNode,       1,  MPI_UNSIGNED_LONG,   iDomain, 6,  MPI_COMM_WORLD, &send_req[6]);
                MPI_Isend(&Buffer_Send_nFaceSevenNode,     1,  MPI_UNSIGNED_LONG,   iDomain, 7,  MPI_COMM_WORLD, &send_req[7]);
                MPI_Isend(&Buffer_Send_nFaceEightNode,     1,  MPI_UNSIGNED_LONG,   iDomain, 8,  MPI_COMM_WORLD, &send_req[8]);
                MPI_Isend(&Buffer_Send_nElemTotal,         1,  MPI_UNSIGNED_LONG,   iDomain, 9,  MPI_COMM_WORLD, &send_req[9]);
                MPI_Isend(&Buffer_Send_nElemDomainTotal,   1,  MPI_UNSIGNED_LONG,   iDomain, 10,  MPI_COMM_WORLD, &send_req[10]);
                MPI_Isend(&Buffer_Send_nElemGhost,         1,  MPI_UNSIGNED_LONG,   iDomain, 11, MPI_COMM_WORLD, &send_req[11]);
                MPI_Isend(&Buffer_Send_nElemiiNeigh,       1,  MPI_UNSIGNED_LONG,   iDomain, 12, MPI_COMM_WORLD, &send_req[12]);
                MPI_Isend(&Buffer_Send_nElemiiiNeigh,      1,  MPI_UNSIGNED_LONG,   iDomain, 13, MPI_COMM_WORLD, &send_req[13]);
                MPI_Isend(&Buffer_Send_nElemivNeigh,       1,  MPI_UNSIGNED_LONG,   iDomain, 14, MPI_COMM_WORLD, &send_req[14]);
                MPI_Isend(&Buffer_Send_nElemvNeigh,        1,  MPI_UNSIGNED_LONG,   iDomain, 15, MPI_COMM_WORLD, &send_req[15]);
                MPI_Isend(&Buffer_Send_nElemviNeigh,       1,  MPI_UNSIGNED_LONG,   iDomain, 16, MPI_COMM_WORLD, &send_req[16]);
                MPI_Isend(&Buffer_Send_nElemviiNeigh,      1,  MPI_UNSIGNED_LONG,   iDomain, 17, MPI_COMM_WORLD, &send_req[17]);
                MPI_Isend(&Buffer_Send_nElemviiiNeigh,     1,  MPI_UNSIGNED_LONG,   iDomain, 18, MPI_COMM_WORLD, &send_req[18]);
                MPI_Isend(&Buffer_Send_nPointTotal,        1,  MPI_UNSIGNED_LONG,   iDomain, 19, MPI_COMM_WORLD, &send_req[19]);
                MPI_Isend(&Buffer_Send_nMarkerDomain,      1,  MPI_UNSIGNED_SHORT,  iDomain, 20, MPI_COMM_WORLD, &send_req[20]);
                MPI_Isend(Buffer_Send_nVertexDomain,       nMarker_Max, MPI_UNSIGNED_LONG,  iDomain, 21, MPI_COMM_WORLD, &send_req[21]);
                MPI_Isend(Buffer_Send_Marker_All_SendRecv, nMarker_Max, MPI_SHORT,          iDomain, 22, MPI_COMM_WORLD, &send_req[22]);
                MPI_Isend(&Buffer_Send_nVertexDomainTotal,         1,  MPI_UNSIGNED_LONG,   iDomain, 23, MPI_COMM_WORLD, &send_req[23]);
                MPI_Isend(Buffer_Send_Marker_All_TagBound,  nMarker_Max*MAX_STRING_SIZE, MPI_CHAR,           iDomain, 24, MPI_COMM_WORLD, &send_req[24]);

                /*--- Wait for this set of non-blocking comm. to complete ---*/

                MPI_Waitall(25, send_req, send_stat);

#endif

                //PART5# in the master node, if the iDomian != 0, the created Send Buffers will be sent to the distinct ranks.//

            } else {

                nDim = Buffer_Send_nDim;
                nZone = Buffer_Send_nZone;

                nFaceTotal       = Buffer_Send_nFaceTotal;
                nFaceThreeNode    = Buffer_Send_nFaceThreeNode;
                nFaceFourNode    = Buffer_Send_nFaceFourNode;
                nFaceFiveNode    = Buffer_Send_nFaceFiveNode;
                nFaceSixNode     = Buffer_Send_nFaceSixNode;
                nFaceSevenNode   = Buffer_Send_nFaceSevenNode;
                nFaceEightNode   = Buffer_Send_nFaceEightNode;


                nElemTotal       = Buffer_Send_nElemTotal;
                nElemDomainTotal = Buffer_Send_nElemDomainTotal;
                nElemGhost       = Buffer_Send_nElemGhost;
                nElemiiNeigh     = Buffer_Send_nElemiiNeigh;
                nElemiiiNeigh    = Buffer_Send_nElemiiiNeigh;
                nElemivNeigh     = Buffer_Send_nElemivNeigh;
                nElemvNeigh      = Buffer_Send_nElemvNeigh;
                nElemviNeigh     = Buffer_Send_nElemviNeigh;
                nElemviiNeigh    = Buffer_Send_nElemviiNeigh;
                nElemviiiNeigh   = Buffer_Send_nElemviiiNeigh;
                nPointTotal      = Buffer_Send_nPointTotal;
                nMarkerDomain    = Buffer_Send_nMarkerDomain;

                for (iMarker = 0; iMarker < nMarker_Max; iMarker++) {
                    nVertexDomain[iMarker] = Buffer_Send_nVertexDomain[iMarker];
                    Marker_All_SendRecv[iMarker] = Buffer_Send_Marker_All_SendRecv[iMarker];
                    for (iter = 0; iter < MAX_STRING_SIZE; iter++)
                        Marker_All_TagBound[iMarker*MAX_STRING_SIZE+iter] = Buffer_Send_Marker_All_TagBound[iMarker*MAX_STRING_SIZE+iter];
                }
                nVertexDomainTotal  =  Buffer_Send_nVertexDomainTotal;
            }
            //PART6# in the master node, the Buffer vectors are simply copied into places.//
        }

        if (rank == iDomain) {

            if (rank != MASTER_NODE) {

#ifdef HAVE_MPI

                MPI_Irecv(&nDim,                1, MPI_UNSIGNED_SHORT, MASTER_NODE, 0,   MPI_COMM_WORLD, &recv_req[0]);
                MPI_Irecv(&nZone,               1, MPI_UNSIGNED_SHORT, MASTER_NODE, 1,   MPI_COMM_WORLD, &recv_req[1]);
                MPI_Irecv(&nFaceTotal,          1, MPI_UNSIGNED_LONG,  MASTER_NODE, 2,   MPI_COMM_WORLD, &recv_req[2]);
                MPI_Irecv(&nFaceThreeNode,      1, MPI_UNSIGNED_LONG,  MASTER_NODE, 3,   MPI_COMM_WORLD, &recv_req[3]);
                MPI_Irecv(&nFaceFourNode,       1, MPI_UNSIGNED_LONG,  MASTER_NODE, 4,   MPI_COMM_WORLD, &recv_req[4]);
                MPI_Irecv(&nFaceFiveNode,       1, MPI_UNSIGNED_LONG,  MASTER_NODE, 5,   MPI_COMM_WORLD, &recv_req[5]);
                MPI_Irecv(&nFaceSixNode,        1, MPI_UNSIGNED_LONG,  MASTER_NODE, 6,   MPI_COMM_WORLD, &recv_req[6]);
                MPI_Irecv(&nFaceSevenNode,      1, MPI_UNSIGNED_LONG,  MASTER_NODE, 7,   MPI_COMM_WORLD, &recv_req[7]);
                MPI_Irecv(&nFaceEightNode,      1, MPI_UNSIGNED_LONG,  MASTER_NODE, 8,   MPI_COMM_WORLD, &recv_req[8]);
                MPI_Irecv(&nElemTotal,          1, MPI_UNSIGNED_LONG,  MASTER_NODE, 9,   MPI_COMM_WORLD, &recv_req[9]);
                MPI_Irecv(&nElemDomainTotal,    1, MPI_UNSIGNED_LONG,  MASTER_NODE, 10,   MPI_COMM_WORLD, &recv_req[10]);
                MPI_Irecv(&nElemGhost,          1, MPI_UNSIGNED_LONG,  MASTER_NODE, 11,   MPI_COMM_WORLD, &recv_req[11]);
                MPI_Irecv(&nElemiiNeigh,        1, MPI_UNSIGNED_LONG,  MASTER_NODE, 12,   MPI_COMM_WORLD, &recv_req[12]);
                MPI_Irecv(&nElemiiiNeigh,       1, MPI_UNSIGNED_LONG,  MASTER_NODE, 13,   MPI_COMM_WORLD, &recv_req[13]);
                MPI_Irecv(&nElemivNeigh,        1, MPI_UNSIGNED_LONG,  MASTER_NODE, 14,   MPI_COMM_WORLD, &recv_req[14]);
                MPI_Irecv(&nElemvNeigh,         1, MPI_UNSIGNED_LONG,  MASTER_NODE, 15,  MPI_COMM_WORLD, &recv_req[15]);
                MPI_Irecv(&nElemviNeigh,        1, MPI_UNSIGNED_LONG,  MASTER_NODE, 16,  MPI_COMM_WORLD, &recv_req[16]);
                MPI_Irecv(&nElemviiNeigh,       1, MPI_UNSIGNED_LONG,  MASTER_NODE, 17,  MPI_COMM_WORLD, &recv_req[17]);
                MPI_Irecv(&nElemviiiNeigh,      1, MPI_UNSIGNED_LONG,  MASTER_NODE, 18,  MPI_COMM_WORLD, &recv_req[18]);
                MPI_Irecv(&nPointTotal,         1, MPI_UNSIGNED_LONG,  MASTER_NODE, 19,  MPI_COMM_WORLD, &recv_req[19]);
                MPI_Irecv(&nMarkerDomain,       1, MPI_UNSIGNED_SHORT, MASTER_NODE, 20,  MPI_COMM_WORLD, &recv_req[20]);
                MPI_Irecv(nVertexDomain,        nMarker_Max,  MPI_UNSIGNED_LONG, MASTER_NODE, 21, MPI_COMM_WORLD, &recv_req[21]);
                MPI_Irecv(Marker_All_SendRecv, nMarker_Max,          MPI_SHORT, MASTER_NODE, 22, MPI_COMM_WORLD, &recv_req[22]);
                MPI_Irecv(&nVertexDomainTotal,   1, MPI_UNSIGNED_LONG,  MASTER_NODE, 23,   MPI_COMM_WORLD, &recv_req[23]);
                MPI_Irecv(Marker_All_TagBound,      nMarker_Max*MAX_STRING_SIZE,       MPI_CHAR, MASTER_NODE, 24, MPI_COMM_WORLD, &recv_req[24]);

                /*--- Wait for the this set of non-blocking recv's to complete ---*/

                MPI_Waitall(25, recv_req, recv_stat);

#endif
                for (iMarker = 0; iMarker < config->GetnMarker_All(); iMarker++) {
                    config->SetMarker_All_SendRecv(iMarker, Marker_All_SendRecv[iMarker]);
                    config->SetMarker_All_TagBound(iMarker, string(&Marker_All_TagBound[iMarker*MAX_STRING_SIZE]));
                }

                //PART7# The Copied values from Send Buffers are placed in the distinct ranks.
                //And, Marker_All_SendRecv is set in the config files of all the files//
            }

            Buffer_Receive_CGF               =  new double [nFaceTotal*nDim];
            Buffer_Receive_GlobalFaceIndex   =  new unsigned long [nFaceTotal];
            Buffer_Receive_nNeighborNode     =  new unsigned long [nFaceTotal];
            Buffer_Receive_FaceThreeNode     =  new unsigned long [nFaceThreeNode*3];
            Buffer_Receive_Faceiii           =  new unsigned long [nFaceThreeNode];
            Buffer_Receive_FaceFourNode      =  new unsigned long [nFaceFourNode*4];
            Buffer_Receive_Faceiv            =  new unsigned long [nFaceFourNode];
            Buffer_Receive_FaceFiveNode      =  new unsigned long [nFaceFiveNode*5];
            Buffer_Receive_Facev             =  new unsigned long [nFaceFiveNode];
            Buffer_Receive_FaceSixNode       =  new unsigned long [nFaceSixNode*6];
            Buffer_Receive_Facevi            =  new unsigned long [nFaceSixNode];
            Buffer_Receive_FaceSevenNode     =  new unsigned long [nFaceSevenNode*7];
            Buffer_Receive_Facevii           =  new unsigned long [nFaceSevenNode];
            Buffer_Receive_FaceEightNode     =  new unsigned long [nFaceEightNode*8];
            Buffer_Receive_Faceviii          =  new unsigned long [nFaceEightNode];
            Buffer_Receive_CGE               =  new double [nElemTotal*nDim];
            Buffer_Receive_GlobalElemIndex   =  new unsigned long [nElemTotal];
            Buffer_Receive_Color             =  new unsigned long [nElemTotal];
            Buffer_Receive_nNeighborFace     =  new unsigned long [nElemTotal];
            Buffer_Receive_nNeighborCell     =  new unsigned long [nElemTotal];
            Buffer_Receive_ElemiiNeigh       =  new long [nElemiiNeigh*2];
            Buffer_Receive_Elemii            =  new unsigned long [nElemiiNeigh];
            Buffer_Receive_ElemiiiNeigh      =  new long [nElemiiiNeigh*3];
            Buffer_Receive_Elemiii           =  new unsigned long [nElemiiiNeigh];
            Buffer_Receive_ElemivNeigh       =  new long [nElemivNeigh*4];
            Buffer_Receive_Elemiv            =  new unsigned long [nElemivNeigh];
            Buffer_Receive_ElemvNeigh        =  new long [nElemvNeigh*5];
            Buffer_Receive_Elemv             =  new unsigned long [nElemvNeigh];
            Buffer_Receive_ElemviNeigh       =  new long [nElemviNeigh*6];
            Buffer_Receive_Elemvi            =  new unsigned long [nElemviNeigh];
            Buffer_Receive_ElemviiNeigh      =  new long [nElemviiNeigh*7];
            Buffer_Receive_Elemvii           =  new unsigned long [nElemviiNeigh];
            Buffer_Receive_ElemviiiNeigh     =  new long [nElemviiiNeigh*8];
            Buffer_Receive_Elemviii          =  new unsigned long [nElemviiiNeigh];
            Buffer_Receive_OwnerCell =          new long [nFaceTotal];
            Buffer_Receive_NeighborCell =       new long [nFaceTotal];
            Buffer_Receive_Coord =              new double [nPointTotal*nDim];
            Buffer_Receive_GlobalPointIndex =   new unsigned long [nPointTotal];
            Buffer_Receive_Volume            =  new double [nElemTotal];
            Buffer_Receive_Normal            =  new double [nFaceTotal*nDim];
            Buffer_Receive_StartFace =          new long [nMarkerDomain];
            Buffer_Receive_Local2Global_Marker= new unsigned long [nMarkerDomain];
            Buffer_Receive_Bound =              new unsigned long [nVertexDomainTotal];

        }

        if (rank == MASTER_NODE) {

            iFaceTotal = 0; iElemTotal = 0; iElemDomain = 0; iElemGhost = Buffer_Send_nElemDomainTotal; iPointTotal =0; iFaceThreeNode = 0; iFaceFourNode = 0;
            iFaceFiveNode = 0;  iFaceSixNode = 0; iFaceSevenNode = 0; iFaceEightNode = 0;
            iElemiiNeigh = 0; iElemiiiNeigh = 0; iElemivNeigh = 0; iElemvNeigh = 0; iElemviNeigh = 0;
            iElemviiNeigh = 0; iElemviiiNeigh = 0;

            for (iFace = 0; iFace < geometry->GetnFace(); iFace++) Global_to_Local_Face[iFace] = -1;
            for (iElem = 0; iElem < geometry->GetnElem(); iElem++) Global_to_Local_Elem[iElem] = -1;
            for (iPoint = 0; iPoint < geometry->GetnPoint(); iPoint++) Global_to_Local_Point[iPoint] = -1;
            for (iElem = 0; iElem < geometry->GetnElem(); iElem++) Global_to_Local_Neigh[iElem] = -1;

            for (jFace = 0; jFace < nFace_Color[iDomain]; jFace++) {
                iFace = Face_Color[iDomain][jFace];

                if(Global_to_Local_Face[iFace] == -1){

                    Global_to_Local_Face[iFace] = iFaceTotal;
                    Buffer_Send_GlobalFaceIndex[iFaceTotal] = iFace;

                    for (iDim = 0; iDim < Buffer_Send_nDim; iDim++){
                        Buffer_Send_CGF[Buffer_Send_nDim*iFaceTotal+iDim] = geometry->face[iFace]->GetCG(iDim);
                        Buffer_Send_Normal[Buffer_Send_nDim*iFaceTotal+iDim] = geometry->face[iFace]->GetNormal_Face(iDim);
                    }
                    Buffer_Send_nNeighborNode[iFaceTotal] = geometry->face[iFace]->GetnNodes_Face();

                    for (iNode = 0; iNode < geometry->face[iFace]->GetnNodes_Face(); iNode++) {
                        iPoint = geometry->face[iFace]->GetNode_Face(iNode);

                        if (Global_to_Local_Point[iPoint] == -1){
                            Global_to_Local_Point[iPoint] = iPointTotal;
                            Buffer_Send_GlobalPointIndex[iPointTotal] = iPoint;

                            for (iDim = 0; iDim < Buffer_Send_nDim; iDim++)
                                Buffer_Send_Coord[Buffer_Send_nDim*iPointTotal+iDim] = geometry->node[iPoint]->GetCoord(iDim);
                            iPointTotal++;
                        }
                        vnodes_local[iNode] = Global_to_Local_Point[iPoint];
                    }

                    if(geometry->face[iFace]->GetnNodes_Face() == 3){
                        for (iNode = 0; iNode < geometry->face[iFace]->GetnNodes_Face(); iNode++) {
                            Buffer_Send_FaceThreeNode[3*iFaceThreeNode+iNode] = vnodes_local[iNode];
                        }
                        Buffer_Send_Faceiii[iFaceThreeNode] = iFaceTotal;
                        iFaceThreeNode++;
                    }

                    if(geometry->face[iFace]->GetnNodes_Face() == 4){
                        for (iNode = 0; iNode < geometry->face[iFace]->GetnNodes_Face(); iNode++) {
                            Buffer_Send_FaceFourNode[4*iFaceFourNode+iNode] = vnodes_local[iNode];
                        }
                        Buffer_Send_Faceiv[iFaceFourNode] = iFaceTotal;
                        iFaceFourNode++;
                    }

                    if(geometry->face[iFace]->GetnNodes_Face() == 5){
                        for (iNode = 0; iNode < geometry->face[iFace]->GetnNodes_Face(); iNode++) {
                            Buffer_Send_FaceFiveNode[5*iFaceFiveNode+iNode] = vnodes_local[iNode];
                        }
                        Buffer_Send_Facev[iFaceFiveNode] = iFaceTotal;
                        iFaceFiveNode++;
                    }

                    if(geometry->face[iFace]->GetnNodes_Face() == 6){
                        for (iNode = 0; iNode < geometry->face[iFace]->GetnNodes_Face(); iNode++) {
                            Buffer_Send_FaceSixNode[6*iFaceSixNode+iNode] = vnodes_local[iNode];
                        }
                        Buffer_Send_Facevi[iFaceSixNode] = iFaceTotal;
                        iFaceSixNode++;
                    }

                    if(geometry->face[iFace]->GetnNodes_Face() == 7){
                        for (iNode = 0; iNode < geometry->face[iFace]->GetnNodes_Face(); iNode++) {
                            Buffer_Send_FaceSevenNode[7*iFaceSevenNode+iNode] = vnodes_local[iNode];
                        }
                        Buffer_Send_Facevii[iFaceSevenNode] = iFaceTotal;
                        iFaceSevenNode++;
                    }

                    if(geometry->face[iFace]->GetnNodes_Face() == 8){
                        for (iNode = 0; iNode < geometry->face[iFace]->GetnNodes_Face(); iNode++) {
                            Buffer_Send_FaceEightNode[8*iFaceEightNode+iNode] = vnodes_local[iNode];
                        }
                        Buffer_Send_Faceviii[iFaceEightNode] = iFaceTotal;
                        iFaceEightNode++;
                    }

                    iFaceTotal++;
                }
            }

            for (jFace = 0; jFace < nFace_Color[iDomain]; jFace++) {
                iFace = Face_Color[iDomain][jFace];
                for(i = 0; i < 2; i++){
                    if(geometry->face[iFace]->GetElems(i) != -1){
                        iElem = geometry->face[iFace]->GetElems(i);

                        if(Global_to_Local_Elem[iElem] == -1) {

                            if(geometry->elem[iElem]->GetColor() == iDomain) iElemTotal = iElemDomain;
                            else iElemTotal = iElemGhost;

                            Global_to_Local_Elem[iElem] = iElemTotal;
                            Buffer_Send_Color[iElemTotal] = geometry->elem[iElem]->GetColor();
                            Buffer_Send_GlobalElemIndex[iElemTotal] = iElem;

                            for (iDim = 0; iDim < Buffer_Send_nDim; iDim++)
                                Buffer_Send_CGE[Buffer_Send_nDim*iElemTotal+iDim] = geometry->elem[iElem]->GetCG(iDim);

                            Buffer_Send_Volume[iElemTotal] = geometry->elem[iElem]->GetVolume();
                            Buffer_Send_nNeighborFace[iElemTotal] = geometry->elem[iElem]->GetnNeighbor_Face();
                            Buffer_Send_nNeighborCell[iElemTotal] = geometry->elem[iElem]->GetnNeighbor_Cell();

                            if(geometry->elem[iElem]->GetColor() == iDomain) iElemDomain++;
                            else iElemGhost++;
                        }
                    }
                }
            }

            for (jFace = 0; jFace < nFace_Color[iDomain]; jFace++) {
                iFace = Face_Color[iDomain][jFace];

                iOwner = geometry->face[iFace]->GetElems(0);
                if(geometry->face[iFace]->GetElems(1) != -1) iNeighbor = geometry->face[iFace]->GetElems(1);

                Buffer_Send_OwnerCell[Global_to_Local_Face[iFace]] = Global_to_Local_Elem[iOwner];
                if(geometry->face[iFace]->GetElems(1) != -1) Buffer_Send_NeighborCell[Global_to_Local_Face[iFace]] = Global_to_Local_Elem[iNeighbor];
                else Buffer_Send_NeighborCell[Global_to_Local_Face[iFace]] = -1;

                for(i = 0; i < 2; i++){
                    if(geometry->face[iFace]->GetElems(i) != -1){
                        iElem = geometry->face[iFace]->GetElems(i);
                        if(Global_to_Local_Neigh[iElem] == -1){
                            Global_to_Local_Neigh[iElem] = 1;

                            if(geometry->elem[iElem]->GetnNeighbor_Cell() == 2){
                                for(kFace = 0; kFace < 2; kFace++){
                                    jElem = geometry->elem[iElem]->GetNeighbor_Cell(kFace);
                                    if(Global_to_Local_Elem[jElem] != -1)
                                        Buffer_Send_ElemiiNeigh[2*iElemiiNeigh+kFace] = Global_to_Local_Elem[jElem];

                                    else Buffer_Send_ElemiiNeigh[2*iElemiiNeigh+kFace] = -1;
                                }
                                Buffer_Send_Elemii[iElemiiNeigh] = Global_to_Local_Elem[iElem];
                                iElemiiNeigh++;
                            }

                            if(geometry->elem[iElem]->GetnNeighbor_Cell() == 3){
                                for(kFace = 0; kFace < 3; kFace++){
                                    jElem = geometry->elem[iElem]->GetNeighbor_Cell(kFace);
                                    if(Global_to_Local_Elem[jElem] != -1)
                                        Buffer_Send_ElemiiiNeigh[3*iElemiiiNeigh+kFace] = Global_to_Local_Elem[jElem];

                                    else Buffer_Send_ElemiiiNeigh[3*iElemiiiNeigh+kFace] = -1;
                                }
                                Buffer_Send_Elemiii[iElemiiiNeigh] = Global_to_Local_Elem[iElem];
                                iElemiiiNeigh++;
                            }

                            if(geometry->elem[iElem]->GetnNeighbor_Cell() == 4){
                                for(kFace = 0; kFace < 4; kFace++){
                                    jElem = geometry->elem[iElem]->GetNeighbor_Cell(kFace);
                                    if(Global_to_Local_Elem[jElem] != -1)
                                        Buffer_Send_ElemivNeigh[4*iElemivNeigh+kFace] = Global_to_Local_Elem[jElem];

                                    else Buffer_Send_ElemivNeigh[4*iElemivNeigh+kFace] = -1;
                                }
                                Buffer_Send_Elemiv[iElemivNeigh] = Global_to_Local_Elem[iElem];
                                iElemivNeigh++;
                            }

                            if(geometry->elem[iElem]->GetnNeighbor_Cell() == 5){
                                for(kFace = 0; kFace < 5; kFace++){
                                    jElem = geometry->elem[iElem]->GetNeighbor_Cell(kFace);
                                    if(Global_to_Local_Elem[jElem] != -1)
                                        Buffer_Send_ElemvNeigh[5*iElemvNeigh+kFace] = Global_to_Local_Elem[jElem];

                                    else Buffer_Send_ElemvNeigh[5*iElemvNeigh+kFace] = -1;
                                }
                                Buffer_Send_Elemv[iElemvNeigh] = Global_to_Local_Elem[iElem];
                                iElemvNeigh++;
                            }

                            if(geometry->elem[iElem]->GetnNeighbor_Cell() == 6){
                                for(kFace = 0; kFace < 6; kFace++){
                                    jElem = geometry->elem[iElem]->GetNeighbor_Cell(kFace);
                                    if(Global_to_Local_Elem[jElem] != -1)
                                        Buffer_Send_ElemviNeigh[6*iElemviNeigh+kFace] = Global_to_Local_Elem[jElem];

                                    else Buffer_Send_ElemviNeigh[6*iElemviNeigh+kFace] = -1;
                                }
                                Buffer_Send_Elemvi[iElemviNeigh] = Global_to_Local_Elem[iElem];
                                iElemviNeigh++;
                            }

                            if(geometry->elem[iElem]->GetnNeighbor_Cell() == 7){
                                for(kFace = 0; kFace < 7; kFace++){
                                    jElem = geometry->elem[iElem]->GetNeighbor_Cell(kFace);
                                    if(Global_to_Local_Elem[jElem] != -1)
                                        Buffer_Send_ElemviiNeigh[7*iElemviiNeigh+kFace] = Global_to_Local_Elem[jElem];

                                    else Buffer_Send_ElemviiNeigh[7*iElemviiNeigh+kFace] = -1;
                                }
                                Buffer_Send_Elemvii[iElemviiNeigh] = Global_to_Local_Elem[iElem];
                                iElemviiNeigh++;
                            }

                            if(geometry->elem[iElem]->GetnNeighbor_Cell() == 8){
                                for(kFace = 0; kFace < 8; kFace++){
                                    jElem = geometry->elem[iElem]->GetNeighbor_Cell(kFace);
                                    if(Global_to_Local_Elem[jElem] != -1)
                                        Buffer_Send_ElemviiiNeigh[8*iElemviiiNeigh+kFace] = Global_to_Local_Elem[jElem];

                                    else Buffer_Send_ElemviiiNeigh[8*iElemviiiNeigh+kFace] = -1;
                                }
                                Buffer_Send_Elemviii[iElemviiiNeigh] = Global_to_Local_Elem[iElem];
                                iElemviiiNeigh++;
                            }

                        }
                    }
                }
            }

            iMarkerDomain = 0;
            iVertexDomainTotal = 0;
            for (iMarker = 0; iMarker < geometry->GetnMarker(); iMarker++) {
                if ((config->GetMarker_All_KindBC(iMarker) != SEND_RECEIVE) && (MarkerIn[iMarker])) {
                    iFace = geometry->GetStart_Face(iMarker);
                    iElem = geometry->face[iFace]->GetElems(0);
                    if(Global_to_Local_Face[iFace] != -1){
                        Buffer_Send_StartFace[iMarkerDomain] = Global_to_Local_Face[iFace];
                    }
                    else Buffer_Send_StartFace[iMarkerDomain] = -1;

                    for (iVertex = 0; iVertex < geometry->GetnElem_Bound(iMarker); iVertex++) {
                        jFace = geometry->bound[iMarker][iVertex]->GetGlobalFace();
                        jElem = geometry->face[jFace]->GetElems(0);

                        if(Global_to_Local_Face[jFace] != -1){
                            Buffer_Send_Bound[iVertexDomainTotal] = Global_to_Local_Face[jFace];
                            iVertexDomainTotal++;
                        }
                    }
                    Buffer_Send_Local2Global_Marker[iMarkerDomain] = iMarker;
                    iMarkerDomain++;
                }
            }

            //PART8# in the master node, Buffer_Send_CGF, CGE, Coord, Color, GlobalFaceIndex, GlobalElemIndex, GlobalPointIndex,
            //FaceThree...Node, ElemFourFace, StartFace, Local2Global_Marker are created.//

            if (iDomain != MASTER_NODE) {

#ifdef HAVE_MPI
                MPI_Isend(Buffer_Send_CGF,                 Buffer_Send_nFaceTotal*Buffer_Send_nDim,       MPI_DOUBLE,        iDomain, 0,   MPI_COMM_WORLD, &send_req[0]);
                MPI_Isend(Buffer_Send_GlobalFaceIndex,     Buffer_Send_nFaceTotal,                        MPI_UNSIGNED_LONG, iDomain, 1,   MPI_COMM_WORLD, &send_req[1]);
                MPI_Isend(Buffer_Send_nNeighborNode,       Buffer_Send_nFaceTotal,                        MPI_UNSIGNED_LONG, iDomain, 2,   MPI_COMM_WORLD, &send_req[2]);
                MPI_Isend(Buffer_Send_FaceThreeNode,       Buffer_Send_nFaceThreeNode*3,                  MPI_UNSIGNED_LONG, iDomain, 3,   MPI_COMM_WORLD, &send_req[3]);
                MPI_Isend(Buffer_Send_Faceiii,             Buffer_Send_nFaceThreeNode,                    MPI_UNSIGNED_LONG, iDomain, 4,   MPI_COMM_WORLD, &send_req[4]);
                MPI_Isend(Buffer_Send_FaceFourNode,        Buffer_Send_nFaceFourNode*4,                   MPI_UNSIGNED_LONG, iDomain, 5,   MPI_COMM_WORLD, &send_req[5]);
                MPI_Isend(Buffer_Send_Faceiv,              Buffer_Send_nFaceFourNode,                     MPI_UNSIGNED_LONG, iDomain, 6,   MPI_COMM_WORLD, &send_req[6]);
                MPI_Isend(Buffer_Send_FaceFiveNode,        Buffer_Send_nFaceFiveNode*5,                   MPI_UNSIGNED_LONG, iDomain, 7,   MPI_COMM_WORLD, &send_req[7]);
                MPI_Isend(Buffer_Send_Facev,               Buffer_Send_nFaceFiveNode,                     MPI_UNSIGNED_LONG, iDomain, 8,   MPI_COMM_WORLD, &send_req[8]);
                MPI_Isend(Buffer_Send_FaceSixNode,         Buffer_Send_nFaceSixNode*6,                    MPI_UNSIGNED_LONG, iDomain, 9,   MPI_COMM_WORLD, &send_req[9]);
                MPI_Isend(Buffer_Send_Facevi,              Buffer_Send_nFaceSixNode,                      MPI_UNSIGNED_LONG, iDomain, 10,   MPI_COMM_WORLD, &send_req[10]);
                MPI_Isend(Buffer_Send_FaceSevenNode,       Buffer_Send_nFaceSevenNode*7,                  MPI_UNSIGNED_LONG, iDomain, 11,   MPI_COMM_WORLD, &send_req[11]);
                MPI_Isend(Buffer_Send_Facevii,             Buffer_Send_nFaceSevenNode,                    MPI_UNSIGNED_LONG, iDomain, 12,   MPI_COMM_WORLD, &send_req[12]);
                MPI_Isend(Buffer_Send_FaceEightNode,       Buffer_Send_nFaceEightNode*8,                  MPI_UNSIGNED_LONG, iDomain, 13,   MPI_COMM_WORLD, &send_req[13]);
                MPI_Isend(Buffer_Send_Faceviii,            Buffer_Send_nFaceEightNode,                    MPI_UNSIGNED_LONG, iDomain, 14,   MPI_COMM_WORLD, &send_req[14]);
                MPI_Isend(Buffer_Send_CGE,                 Buffer_Send_nElemTotal*nDim,                   MPI_DOUBLE,        iDomain, 15,   MPI_COMM_WORLD, &send_req[15]);
                MPI_Isend(Buffer_Send_GlobalElemIndex,     Buffer_Send_nElemTotal,                        MPI_UNSIGNED_LONG, iDomain, 16,   MPI_COMM_WORLD, &send_req[16]);
                MPI_Isend(Buffer_Send_Color,               Buffer_Send_nElemTotal,                        MPI_UNSIGNED_LONG, iDomain, 17,   MPI_COMM_WORLD, &send_req[17]);
                MPI_Isend(Buffer_Send_nNeighborFace,       Buffer_Send_nElemTotal,                        MPI_UNSIGNED_LONG, iDomain, 18,  MPI_COMM_WORLD, &send_req[18]);
                MPI_Isend(Buffer_Send_nNeighborCell,       Buffer_Send_nElemTotal,                        MPI_UNSIGNED_LONG, iDomain, 19,  MPI_COMM_WORLD, &send_req[19]);
                MPI_Isend(Buffer_Send_ElemiiNeigh,         Buffer_Send_nElemiiNeigh*2,                   MPI_LONG, iDomain, 20,           MPI_COMM_WORLD, &send_req[20]);
                MPI_Isend(Buffer_Send_Elemii,              Buffer_Send_nElemiiNeigh,                     MPI_UNSIGNED_LONG, iDomain, 21,  MPI_COMM_WORLD, &send_req[21]);
                MPI_Isend(Buffer_Send_ElemiiiNeigh,        Buffer_Send_nElemiiiNeigh*3,                    MPI_LONG, iDomain, 22,           MPI_COMM_WORLD, &send_req[22]);
                MPI_Isend(Buffer_Send_Elemiii,             Buffer_Send_nElemiiiNeigh,                      MPI_UNSIGNED_LONG, iDomain, 23,  MPI_COMM_WORLD, &send_req[23]);
                MPI_Isend(Buffer_Send_ElemivNeigh,         Buffer_Send_nElemivNeigh*4,                     MPI_LONG, iDomain, 24,           MPI_COMM_WORLD, &send_req[24]);
                MPI_Isend(Buffer_Send_Elemiv,              Buffer_Send_nElemivNeigh,                       MPI_UNSIGNED_LONG, iDomain, 25,  MPI_COMM_WORLD, &send_req[25]);
                MPI_Isend(Buffer_Send_ElemvNeigh,          Buffer_Send_nElemvNeigh*5,                    MPI_LONG, iDomain, 26,           MPI_COMM_WORLD, &send_req[26]);
                MPI_Isend(Buffer_Send_Elemv,               Buffer_Send_nElemvNeigh,                      MPI_UNSIGNED_LONG, iDomain, 27,  MPI_COMM_WORLD, &send_req[27]);
                MPI_Isend(Buffer_Send_ElemviNeigh,         Buffer_Send_nElemviNeigh*6,                    MPI_LONG, iDomain, 28,           MPI_COMM_WORLD, &send_req[28]);
                MPI_Isend(Buffer_Send_Elemvi,              Buffer_Send_nElemviNeigh,                      MPI_UNSIGNED_LONG, iDomain, 29,  MPI_COMM_WORLD, &send_req[29]);
                MPI_Isend(Buffer_Send_ElemviiNeigh,        Buffer_Send_nElemviiNeigh*7,                    MPI_LONG, iDomain, 30,           MPI_COMM_WORLD, &send_req[30]);
                MPI_Isend(Buffer_Send_Elemvii,             Buffer_Send_nElemviiNeigh,                      MPI_UNSIGNED_LONG, iDomain, 31,  MPI_COMM_WORLD, &send_req[31]);
                MPI_Isend(Buffer_Send_ElemviiiNeigh,       Buffer_Send_nElemviiiNeigh*8,                    MPI_LONG, iDomain, 32,           MPI_COMM_WORLD, &send_req[32]);
                MPI_Isend(Buffer_Send_Elemviii,            Buffer_Send_nElemviiiNeigh,                      MPI_UNSIGNED_LONG, iDomain, 33,  MPI_COMM_WORLD, &send_req[33]);
                MPI_Isend(Buffer_Send_OwnerCell,           Buffer_Send_nFaceTotal,                        MPI_LONG, iDomain, 34,           MPI_COMM_WORLD, &send_req[34]);
                MPI_Isend(Buffer_Send_NeighborCell,        Buffer_Send_nFaceTotal,                        MPI_LONG, iDomain, 35,           MPI_COMM_WORLD, &send_req[35]);
                MPI_Isend(Buffer_Send_Coord,               Buffer_Send_nPointTotal*nDim,                  MPI_DOUBLE,        iDomain, 36,  MPI_COMM_WORLD, &send_req[36]);
                MPI_Isend(Buffer_Send_GlobalPointIndex,    Buffer_Send_nPointTotal,                       MPI_UNSIGNED_LONG, iDomain, 37,  MPI_COMM_WORLD, &send_req[37]);
                MPI_Isend(Buffer_Send_Volume,              Buffer_Send_nElemTotal,                        MPI_DOUBLE,        iDomain, 38,  MPI_COMM_WORLD, &send_req[38]);
                MPI_Isend(Buffer_Send_Normal,              Buffer_Send_nFaceTotal*Buffer_Send_nDim,       MPI_DOUBLE,        iDomain, 39,  MPI_COMM_WORLD, &send_req[39]);
                MPI_Isend(Buffer_Send_StartFace,           Buffer_Send_nMarkerDomain,                     MPI_LONG, iDomain, 40,           MPI_COMM_WORLD, &send_req[40]);
                MPI_Isend(Buffer_Send_Local2Global_Marker, Buffer_Send_nMarkerDomain,                     MPI_UNSIGNED_LONG, iDomain, 41,  MPI_COMM_WORLD, &send_req[41]);
                MPI_Isend(Buffer_Send_Bound,               Buffer_Send_nVertexDomainTotal,                MPI_UNSIGNED_LONG, iDomain, 42,  MPI_COMM_WORLD, &send_req[42]);

                /*--- Wait for this set of non-blocking comm. to complete ---*/

                MPI_Waitall(43, send_req, send_stat);

#endif

                //PART9# The created Buffere Send vectors have been sent to the distinct ranks.//

            } else {

                for (iter = 0; iter < Buffer_Send_nFaceTotal*Buffer_Send_nDim; iter++){
                    Buffer_Receive_CGF[iter] = Buffer_Send_CGF[iter];
                    Buffer_Receive_Normal[iter] = Buffer_Send_Normal[iter];
                }

                for (iter = 0; iter < Buffer_Send_nFaceTotal; iter++) {
                    Buffer_Receive_GlobalFaceIndex[iter] = Buffer_Send_GlobalFaceIndex[iter];
                    Buffer_Receive_nNeighborNode[iter] = Buffer_Send_nNeighborNode[iter];
                    Buffer_Receive_OwnerCell[iter] = Buffer_Send_OwnerCell[iter];
                    Buffer_Receive_NeighborCell[iter] = Buffer_Send_NeighborCell[iter];
                }

                for (iter = 0; iter < Buffer_Send_nFaceThreeNode*3; iter++)
                    Buffer_Receive_FaceThreeNode[iter] =  Buffer_Send_FaceThreeNode[iter];

                for (iter = 0; iter < Buffer_Send_nFaceThreeNode; iter++)
                    Buffer_Receive_Faceiii[iter] =  Buffer_Send_Faceiii[iter];

                for (iter = 0; iter < Buffer_Send_nFaceFourNode*4; iter++)
                    Buffer_Receive_FaceFourNode[iter] =  Buffer_Send_FaceFourNode[iter];

                for (iter = 0; iter < Buffer_Send_nFaceFourNode; iter++)
                    Buffer_Receive_Faceiv[iter] =  Buffer_Send_Faceiv[iter];

                for (iter = 0; iter < Buffer_Send_nFaceFiveNode*5; iter++)
                    Buffer_Receive_FaceFiveNode[iter] =  Buffer_Send_FaceFiveNode[iter];

                for (iter = 0; iter < Buffer_Send_nFaceFiveNode; iter++)
                    Buffer_Receive_Facev[iter] =  Buffer_Send_Facev[iter];

                for (iter = 0; iter < Buffer_Send_nFaceSixNode*6; iter++)
                    Buffer_Receive_FaceSixNode[iter] =  Buffer_Send_FaceSixNode[iter];

                for (iter = 0; iter < Buffer_Send_nFaceSixNode; iter++)
                    Buffer_Receive_Facevi[iter] =  Buffer_Send_Facevi[iter];

                for (iter = 0; iter < Buffer_Send_nFaceSevenNode*7; iter++)
                    Buffer_Receive_FaceSevenNode[iter] =  Buffer_Send_FaceSevenNode[iter];

                for (iter = 0; iter < Buffer_Send_nFaceSevenNode; iter++)
                    Buffer_Receive_Facevii[iter] =  Buffer_Send_Facevii[iter];

                for (iter = 0; iter < Buffer_Send_nFaceEightNode*8; iter++)
                    Buffer_Receive_FaceEightNode[iter] =  Buffer_Send_FaceEightNode[iter];

                for (iter = 0; iter < Buffer_Send_nFaceEightNode; iter++)
                    Buffer_Receive_Faceviii[iter] =  Buffer_Send_Faceviii[iter];

                for (iter = 0; iter < Buffer_Send_nElemTotal*Buffer_Send_nDim; iter++)
                    Buffer_Receive_CGE[iter] = Buffer_Send_CGE[iter];

                for (iter = 0; iter < Buffer_Send_nElemTotal; iter++) {
                    Buffer_Receive_GlobalElemIndex[iter] = Buffer_Send_GlobalElemIndex[iter];
                    Buffer_Receive_Color[iter] = Buffer_Send_Color[iter];
                    Buffer_Receive_nNeighborFace[iter] = Buffer_Send_nNeighborFace[iter];
                    Buffer_Receive_nNeighborCell[iter] = Buffer_Send_nNeighborCell[iter];
                    Buffer_Receive_Volume[iter] = Buffer_Send_Volume[iter];
                }

                for (iter = 0; iter < Buffer_Send_nElemiiNeigh*2; iter++)
                    Buffer_Receive_ElemiiNeigh[iter] =  Buffer_Send_ElemiiNeigh[iter];

                for (iter = 0; iter < Buffer_Send_nElemiiNeigh; iter++)
                    Buffer_Receive_Elemii[iter] =  Buffer_Send_Elemii[iter];

                for (iter = 0; iter < Buffer_Send_nElemiiiNeigh*3; iter++)
                    Buffer_Receive_ElemiiiNeigh[iter] =  Buffer_Send_ElemiiiNeigh[iter];

                for (iter = 0; iter < Buffer_Send_nElemiiiNeigh; iter++)
                    Buffer_Receive_Elemiii[iter] =  Buffer_Send_Elemiii[iter];

                for (iter = 0; iter < Buffer_Send_nElemivNeigh*4; iter++)
                    Buffer_Receive_ElemivNeigh[iter] =  Buffer_Send_ElemivNeigh[iter];

                for (iter = 0; iter < Buffer_Send_nElemivNeigh; iter++)
                    Buffer_Receive_Elemiv[iter] =  Buffer_Send_Elemiv[iter];

                for (iter = 0; iter < Buffer_Send_nElemvNeigh*5; iter++)
                    Buffer_Receive_ElemvNeigh[iter] =  Buffer_Send_ElemvNeigh[iter];

                for (iter = 0; iter < Buffer_Send_nElemvNeigh; iter++)
                    Buffer_Receive_Elemv[iter] =  Buffer_Send_Elemv[iter];

                for (iter = 0; iter < Buffer_Send_nElemviNeigh*6; iter++)
                    Buffer_Receive_ElemviNeigh[iter] =  Buffer_Send_ElemviNeigh[iter];

                for (iter = 0; iter < Buffer_Send_nElemviNeigh; iter++)
                    Buffer_Receive_Elemvi[iter] =  Buffer_Send_Elemvi[iter];

                for (iter = 0; iter < Buffer_Send_nElemviiNeigh*7; iter++)
                    Buffer_Receive_ElemviiNeigh[iter] =  Buffer_Send_ElemviiNeigh[iter];

                for (iter = 0; iter < Buffer_Send_nElemviiNeigh; iter++)
                    Buffer_Receive_Elemvii[iter] =  Buffer_Send_Elemvii[iter];

                for (iter = 0; iter < Buffer_Send_nElemviiiNeigh*8; iter++)
                    Buffer_Receive_ElemviiiNeigh[iter] =  Buffer_Send_ElemviiiNeigh[iter];

                for (iter = 0; iter < Buffer_Send_nElemviiiNeigh; iter++)
                    Buffer_Receive_Elemviii[iter] =  Buffer_Send_Elemviii[iter];

                for (iter = 0; iter < Buffer_Send_nPointTotal*Buffer_Send_nDim; iter++)
                    Buffer_Receive_Coord[iter] = Buffer_Send_Coord[iter];

                for (iter = 0; iter < Buffer_Send_nPointTotal; iter++)
                    Buffer_Receive_GlobalPointIndex[iter] = Buffer_Send_GlobalPointIndex[iter];


                for (iter = 0; iter < Buffer_Send_nMarkerDomain; iter++){
                    Buffer_Receive_StartFace[iter] =  Buffer_Send_StartFace[iter];
                    Buffer_Receive_Local2Global_Marker[iter] =  Buffer_Send_Local2Global_Marker[iter];
                }

                for (iter = 0; iter < Buffer_Send_nVertexDomainTotal; iter++){
                    Buffer_Receive_Bound[iter] = Buffer_Send_Bound[iter];
                }
            }
            //PART10# the Buffer Receive vectors have been set, in the master node.//

            delete[] Buffer_Send_CGF;
            delete[] Buffer_Send_GlobalFaceIndex;
            delete[] Buffer_Send_nNeighborNode;
            delete[] Buffer_Send_FaceThreeNode;
            delete[] Buffer_Send_Faceiii;
            delete[] Buffer_Send_FaceFourNode;
            delete[] Buffer_Send_Faceiv;
            delete[] Buffer_Send_FaceFiveNode;
            delete[] Buffer_Send_Facev;
            delete[] Buffer_Send_FaceSixNode;
            delete[] Buffer_Send_Facevi;
            delete[] Buffer_Send_FaceSevenNode;
            delete[] Buffer_Send_Facevii;
            delete[] Buffer_Send_FaceEightNode;
            delete[] Buffer_Send_Faceviii;
            delete[] Buffer_Send_CGE;
            delete[] Buffer_Send_GlobalElemIndex;
            delete[] Buffer_Send_Color;
            delete[] Buffer_Send_nNeighborFace;
            delete[] Buffer_Send_nNeighborCell;
            delete[] Buffer_Send_ElemiiNeigh;
            delete[] Buffer_Send_Elemii;
            delete[] Buffer_Send_ElemiiiNeigh;
            delete[] Buffer_Send_Elemiii;
            delete[] Buffer_Send_ElemivNeigh;
            delete[] Buffer_Send_Elemiv;
            delete[] Buffer_Send_ElemvNeigh;
            delete[] Buffer_Send_Elemv;
            delete[] Buffer_Send_ElemviNeigh;
            delete[] Buffer_Send_Elemvi;
            delete[] Buffer_Send_ElemviiNeigh;
            delete[] Buffer_Send_Elemvii;
            delete[] Buffer_Send_ElemviiiNeigh;
            delete[] Buffer_Send_Elemviii;
            delete[] Buffer_Send_OwnerCell;
            delete[] Buffer_Send_NeighborCell;
            delete[] Buffer_Send_Coord;
            delete[] Buffer_Send_GlobalPointIndex;
            delete[] Buffer_Send_Volume;
            delete[] Buffer_Send_Normal;
            delete[] Buffer_Send_StartFace;
            delete[] Buffer_Send_Local2Global_Marker;
            delete[] Buffer_Send_Bound;

        }

        if (rank == iDomain) {

            if (rank != MASTER_NODE) {

#ifdef HAVE_MPI
                MPI_Irecv(Buffer_Receive_CGF,                   nFaceTotal*nDim,       MPI_DOUBLE,        MASTER_NODE, 0,   MPI_COMM_WORLD, &recv_req[0]);
                MPI_Irecv(Buffer_Receive_GlobalFaceIndex,       nFaceTotal,            MPI_UNSIGNED_LONG, MASTER_NODE, 1,   MPI_COMM_WORLD, &recv_req[1]);
                MPI_Irecv(Buffer_Receive_nNeighborNode,         nFaceTotal,            MPI_UNSIGNED_LONG, MASTER_NODE, 2,   MPI_COMM_WORLD, &recv_req[2]);
                MPI_Irecv(Buffer_Receive_FaceThreeNode,         nFaceThreeNode*3,      MPI_UNSIGNED_LONG, MASTER_NODE, 3,   MPI_COMM_WORLD, &recv_req[3]);
                MPI_Irecv(Buffer_Receive_Faceiii,               nFaceThreeNode,        MPI_UNSIGNED_LONG, MASTER_NODE, 4,   MPI_COMM_WORLD, &recv_req[4]);
                MPI_Irecv(Buffer_Receive_FaceFourNode,          nFaceFourNode*4,       MPI_UNSIGNED_LONG, MASTER_NODE, 5,   MPI_COMM_WORLD, &recv_req[5]);
                MPI_Irecv(Buffer_Receive_Faceiv,                nFaceFourNode,         MPI_UNSIGNED_LONG, MASTER_NODE, 6,   MPI_COMM_WORLD, &recv_req[6]);
                MPI_Irecv(Buffer_Receive_FaceFiveNode,          nFaceFiveNode*5,       MPI_UNSIGNED_LONG, MASTER_NODE, 7,   MPI_COMM_WORLD, &recv_req[7]);
                MPI_Irecv(Buffer_Receive_Facev,                 nFaceFiveNode,         MPI_UNSIGNED_LONG, MASTER_NODE, 8,   MPI_COMM_WORLD, &recv_req[8]);
                MPI_Irecv(Buffer_Receive_FaceSixNode,           nFaceSixNode*6,        MPI_UNSIGNED_LONG, MASTER_NODE, 9,   MPI_COMM_WORLD, &recv_req[9]);
                MPI_Irecv(Buffer_Receive_Facevi,                nFaceSixNode,          MPI_UNSIGNED_LONG, MASTER_NODE, 10,   MPI_COMM_WORLD, &recv_req[10]);
                MPI_Irecv(Buffer_Receive_FaceSevenNode,         nFaceSevenNode*7,      MPI_UNSIGNED_LONG, MASTER_NODE, 11,   MPI_COMM_WORLD, &recv_req[11]);
                MPI_Irecv(Buffer_Receive_Facevii,               nFaceSevenNode,        MPI_UNSIGNED_LONG, MASTER_NODE, 12,   MPI_COMM_WORLD, &recv_req[12]);
                MPI_Irecv(Buffer_Receive_FaceEightNode,         nFaceEightNode*8,      MPI_UNSIGNED_LONG, MASTER_NODE, 13,   MPI_COMM_WORLD, &recv_req[13]);
                MPI_Irecv(Buffer_Receive_Faceviii,              nFaceEightNode,        MPI_UNSIGNED_LONG, MASTER_NODE, 14,   MPI_COMM_WORLD, &recv_req[14]);
                MPI_Irecv(Buffer_Receive_CGE,                   nElemTotal*nDim,       MPI_DOUBLE,        MASTER_NODE, 15,   MPI_COMM_WORLD, &recv_req[15]);
                MPI_Irecv(Buffer_Receive_GlobalElemIndex,       nElemTotal,            MPI_UNSIGNED_LONG, MASTER_NODE, 16,   MPI_COMM_WORLD, &recv_req[16]);
                MPI_Irecv(Buffer_Receive_Color,                 nElemTotal,            MPI_UNSIGNED_LONG, MASTER_NODE, 17,   MPI_COMM_WORLD, &recv_req[17]);
                MPI_Irecv(Buffer_Receive_nNeighborFace,         nElemTotal,            MPI_UNSIGNED_LONG, MASTER_NODE, 18,  MPI_COMM_WORLD, &recv_req[18]);
                MPI_Irecv(Buffer_Receive_nNeighborCell,         nElemTotal,            MPI_UNSIGNED_LONG, MASTER_NODE, 19,  MPI_COMM_WORLD, &recv_req[19]);
                MPI_Irecv(Buffer_Receive_ElemiiNeigh,           nElemiiNeigh*2,        MPI_LONG, MASTER_NODE, 20,           MPI_COMM_WORLD, &recv_req[20]);
                MPI_Irecv(Buffer_Receive_Elemii,                nElemiiNeigh,          MPI_UNSIGNED_LONG, MASTER_NODE, 21,  MPI_COMM_WORLD, &recv_req[21]);
                MPI_Irecv(Buffer_Receive_ElemiiiNeigh,          nElemiiiNeigh*3,       MPI_LONG, MASTER_NODE, 22,           MPI_COMM_WORLD, &recv_req[22]);
                MPI_Irecv(Buffer_Receive_Elemiii,               nElemiiiNeigh,         MPI_UNSIGNED_LONG, MASTER_NODE, 23,  MPI_COMM_WORLD, &recv_req[23]);
                MPI_Irecv(Buffer_Receive_ElemivNeigh,           nElemivNeigh*4,        MPI_LONG, MASTER_NODE, 24,           MPI_COMM_WORLD, &recv_req[24]);
                MPI_Irecv(Buffer_Receive_Elemiv,                nElemivNeigh,          MPI_UNSIGNED_LONG, MASTER_NODE, 25,  MPI_COMM_WORLD, &recv_req[25]);
                MPI_Irecv(Buffer_Receive_ElemvNeigh,            nElemvNeigh*5,         MPI_LONG, MASTER_NODE, 26,           MPI_COMM_WORLD, &recv_req[26]);
                MPI_Irecv(Buffer_Receive_Elemv,                 nElemvNeigh,           MPI_UNSIGNED_LONG, MASTER_NODE, 27,  MPI_COMM_WORLD, &recv_req[27]);
                MPI_Irecv(Buffer_Receive_ElemviNeigh,           nElemviNeigh*6,        MPI_LONG, MASTER_NODE, 28,           MPI_COMM_WORLD, &recv_req[28]);
                MPI_Irecv(Buffer_Receive_Elemvi,                nElemviNeigh,          MPI_UNSIGNED_LONG, MASTER_NODE, 29,  MPI_COMM_WORLD, &recv_req[29]);
                MPI_Irecv(Buffer_Receive_ElemviiNeigh,          nElemviiNeigh*7,       MPI_LONG, MASTER_NODE, 30,           MPI_COMM_WORLD, &recv_req[30]);
                MPI_Irecv(Buffer_Receive_Elemvii,               nElemviiNeigh,         MPI_UNSIGNED_LONG, MASTER_NODE, 31,  MPI_COMM_WORLD, &recv_req[31]);
                MPI_Irecv(Buffer_Receive_ElemviiiNeigh,         nElemviiiNeigh*8,      MPI_LONG, MASTER_NODE, 32,           MPI_COMM_WORLD, &recv_req[32]);
                MPI_Irecv(Buffer_Receive_Elemviii,              nElemviiiNeigh,        MPI_UNSIGNED_LONG, MASTER_NODE, 33,  MPI_COMM_WORLD, &recv_req[33]);
                MPI_Irecv(Buffer_Receive_OwnerCell,             nFaceTotal,            MPI_UNSIGNED_LONG, MASTER_NODE, 34,  MPI_COMM_WORLD, &recv_req[34]);
                MPI_Irecv(Buffer_Receive_NeighborCell,          nFaceTotal,            MPI_UNSIGNED_LONG, MASTER_NODE, 35,  MPI_COMM_WORLD, &recv_req[35]);
                MPI_Irecv(Buffer_Receive_Coord,                 nPointTotal*nDim,      MPI_DOUBLE,        MASTER_NODE, 36,  MPI_COMM_WORLD, &recv_req[36]);
                MPI_Irecv(Buffer_Receive_GlobalPointIndex,      nPointTotal,           MPI_UNSIGNED_LONG, MASTER_NODE, 37,  MPI_COMM_WORLD, &recv_req[37]);
                MPI_Irecv(Buffer_Receive_Volume,                nElemTotal,            MPI_DOUBLE, MASTER_NODE, 38,         MPI_COMM_WORLD, &recv_req[38]);
                MPI_Irecv(Buffer_Receive_Normal,                nFaceTotal*nDim,       MPI_DOUBLE, MASTER_NODE, 39,         MPI_COMM_WORLD, &recv_req[39]);
                MPI_Irecv(Buffer_Receive_StartFace,             nMarkerDomain,         MPI_LONG, MASTER_NODE, 40,           MPI_COMM_WORLD, &recv_req[40]);
                MPI_Irecv(Buffer_Receive_Local2Global_Marker,   nMarkerDomain,         MPI_UNSIGNED_LONG, MASTER_NODE, 41,  MPI_COMM_WORLD, &recv_req[41]);
                MPI_Irecv(Buffer_Receive_Bound,                 nVertexDomainTotal,    MPI_UNSIGNED_LONG, MASTER_NODE, 42,  MPI_COMM_WORLD, &recv_req[42]);

                /*--- Wait for this set of non-blocking recv's to complete ---*/

                MPI_Waitall(43, recv_req, recv_stat);

#endif

                //PART11# the ranks other than master node have received the information about the Receive Buffers.//
            }
            nFace = nFaceTotal;
            face = new CPrimalGrid*[nFace];
            Local_to_Global_Face = new unsigned long[nFace];
            for(iFace = 0; iFace < nFace; iFace++){
                Local_to_Global_Face[iFace] = Buffer_Receive_GlobalFaceIndex[iFace];
                face[iFace] = new CFace(Buffer_Receive_nNeighborNode[iFace], Local_to_Global_Face[iFace]);
                face[iFace]->SetnNodes_Face(Buffer_Receive_nNeighborNode[iFace]);
                face[iFace]->SetElems(0, Buffer_Receive_OwnerCell[iFace]);
                face[iFace]->SetGlobalIndex(Buffer_Receive_GlobalFaceIndex[iFace]);
                if(Buffer_Receive_NeighborCell[iFace] != -1)
                    face[iFace]->SetElems(1, Buffer_Receive_NeighborCell[iFace]);
                else face[iFace]->SetElems(1, -1);

                for(iDim = 0; iDim < nDim; iDim++){
                    face[iFace]->SetCG(iDim, Buffer_Receive_CGF[iFace*nDim+iDim]);
                    face[iFace]->SetNormal_Face(iDim, Buffer_Receive_Normal[iFace*nDim+iDim]);
                }
            }

            for(iFaceThreeNode = 0; iFaceThreeNode < nFaceThreeNode; iFaceThreeNode++){
                for(iNode = 0; iNode < 3; iNode++){
                    face[Buffer_Receive_Faceiii[iFaceThreeNode]]->SetNode_Face(iNode, Buffer_Receive_FaceThreeNode[iFaceThreeNode*3+iNode]);
                }
            }

            for(iFaceFourNode = 0; iFaceFourNode < nFaceFourNode; iFaceFourNode++){
                for(iNode = 0; iNode < 4; iNode++){
                    face[Buffer_Receive_Faceiv[iFaceFourNode]]->SetNode_Face(iNode, Buffer_Receive_FaceFourNode[iFaceFourNode*4+iNode]);
                }
            }

            for(iFaceFiveNode = 0; iFaceFiveNode < nFaceFiveNode; iFaceFiveNode++){
                for(iNode = 0; iNode < 5; iNode++){
                    face[Buffer_Receive_Facev[iFaceFiveNode]]->SetNode_Face(iNode, Buffer_Receive_FaceFiveNode[iFaceFiveNode*5+iNode]);
                }
            }

            for(iFaceSixNode = 0; iFaceSixNode < nFaceSixNode; iFaceSixNode++){
                for(iNode = 0; iNode < 6; iNode++){
                    face[Buffer_Receive_Facevi[iFaceSixNode]]->SetNode_Face(iNode, Buffer_Receive_FaceSixNode[iFaceSixNode*6+iNode]);
                }
            }

            for(iFaceSevenNode = 0; iFaceSevenNode < nFaceSevenNode; iFaceSevenNode++){
                for(iNode = 0; iNode < 7; iNode++){
                    face[Buffer_Receive_Facevii[iFaceSevenNode]]->SetNode_Face(iNode, Buffer_Receive_FaceSevenNode[iFaceSevenNode*7+iNode]);
                }
            }

            for(iFaceEightNode = 0; iFaceEightNode < nFaceEightNode; iFaceEightNode++){
                for(iNode = 0; iNode < 8; iNode++){
                    face[Buffer_Receive_Faceviii[iFaceEightNode]]->SetNode_Face(iNode, Buffer_Receive_FaceEightNode[iFaceEightNode*8+iNode]);
                }
            }


            delete[] Buffer_Receive_CGF;
            delete[] Buffer_Receive_GlobalFaceIndex;
            delete[] Buffer_Receive_nNeighborNode;
            delete[] Buffer_Receive_FaceThreeNode;
            delete[] Buffer_Receive_Faceiii;
            delete[] Buffer_Receive_FaceFourNode;
            delete[] Buffer_Receive_Faceiv;
            delete[] Buffer_Receive_FaceFiveNode;
            delete[] Buffer_Receive_Facev;
            delete[] Buffer_Receive_FaceSixNode;
            delete[] Buffer_Receive_Facevi;
            delete[] Buffer_Receive_FaceSevenNode;
            delete[] Buffer_Receive_Facevii;
            delete[] Buffer_Receive_FaceEightNode;
            delete[] Buffer_Receive_Faceviii;

            //PART12# in each rank, the face is allocated in CFace and its belonging nodes and also owner and neighbor cells are stored by its Received Buffers.//

            nElem = nElemTotal;
            nElemDomain = nElemDomainTotal;
            elem = new CPrimalGrid*[nElem];
            Local_to_Global_Elem = new unsigned long[nElem];
            for(iElem = 0; iElem < nElem; iElem++){
                Local_to_Global_Elem[iElem] = Buffer_Receive_GlobalElemIndex[iElem];
                elem[iElem] = new CElement(Buffer_Receive_nNeighborFace[iElem], Local_to_Global_Elem[iElem]);
                elem[iElem]->SetColor(Buffer_Receive_Color[iElem]);
                elem[iElem]->SetnNeighbor_Face(Buffer_Receive_nNeighborFace[iElem]);
                elem[iElem]->SetnNeighbor_Cell(Buffer_Receive_nNeighborCell[iElem]);
                elem[iElem]->SetVolume(Buffer_Receive_Volume[iElem]);
                elem[iElem]->SetGlobalIndex(Buffer_Receive_GlobalElemIndex[iElem]);
                for(iDim = 0; iDim < nDim; iDim++){
                    elem[iElem]->SetCG(iDim, Buffer_Receive_CGE[iElem*nDim+iDim]);
                }
            }

            for(iElemiiNeigh = 0; iElemiiNeigh < nElemiiNeigh; iElemiiNeigh++){
                for(kFace = 0; kFace < 2; kFace++){
                    if(Buffer_Receive_ElemiiNeigh[iElemiiNeigh*2+kFace] != -1)
                        elem[Buffer_Receive_Elemii[iElemiiNeigh]]->SetNeighbor_Cell(Buffer_Receive_ElemiiNeigh[iElemiiNeigh*2+kFace], kFace);

                    else elem[Buffer_Receive_Elemii[iElemiiNeigh]]->SetNeighbor_Cell(-1, kFace);
                }
            }

            for(iElemiiiNeigh = 0; iElemiiiNeigh < nElemiiiNeigh; iElemiiiNeigh++){
                for(kFace = 0; kFace < 3; kFace++){
                    if(Buffer_Receive_ElemiiiNeigh[iElemiiiNeigh*3+kFace] != -1)
                        elem[Buffer_Receive_Elemiii[iElemiiiNeigh]]->SetNeighbor_Cell(Buffer_Receive_ElemiiiNeigh[iElemiiiNeigh*3+kFace], kFace);

                    else elem[Buffer_Receive_Elemiii[iElemiiiNeigh]]->SetNeighbor_Cell(-1, kFace);
                }
            }

            for(iElemivNeigh = 0; iElemivNeigh < nElemivNeigh; iElemivNeigh++){
                for(kFace = 0; kFace < 4; kFace++){
                    if(Buffer_Receive_ElemivNeigh[iElemivNeigh*4+kFace] != -1)
                        elem[Buffer_Receive_Elemiv[iElemivNeigh]]->SetNeighbor_Cell(Buffer_Receive_ElemivNeigh[iElemivNeigh*4+kFace], kFace);

                    else elem[Buffer_Receive_Elemiv[iElemivNeigh]]->SetNeighbor_Cell(-1, kFace);

                }
            }

            for(iElemvNeigh = 0; iElemvNeigh < nElemvNeigh; iElemvNeigh++){
                for(kFace = 0; kFace < 5; kFace++){
                    if(Buffer_Receive_ElemvNeigh[iElemvNeigh*5+kFace] != -1)
                        elem[Buffer_Receive_Elemv[iElemvNeigh]]->SetNeighbor_Cell(Buffer_Receive_ElemvNeigh[iElemvNeigh*5+kFace], kFace);

                    else elem[Buffer_Receive_Elemv[iElemvNeigh]]->SetNeighbor_Cell(-1, kFace);

                }
            }

            for(iElemviNeigh = 0; iElemviNeigh < nElemviNeigh; iElemviNeigh++){
                for(kFace = 0; kFace < 6; kFace++){
                    if(Buffer_Receive_ElemviNeigh[iElemviNeigh*6+kFace] != -1)
                        elem[Buffer_Receive_Elemvi[iElemviNeigh]]->SetNeighbor_Cell(Buffer_Receive_ElemviNeigh[iElemviNeigh*6+kFace], kFace);

                    else elem[Buffer_Receive_Elemvi[iElemviNeigh]]->SetNeighbor_Cell(-1, kFace);

                }
            }

            for(iElemviiNeigh = 0; iElemviiNeigh < nElemviiNeigh; iElemviiNeigh++){
                for(kFace = 0; kFace < 7; kFace++){
                    if(Buffer_Receive_ElemviiNeigh[iElemviiNeigh*7+kFace] != -1)
                        elem[Buffer_Receive_Elemvii[iElemviiNeigh]]->SetNeighbor_Cell(Buffer_Receive_ElemviiNeigh[iElemviiNeigh*7+kFace], kFace);

                    else elem[Buffer_Receive_Elemvii[iElemviiNeigh]]->SetNeighbor_Cell(-1, kFace);

                }
            }

            for(iElemviiiNeigh = 0; iElemviiiNeigh < nElemviiiNeigh; iElemviiiNeigh++){
                for(kFace = 0; kFace < 8; kFace++){
                    if(Buffer_Receive_ElemviiiNeigh[iElemviiiNeigh*8+kFace] != -1)
                        elem[Buffer_Receive_Elemviii[iElemviiiNeigh]]->SetNeighbor_Cell(Buffer_Receive_ElemviiiNeigh[iElemviiiNeigh*8+kFace], kFace);

                    else elem[Buffer_Receive_Elemviii[iElemviiiNeigh]]->SetNeighbor_Cell(-1, kFace);

                }
            }

            //PART13# in each rank, the element is allocated in CElement and its belonging faces and also its color and global index are stored by its Received Buffers.//

            delete[] Buffer_Receive_CGE;
            delete[] Buffer_Receive_GlobalElemIndex;
            delete[] Buffer_Receive_Color;
            delete[] Buffer_Receive_nNeighborFace;
            delete[] Buffer_Receive_nNeighborCell;
            delete[] Buffer_Receive_ElemiiNeigh;
            delete[] Buffer_Receive_Elemii;
            delete[] Buffer_Receive_ElemiiiNeigh;
            delete[] Buffer_Receive_Elemiii;
            delete[] Buffer_Receive_ElemivNeigh;
            delete[] Buffer_Receive_Elemiv;
            delete[] Buffer_Receive_ElemvNeigh;
            delete[] Buffer_Receive_Elemv;
            delete[] Buffer_Receive_ElemviNeigh;
            delete[] Buffer_Receive_Elemvi;
            delete[] Buffer_Receive_ElemviiNeigh;
            delete[] Buffer_Receive_Elemvii;
            delete[] Buffer_Receive_ElemviiiNeigh;
            delete[] Buffer_Receive_Elemviii;
            delete[] Buffer_Receive_OwnerCell;
            delete[] Buffer_Receive_NeighborCell;
            delete[] Buffer_Receive_Volume;
            delete [] Buffer_Receive_Normal;

            nPoint = nPointTotal;
            node = new CPoint*[nPoint];
            Local_to_Global_Point = new unsigned long[nPoint];
            for(iPoint = 0; iPoint < nPoint; iPoint++){
                Local_to_Global_Point[iPoint] = Buffer_Receive_GlobalPointIndex[iPoint];
                node[iPoint] = new CPoint(Buffer_Receive_Coord[iPoint*nDim+0], Buffer_Receive_Coord[iPoint*nDim+1], Buffer_Receive_Coord[iPoint*nDim+2], Local_to_Global_Point[iPoint], config);
                node[iPoint]->SetGlobalIndex(Buffer_Receive_GlobalPointIndex[iPoint]);
            }

            //PART14# in each rank, the node is allocated in CPoint and also its global index are stored by its Received Buffers.//

            delete[] Buffer_Receive_Coord;
            delete[] Buffer_Receive_GlobalPointIndex;

            nMarker = nMarkerDomain;
            nElem_Bound = new unsigned long [nMarker_Max];
            Start_Face = new unsigned long [nMarker_Max];
            Local_to_Global_Marker = new unsigned short [nMarker_Max];
            Tag_to_Marker = new string [nMarker_Max];
            string *TagBound_Copy = new string [nMarker_Max];
            short *SendRecv_Copy = new short [nMarker_Max];

            for (iMarker = 0; iMarker < nMarker; iMarker++) nElem_Bound[iMarker] = nVertexDomain[iMarker];

            bound = new CPrimalGrid**[nMarker+(overhead*nDomain)];
            for (iMarker = 0; iMarker < nMarker; iMarker++) bound[iMarker] = new CPrimalGrid* [nElem_Bound[iMarker]];

            iVertexDomainTotal = 0;
            for (iMarker = 0; iMarker < nMarker; iMarker++) {
                iVertexDomain = 0;

                for(iElem_Bound = 0; iElem_Bound < nElem_Bound[iMarker]; iElem_Bound++){
                    bound[iMarker][iVertexDomain] = new CFace(face[Buffer_Receive_Bound[iVertexDomainTotal]]->GetnNodes_Face(),
                            Local_to_Global_Face[Buffer_Receive_Bound[iVertexDomainTotal]]);
                    bound[iMarker][iVertexDomain]->SetGlobalFace(Buffer_Receive_Bound[iVertexDomainTotal]);
                    iVertexDomain++;
                    iVertexDomainTotal++;
                }

                Local_to_Global_Marker[iMarker] = Buffer_Receive_Local2Global_Marker[iMarker];
                string Grid_Marker = config->GetMarker_All_TagBound(Local_to_Global_Marker[iMarker]);
                short SendRecv = config->GetMarker_All_SendRecv(Local_to_Global_Marker[iMarker]);
                TagBound_Copy[iMarker] = Grid_Marker;
                SendRecv_Copy[iMarker] = SendRecv;
            }

            for (iMarker = 0; iMarker < nMarker; iMarker++) {
                config->SetMarker_All_TagBound(iMarker, TagBound_Copy[iMarker]);
                config->SetMarker_All_SendRecv(iMarker, SendRecv_Copy[iMarker]);
            }

            //PART15# the boundary elements are allocated in CBound and the global! index are stored by its received buffers.//
            delete[] Buffer_Receive_StartFace;
            delete[] Buffer_Receive_Local2Global_Marker;
            delete[] Buffer_Receive_Bound;
            delete[] TagBound_Copy;
            delete[] SendRecv_Copy;

        }

    }
    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        config->SetMarker_All_SendRecv(iMarker, Marker_All_SendRecv[iMarker]);
    }

    unsigned long Local_nFace = nFace;
    unsigned long Local_nElem = nElem;
    unsigned long Local_nElemDomain = nElemDomain;
    unsigned long Local_nPoint = nPoint;


#ifdef HAVE_MPI

    MPI_Allreduce(&Local_nFace, &Global_nFace, 1, MPI_UNSIGNED_LONG, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&Local_nElem, &Global_nElem, 1, MPI_UNSIGNED_LONG, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&Local_nElemDomain, &Global_nElemDomain, 1, MPI_UNSIGNED_LONG, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&Local_nPoint, &Global_nPoint, 1, MPI_UNSIGNED_LONG, MPI_SUM, MPI_COMM_WORLD);

#else
    Global_nFace = Local_nFace;
    Global_nElem = Local_nElem;
    Global_nElemDomain = Local_nElemDomain;
    Global_nPoint = Local_nPoint;

#endif

    if (rank == MASTER_NODE) {

        delete [] Global_to_Local_Elem;
        delete [] Global_to_Local_Face;
        delete [] Global_to_Local_Point;
        delete [] Global_to_Local_Neigh;
        delete [] MarkerIn;
        delete [] nFace_Color;
        delete [] Marker_All_SendRecv_Copy;
        delete [] Marker_All_TagBound_Copy;

        for (iDomain = 0; iDomain < nDomain; iDomain++) {
            delete[] Face_Color[iDomain];
        }
        delete[] Face_Color;
    }

    delete [] nVertexDomain;
    delete [] Buffer_Send_nVertexDomain;
    delete [] Buffer_Send_Marker_All_SendRecv;
    delete [] Marker_All_TagBound;
    delete [] Buffer_Send_Marker_All_TagBound;

    cout<<rank<<"...CPhyicalGeometry is Accomplished! "<<nElem<<endl;

}
/*---By Mahtab---*/

CPhysicalGeometry::~CPhysicalGeometry(void) {


    if (Local_to_Global_Point != NULL) delete[] Local_to_Global_Point;
    if (Local_to_Global_Marker != NULL) delete[] Local_to_Global_Marker;
    if (Local_to_Global_Face != NULL) delete[] Local_to_Global_Face;
    if (Local_to_Global_Elem != NULL) delete[] Local_to_Global_Elem;
}


void CPhysicalGeometry::SetSendReceive(CConfig *config) {

    unsigned short Counter_Send, Counter_Receive, iMarkerSend, iMarkerReceive;
    unsigned long iVertex, LocalNode;

    unsigned long  i, j, iFace, iElem, jElem;
    unsigned short nDomain, iDomain, jDomain;
    vector<unsigned long>::iterator it;

    vector<vector<unsigned long> > SendDomainLocal; /*!< \brief SendDomain[from domain][to domain] and return the point index of the node that must me sended. */
    vector<vector<unsigned long> > ReceivedDomainLocal; /*!< \brief SendDomain[from domain][to domain] and return the point index of the node that must me sended. */

    unsigned short nMarker_Max = config->GetnMarker_Max();
    unsigned long *nVertexDomain = new unsigned long[nMarker_Max];

    int rank = MASTER_NODE;
    int size = SINGLE_NODE;

#ifdef HAVE_MPI
    MPI_Comm_size(MPI_COMM_WORLD,&size);
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
#endif

    nDomain = size;

    SendDomainLocal.resize(nDomain);
    ReceivedDomainLocal.resize(nDomain);

    for (iFace = 0; iFace < nFace; iFace++) {
        for (i = 0; i < 2; i++) {
            if(face[iFace]->GetElems(i) != -1){
                iElem = face[iFace]->GetElems(i);
                iDomain = elem[iElem]->GetColor();

                if (iDomain == rank) {
                    for(j = 0; j < elem[iElem]->GetnNeighbor_Cell(); j++) {
                        if(elem[iElem]->GetNeighbor_Cell(j) != -1){
                            jElem = elem[iElem]->GetNeighbor_Cell(j);
                            jDomain = elem[jElem]->GetColor();

                            if (iDomain != jDomain) {
                                SendDomainLocal[jDomain].push_back(Local_to_Global_Elem[iElem]);
                                ReceivedDomainLocal[jDomain].push_back(Local_to_Global_Elem[jElem]);
                            }
                        }
                    }
                }
            }
        }
    }


    for (iDomain = 0; iDomain < nDomain; iDomain++) {
        sort( SendDomainLocal[iDomain].begin(), SendDomainLocal[iDomain].end());
        it = unique( SendDomainLocal[iDomain].begin(), SendDomainLocal[iDomain].end());
        SendDomainLocal[iDomain].resize( it - SendDomainLocal[iDomain].begin() );
    }

    for (iDomain = 0; iDomain < nDomain; iDomain++) {
        sort( ReceivedDomainLocal[iDomain].begin(), ReceivedDomainLocal[iDomain].end());
        it = unique( ReceivedDomainLocal[iDomain].begin(), ReceivedDomainLocal[iDomain].end());
        ReceivedDomainLocal[iDomain].resize( it - ReceivedDomainLocal[iDomain].begin() );
    }

    Max_GlobalPoint = 0;
    for (iElem = 0; iElem < nElem; iElem++) {
        if (Local_to_Global_Elem[iElem] > Max_GlobalPoint)
            Max_GlobalPoint = Local_to_Global_Elem[iElem];
    }
    Global_to_Local_Elem =  new long[Max_GlobalPoint+1]; // +1 to include the bigger point.

    for (iElem = 0; iElem < Max_GlobalPoint+1; iElem++)
        Global_to_Local_Elem[iElem] = -1;

    for (iElem = 0; iElem < nElem; iElem++)
        Global_to_Local_Elem[Local_to_Global_Elem[iElem]] = iElem;

    for (iDomain = 0; iDomain < nDomain; iDomain++) {
        if (SendDomainLocal[iDomain].size() != 0) {
            nVertexDomain[nMarker] = SendDomainLocal[iDomain].size();
            for (iVertex = 0; iVertex < nVertexDomain[nMarker]; iVertex++) {
                SendDomainLocal[iDomain][iVertex] = Global_to_Local_Elem[SendDomainLocal[iDomain][iVertex]];
            }
            config->SetMarker_All_TagBound(nMarker, "SEND_RECEIVE");
            nElem_Bound[nMarker] = nVertexDomain[nMarker];
            bound[nMarker] = new CPrimalGrid*[nElem_Bound[nMarker]];
            nMarker++;
        }
    }

    for (iDomain = 0; iDomain < nDomain; iDomain++) {
        if (ReceivedDomainLocal[iDomain].size() != 0) {
            nVertexDomain[nMarker] = ReceivedDomainLocal[iDomain].size();
            for (iVertex = 0; iVertex < nVertexDomain[nMarker]; iVertex++) {
                ReceivedDomainLocal[iDomain][iVertex] = Global_to_Local_Elem[ReceivedDomainLocal[iDomain][iVertex]];
            }
            config->SetMarker_All_TagBound(nMarker, "SEND_RECEIVE");

            nElem_Bound[nMarker] = nVertexDomain[nMarker];
            bound[nMarker] = new CPrimalGrid*[nElem_Bound[nMarker]];
            nMarker++;
        }
    }

    Counter_Send = 0; 	Counter_Receive = 0;
    for (iDomain = 0; iDomain < nDomain; iDomain++)
        if (SendDomainLocal[iDomain].size() != 0) Counter_Send++;

    for (iDomain = 0; iDomain < nDomain; iDomain++)
        if (ReceivedDomainLocal[iDomain].size() != 0) Counter_Receive++;

    iMarkerSend = nMarker - Counter_Send - Counter_Receive;
    iMarkerReceive = nMarker - Counter_Receive;

    for (iDomain = 0; iDomain < nDomain; iDomain++) {
        if (SendDomainLocal[iDomain].size() != 0) {
            for (iVertex = 0; iVertex < GetnElem_Bound(iMarkerSend); iVertex++) {
                LocalNode = SendDomainLocal[iDomain][iVertex];
                bound[iMarkerSend][iVertex] = new CVertexMPI(LocalNode, nDim);
                bound[iMarkerSend][iVertex]->SetBound_Element(LocalNode);
            }
            Marker_All_SendRecv[iMarkerSend] = iDomain+1;
            iMarkerSend++;
        }
    }

    for (iDomain = 0; iDomain < nDomain; iDomain++) {
        if (ReceivedDomainLocal[iDomain].size() != 0) {
            for (iVertex = 0; iVertex < GetnElem_Bound(iMarkerReceive); iVertex++) {
                LocalNode = ReceivedDomainLocal[iDomain][iVertex];
                bound[iMarkerReceive][iVertex] = new CVertexMPI(LocalNode, nDim);
                bound[iMarkerReceive][iVertex]->SetBound_Element(LocalNode);
            }
            Marker_All_SendRecv[iMarkerReceive] = -(iDomain+1);
            iMarkerReceive++;
        }
    }

    delete [] nVertexDomain;

    cout<<"............SET SEND RECEIVE............................."<<rank<<endl;

}


void CPhysicalGeometry::SetBoundaries(CConfig *config) {

    unsigned long iFace, iElem, iElem_Bound, TotalElem, *nElem_Bound_Copy, iVertex_;
    unsigned short iDomain, nDomain, iMarkersDomain, iLoop, *DomainCount, nMarker_Physical, Duplicate_SendReceive, *DomainSendCount, **DomainSendMarkers, *DomainReceiveCount, **DomainReceiveMarkers, nMarker_SendRecv, iMarker, iMarker_;
    CPrimalGrid*** bound_Copy;
    short *Marker_All_SendRecv_Copy;
    bool CheckStart;
    string Marker_Tag;

    int size = SINGLE_NODE;
    int rank = MASTER_NODE;
#ifdef HAVE_MPI
    MPI_Comm_size(MPI_COMM_WORLD,&size);
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);

#endif


    nDomain = size+1;

    nMarker_Physical = 0;
    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        Marker_Tag = config->GetMarker_All_TagBound(iMarker);
        if (Marker_Tag != "SEND_RECEIVE") {
            nMarker_Physical++;
        }
    }

    Duplicate_SendReceive = 0;
    for (iLoop = 0; iLoop < 2; iLoop++) {

        DomainCount = new unsigned short [nDomain];

        for (iDomain = 0; iDomain < nDomain; iDomain++)
            DomainCount[iDomain] = 0;

        if (iLoop == 0) {
            for (iDomain = 0; iDomain < nDomain; iDomain++)
                for (iMarker = 0; iMarker < nMarker; iMarker++){
                    Marker_Tag = config->GetMarker_All_TagBound(iMarker);
                    if (Marker_Tag == "SEND_RECEIVE")
                        if (Marker_All_SendRecv[iMarker] == iDomain) DomainCount[iDomain]++;
                }
        }
        else {
            for (iDomain = 0; iDomain < nDomain; iDomain++)
                for (iMarker = 0; iMarker < nMarker; iMarker++){
                    Marker_Tag = config->GetMarker_All_TagBound(iMarker);
                    if (Marker_Tag == "SEND_RECEIVE")
                        if (Marker_All_SendRecv[iMarker] == -iDomain) DomainCount[iDomain]++;
                }
        }

        for (iDomain = 0; iDomain < nDomain; iDomain++)
            if (DomainCount[iDomain] > 1) Duplicate_SendReceive++;

        delete [] DomainCount;
    }

    DomainSendCount = new unsigned short [nDomain];
    DomainSendMarkers = new unsigned short *[nDomain];
    DomainReceiveCount = new unsigned short [nDomain];
    DomainReceiveMarkers = new unsigned short *[nDomain];

    for (iDomain = 0; iDomain < nDomain; iDomain++) {
        DomainSendCount[iDomain] = 0;
        DomainSendMarkers[iDomain] = new unsigned short [nMarker];

        DomainReceiveCount[iDomain] = 0;
        DomainReceiveMarkers[iDomain] = new unsigned short [nMarker];
    }

    for (iDomain = 0; iDomain < nDomain; iDomain++) {
        for (iMarker = 0; iMarker < nMarker; iMarker++) {
            Marker_Tag = config->GetMarker_All_TagBound(iMarker);
            if (Marker_Tag == "SEND_RECEIVE") {
                if (Marker_All_SendRecv[iMarker] == iDomain) {
                    DomainSendMarkers[iDomain][DomainSendCount[iDomain]] = iMarker;
                    DomainSendCount[iDomain]++;
                }
                if (Marker_All_SendRecv[iMarker] == -iDomain) {
                    DomainReceiveMarkers[iDomain][DomainReceiveCount[iDomain]] = iMarker;
                    DomainReceiveCount[iDomain]++;
                }
            }
        }
    }



    nMarker_SendRecv = nMarker - nMarker_Physical - Duplicate_SendReceive;
    bound_Copy = new CPrimalGrid**[nMarker_Physical + nMarker_SendRecv];
    nElem_Bound_Copy = new unsigned long [nMarker_Physical + nMarker_SendRecv];
    Marker_All_SendRecv_Copy = new short [nMarker_Physical + nMarker_SendRecv];
    iMarker_ = nMarker_Physical;
    iVertex_ = 0;
    CheckStart = false;

    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        Marker_Tag = config->GetMarker_All_TagBound(iMarker);
        if (Marker_Tag != "SEND_RECEIVE") {
            nElem_Bound_Copy[iMarker] = nElem_Bound[iMarker];
            bound_Copy[iMarker] = new CPrimalGrid* [nElem_Bound[iMarker]];
            for (iElem_Bound = 0; iElem_Bound < nElem_Bound[iMarker]; iElem_Bound++) {
                iFace = bound[iMarker][iElem_Bound]->GetGlobalFace();
                bound_Copy[iMarker][iElem_Bound] = new CFace(face[iFace]->GetnNodes_Face(), face[iFace]->GetGlobalIndex());
                bound_Copy[iMarker][iElem_Bound]->SetGlobalFace(iFace);
            }
        }
    }

    for (iDomain = 0; iDomain < nDomain; iDomain++) {

        if (DomainSendCount[iDomain] != 0) {
            TotalElem = 0;
            for (iMarkersDomain = 0; iMarkersDomain < DomainSendCount[iDomain]; iMarkersDomain++) {
                iMarker = DomainSendMarkers[iDomain][iMarkersDomain];
                TotalElem += nElem_Bound[iMarker];
            }
            if (CheckStart) iMarker_++;
            CheckStart = true;
            iVertex_ = 0;
            nElem_Bound_Copy[iMarker_] = TotalElem;
            bound_Copy[iMarker_] = new CPrimalGrid*[TotalElem];
        }

        for (iMarkersDomain = 0; iMarkersDomain < DomainSendCount[iDomain]; iMarkersDomain++) {
            iMarker = DomainSendMarkers[iDomain][iMarkersDomain];
            Marker_All_SendRecv_Copy[iMarker_] = Marker_All_SendRecv[iMarker];
            for (iElem_Bound = 0; iElem_Bound < nElem_Bound[iMarker]; iElem_Bound++) {
                iElem = bound[iMarker][iElem_Bound]->GetBound_Element();
                bound_Copy[iMarker_][iVertex_] = new CVertexMPI(iElem, nDim);
                bound_Copy[iMarker_][iVertex_]->SetBound_Element(iElem);
                iVertex_++;
            }
        }

        if (DomainReceiveCount[iDomain] != 0) {
            TotalElem = 0;
            for (iMarkersDomain = 0; iMarkersDomain < DomainReceiveCount[iDomain]; iMarkersDomain++) {
                iMarker = DomainReceiveMarkers[iDomain][iMarkersDomain];
                TotalElem += nElem_Bound[iMarker];
            }
            if (CheckStart) iMarker_++;
            CheckStart = true;
            iVertex_ = 0;
            nElem_Bound_Copy[iMarker_] = TotalElem;
            bound_Copy[iMarker_] = new CPrimalGrid*[TotalElem];
        }

        for (iMarkersDomain = 0; iMarkersDomain < DomainReceiveCount[iDomain]; iMarkersDomain++) {
            iMarker = DomainReceiveMarkers[iDomain][iMarkersDomain];
            Marker_All_SendRecv_Copy[iMarker_] = Marker_All_SendRecv[iMarker];
            for (iElem_Bound = 0; iElem_Bound < nElem_Bound[iMarker]; iElem_Bound++) {
                iElem = bound[iMarker][iElem_Bound]->GetBound_Element();
                bound_Copy[iMarker_][iVertex_] = new CVertexMPI(iElem, nDim);
                bound_Copy[iMarker_][iVertex_]->SetBound_Element(iElem);
                iVertex_++;
            }
        }
    }

    delete [] DomainSendCount;
    for (iDomain = 0; iDomain < nDomain; iDomain++)
        delete DomainSendMarkers[iDomain];
    delete[] DomainSendMarkers;

    delete [] DomainReceiveCount;
    for (iDomain = 0; iDomain < nDomain; iDomain++)
        delete DomainReceiveMarkers[iDomain];
    delete[] DomainReceiveMarkers;

    for (iMarker = 0; iMarker < nMarker; iMarker++)
        delete bound[iMarker];
    delete [] bound;

    bound = bound_Copy;
    nMarker = nMarker_Physical + nMarker_SendRecv;

    config->SetnMarker_All(nMarker);

    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        nElem_Bound[iMarker] = nElem_Bound_Copy[iMarker];
    }
    for (iMarker = nMarker_Physical; iMarker < nMarker; iMarker++) {
        Marker_All_SendRecv[iMarker] = Marker_All_SendRecv_Copy[iMarker];
        config->SetMarker_All_SendRecv(iMarker, Marker_All_SendRecv[iMarker]);
        config->SetMarker_All_TagBound(iMarker, "SEND_RECEIVE");
    }

    /*--- Update config information storing the boundary information in the right place ---*/
    for(iElem = 0; iElem < nElem; iElem++){
        elem[iElem]->SetDomain(true);
    }
    for (iMarker = 0 ; iMarker < nMarker; iMarker++) {

        Marker_Tag = config->GetMarker_All_TagBound(iMarker);

        if (Marker_Tag != "SEND_RECEIVE") {

            Tag_to_Marker[config->GetMarker_CfgFile_TagBound(Marker_Tag)] = Marker_Tag;
            config->SetMarker_All_KindBC(iMarker, config->GetMarker_CfgFile_KindBC(Marker_Tag));
            config->SetMarker_All_Monitoring(iMarker, config->GetMarker_CfgFile_Monitoring(Marker_Tag));
            config->SetMarker_All_Plotting(iMarker, config->GetMarker_CfgFile_Plotting(Marker_Tag));
        }

        else {

            config->SetMarker_All_KindBC(iMarker, SEND_RECEIVE);
            config->SetMarker_All_Monitoring(iMarker, NO);
            config->SetMarker_All_Plotting(iMarker, NO);

            for (iElem_Bound = 0; iElem_Bound < nElem_Bound[iMarker]; iElem_Bound++) {
                if (config->GetMarker_All_SendRecv(iMarker) < 0){
                    elem[bound[iMarker][iElem_Bound]->GetBound_Element()]->SetDomain(false);
                }
            }
        }

        unsigned long iElem_Surface, iFace, iElem;

        for (iElem_Surface = 0; iElem_Surface < nElem_Bound[iMarker]; iElem_Surface++) {
            if (config->GetMarker_All_KindBC(iMarker) != SEND_RECEIVE &&
                    config->GetMarker_All_KindBC(iMarker) != INTERFACE_BOUNDARY &&
                    config->GetMarker_All_KindBC(iMarker) != NEARFIELD_BOUNDARY &&
                    config->GetMarker_All_KindBC(iMarker) != PERIODIC_BOUNDARY){
                iFace = bound[iMarker][iElem_Surface]->GetGlobalFace();
                iElem = face[iFace]->GetElems(0);
                elem[iElem]->SetPhysicalBoundary(true);

            }
            if (config->GetMarker_All_KindBC(iMarker) == EULER_WALL ||
                    config->GetMarker_All_KindBC(iMarker) == HEAT_FLUX ||
                    config->GetMarker_All_KindBC(iMarker) == ISOTHERMAL){
                iFace = bound[iMarker][iElem_Surface]->GetGlobalFace();
                iElem = face[iFace]->GetElems(0);
                elem[iElem]->SetSolidBoundary(true);
            }
        }
    }


    cout<<"..............SET BOUNDARIES..........................."<<rank<<endl;

}

void CPhysicalGeometry::Read_SU2_Format(CConfig *config, string val_mesh_filename, unsigned short val_iZone, unsigned short val_nZone) {

}

//##MAHTAB##//
void CPhysicalGeometry::Read_OpenFOAM_Format(CConfig *config, string val_mesh_filename1,
                                             string val_mesh_filename2, string val_mesh_filename3, string val_mesh_filename4,
                                             string val_mesh_filename5, unsigned short val_iZone, unsigned short val_nZone) {
    ifstream mesh_file1;
    ifstream mesh_file2;
    ifstream mesh_file3;
    ifstream mesh_file4;
    ifstream mesh_file5;

    string text_line, Marker_Tag;
    char cstr[MAX_STRING_SIZE];
    string::size_type position;

    unsigned long i, j, iPoint=0, GlobalIndex, iFace = 0, jFace = 0, Owner_Cell, Neighbor_Cell, iElem = 0, jElem =0;
    unsigned long vnodes_0, vnodes_1, vnodes_2, vnodes_3, vnodes_4, vnodes_5, vnodes_6, vnodes_7;
    unsigned short nNodes, iMarker, iDim, iChar;
    double *Coord_3D = NULL , *Coord_1 =NULL, *Coord_2 = NULL, *Coord_3 = NULL, *Coord_4 = NULL,
            *Coord_5 =NULL, *Coord_6 = NULL, *Coord_7 = NULL, *Coord_8 = NULL,
            *vec_a = NULL, *vec_b = NULL, *vec_a1 = NULL, *vec_a2 = NULL,
            *vec_b1 = NULL, *vec_b2 = NULL, *Normal = NULL, *N_1 = NULL, *N_2 = NULL, *UN1 = NULL, *UN2 = NULL, *CG = NULL;
    double *Atri_1 = NULL, *Atri_2 = NULL, *Atri_3 = NULL, *Atri_4 = NULL,
            *Atri_5 = NULL, *Atri_6 = NULL, *Atri_7 = NULL, *Atri_8 = NULL;

    nDim = 3;
    unsigned long vnodes[nDim+1];

    Coord_3D = new double[nDim];
    Coord_1 = new double[nDim];
    Coord_2 = new double[nDim];
    Coord_3 = new double[nDim];
    Coord_4 = new double[nDim];
    Coord_5 = new double[nDim];
    Coord_6 = new double[nDim];
    Coord_7 = new double[nDim];
    Coord_8 = new double[nDim];
    vec_a = new double[nDim];
    vec_b = new double[nDim];
    vec_a1 = new double[nDim];
    vec_a2 = new double[nDim];
    vec_b1 = new double[nDim];
    vec_b2 = new double[nDim];
    Normal = new double[nDim];
    N_1 = new double[nDim];
    N_2 = new double[nDim];
    UN1 = new double[nDim];
    UN2 = new double[nDim];
    CG = new double[nDim];
    Atri_1 = new double[nDim];
    Atri_2 = new double[nDim];
    Atri_3 = new double[nDim];
    Atri_4 = new double[nDim];
    Atri_5 = new double[nDim];
    Atri_6 = new double[nDim];
    Atri_7 = new double[nDim];
    Atri_8 = new double[nDim];


    /*---Note2: nDim+4; 4 is related to the max. number of nodes of an element in the whole domain---*/

    strcpy (cstr, val_mesh_filename1.c_str());
    mesh_file1.open(cstr, ios::in);

    nPoint =0;
    while (getline (mesh_file1,text_line) && !nPoint) {
        nPoint = atoi(text_line.c_str());
    }
    node =new CPoint*[nPoint];

    while(iPoint < nPoint && getline(mesh_file1, text_line)){
        unsigned st = text_line.find('(');
        unsigned end = text_line.find(')');
        text_line = text_line.substr(st+1, end-1);
        if(text_line.find_last_not_of(" \r\t")>2){
            istringstream point_line(text_line);
            GlobalIndex = iPoint;
            point_line >> Coord_3D[0]; point_line >> Coord_3D[1]; point_line >> Coord_3D[2];
            node[iPoint] = new CPoint(Coord_3D[0], Coord_3D[1], Coord_3D[2], GlobalIndex, config);
            for(iDim = 0; iDim < nDim; iDim++) node[iPoint]->SetCoord(iDim, Coord_3D[iDim]);
            iPoint++;
        }
    }
    mesh_file1.close();

    cout<<" ... points file = done ! ... "<<endl;

    strcpy (cstr, val_mesh_filename2.c_str());
    mesh_file2.open(cstr, ios::in);

    nFace =0;
    while (getline (mesh_file2,text_line) && !nFace) {
        nFace = atoi(text_line.c_str());
    }
    face = new CPrimalGrid*[nFace];

    while(iFace < nFace &&getline(mesh_file2, text_line)){

        unsigned st = text_line.find('(');
        unsigned end = text_line.find(')');
        if(text_line.find_last_not_of(" \r\t")>2){
            istringstream face_line1(text_line);
            face_line1 >> nNodes;
            text_line = text_line.substr(st+1, end-1);
            istringstream face_line(text_line);

            GlobalIndex = iFace;
            face[iFace] = new CFace(nNodes, GlobalIndex);
            /*---Note 3: through each line, how it is possible to read n number of nodes---*/
            if(nNodes == 3){
                face_line >> vnodes[0]; face_line >> vnodes[1]; face_line >> vnodes[2];
                vnodes_0 = vnodes[0];
                vnodes_1 = vnodes[1];
                vnodes_2 = vnodes[2];

                for(iDim = 0; iDim < nDim; iDim++){
                    Coord_1[iDim] = node[vnodes_0]->GetCoord(iDim);
                    Coord_2[iDim] = node[vnodes_1]->GetCoord(iDim);
                    Coord_3[iDim] = node[vnodes_2]->GetCoord(iDim);
                }

                CG[0] = (Coord_1[0]+Coord_2[0]+Coord_3[0])/3;
                CG[1] = (Coord_1[1]+Coord_2[1]+Coord_3[1])/3;
                CG[2] = (Coord_1[2]+Coord_2[2]+Coord_3[2])/3;

                Atri_1[0] = 0.5*((Coord_1[1]-CG[1])*(Coord_2[2]-CG[2])-(Coord_2[1]-CG[1])*(Coord_1[2]-CG[2]));
                Atri_1[1] = -0.5*((Coord_1[0]-CG[0])*(Coord_2[2]-CG[2])-(Coord_2[0]-CG[0])*(Coord_1[2]-CG[2]));
                Atri_1[2] = 0.5*((Coord_1[0]-CG[0])*(Coord_2[1]-CG[1])-(Coord_2[0]-CG[0])*(Coord_1[1]-CG[1]));

                Atri_2[0] = 0.5*((Coord_2[1]-CG[1])*(Coord_3[2]-CG[2])-(Coord_3[1]-CG[1])*(Coord_2[2]-CG[2]));
                Atri_2[1] = -0.5*((Coord_2[0]-CG[0])*(Coord_3[2]-CG[2])-(Coord_3[0]-CG[0])*(Coord_2[2]-CG[2]));
                Atri_2[2] = 0.5*((Coord_2[0]-CG[0])*(Coord_3[1]-CG[1])-(Coord_3[0]-CG[0])*(Coord_2[1]-CG[1]));

                Atri_3[0] = 0.5*((Coord_3[1]-CG[1])*(Coord_1[2]-CG[2])-(Coord_1[1]-CG[1])*(Coord_3[2]-CG[2]));
                Atri_3[1] = -0.5*((Coord_3[0]-CG[0])*(Coord_1[2]-CG[2])-(Coord_1[0]-CG[0])*(Coord_3[2]-CG[2]));
                Atri_3[2] = 0.5*((Coord_3[0]-CG[0])*(Coord_1[1]-CG[1])-(Coord_1[0]-CG[0])*(Coord_3[1]-CG[1]));

                for(iDim = 0; iDim < nDim; iDim++){

                    face[iFace]->SetAtri(0, iDim, Atri_1[iDim]);
                    face[iFace]->SetAtri(1, iDim, Atri_2[iDim]);
                    face[iFace]->SetAtri(2, iDim, Atri_3[iDim]);
                    Normal[iDim] = Atri_1[iDim]+Atri_2[iDim]+Atri_3[iDim];
                    face[iFace]->SetNormal_Face(iDim, Normal[iDim]);
                    face[iFace]->SetCG(iDim, CG[iDim]);
                }

                face[iFace]->SetNode_Face(0, vnodes_0);
                face[iFace]->SetNode_Face(1, vnodes_1);
                face[iFace]->SetNode_Face(2, vnodes_2);

                face[iFace]->SetnNodes_Face(nNodes);
                iFace++;
            }

            if(nNodes == 4){
                face_line >> vnodes[0]; face_line >> vnodes[1]; face_line >> vnodes[2]; face_line >> vnodes[3];
                vnodes_0 = vnodes[0];
                vnodes_1 = vnodes[1];
                vnodes_2 = vnodes[2];
                vnodes_3 = vnodes[3];

                for(iDim = 0; iDim < nDim; iDim++){
                    Coord_1[iDim] = node[vnodes_0]->GetCoord(iDim);
                    Coord_2[iDim] = node[vnodes_1]->GetCoord(iDim);
                    Coord_3[iDim] = node[vnodes_2]->GetCoord(iDim);
                    Coord_4[iDim] = node[vnodes_3]->GetCoord(iDim);
                }

                CG[0] = (Coord_1[0]+Coord_2[0]+Coord_3[0]+Coord_4[0])/4;
                CG[1] = (Coord_1[1]+Coord_2[1]+Coord_3[1]+Coord_4[1])/4;
                CG[2] = (Coord_1[2]+Coord_2[2]+Coord_3[2]+Coord_4[2])/4;

                Atri_1[0] = 0.5*((Coord_1[1]-CG[1])*(Coord_2[2]-CG[2])-(Coord_2[1]-CG[1])*(Coord_1[2]-CG[2]));
                Atri_1[1] = -0.5*((Coord_1[0]-CG[0])*(Coord_2[2]-CG[2])-(Coord_2[0]-CG[0])*(Coord_1[2]-CG[2]));
                Atri_1[2] = 0.5*((Coord_1[0]-CG[0])*(Coord_2[1]-CG[1])-(Coord_2[0]-CG[0])*(Coord_1[1]-CG[1]));

                Atri_2[0] = 0.5*((Coord_2[1]-CG[1])*(Coord_3[2]-CG[2])-(Coord_3[1]-CG[1])*(Coord_2[2]-CG[2]));
                Atri_2[1] = -0.5*((Coord_2[0]-CG[0])*(Coord_3[2]-CG[2])-(Coord_3[0]-CG[0])*(Coord_2[2]-CG[2]));
                Atri_2[2] = 0.5*((Coord_2[0]-CG[0])*(Coord_3[1]-CG[1])-(Coord_3[0]-CG[0])*(Coord_2[1]-CG[1]));

                Atri_3[0] = 0.5*((Coord_3[1]-CG[1])*(Coord_4[2]-CG[2])-(Coord_4[1]-CG[1])*(Coord_3[2]-CG[2]));
                Atri_3[1] = -0.5*((Coord_3[0]-CG[0])*(Coord_4[2]-CG[2])-(Coord_4[0]-CG[0])*(Coord_3[2]-CG[2]));
                Atri_3[2] = 0.5*((Coord_3[0]-CG[0])*(Coord_4[1]-CG[1])-(Coord_4[0]-CG[0])*(Coord_3[1]-CG[1]));

                Atri_4[0] = 0.5*((Coord_4[1]-CG[1])*(Coord_1[2]-CG[2])-(Coord_1[1]-CG[1])*(Coord_4[2]-CG[2]));
                Atri_4[1] = -0.5*((Coord_4[0]-CG[0])*(Coord_1[2]-CG[2])-(Coord_1[0]-CG[0])*(Coord_4[2]-CG[2]));
                Atri_4[2] = 0.5*((Coord_4[0]-CG[0])*(Coord_1[1]-CG[1])-(Coord_1[0]-CG[0])*(Coord_4[1]-CG[1]));

                for(iDim = 0; iDim < nDim; iDim++){

                    face[iFace]->SetAtri(0, iDim, Atri_1[iDim]);
                    face[iFace]->SetAtri(1, iDim, Atri_2[iDim]);
                    face[iFace]->SetAtri(2, iDim, Atri_3[iDim]);
                    face[iFace]->SetAtri(3, iDim, Atri_4[iDim]);
                    Normal[iDim] = (Atri_1[iDim]+Atri_2[iDim]+Atri_3[iDim]+Atri_4[iDim]);

                    face[iFace]->SetNormal_Face(iDim, Normal[iDim]);
                    face[iFace]->SetCG(iDim, CG[iDim]);
                }

                face[iFace]->SetNode_Face(0, vnodes_0);
                face[iFace]->SetNode_Face(1, vnodes_1);
                face[iFace]->SetNode_Face(2, vnodes_2);
                face[iFace]->SetNode_Face(3, vnodes_3);

                face[iFace]->SetnNodes_Face(nNodes);
                iFace++;
            }

            if(nNodes == 5){
                face_line >> vnodes[0]; face_line >> vnodes[1]; face_line >> vnodes[2]; face_line >> vnodes[3]; face_line >> vnodes[4];
                vnodes_0 = vnodes[0];
                vnodes_1 = vnodes[1];
                vnodes_2 = vnodes[2];
                vnodes_3 = vnodes[3];
                vnodes_4 = vnodes[4];

                for(iDim = 0; iDim < nDim; iDim++){
                    Coord_1[iDim] = node[vnodes_0]->GetCoord(iDim);
                    Coord_2[iDim] = node[vnodes_1]->GetCoord(iDim);
                    Coord_3[iDim] = node[vnodes_2]->GetCoord(iDim);
                    Coord_4[iDim] = node[vnodes_3]->GetCoord(iDim);
                    Coord_5[iDim] = node[vnodes_4]->GetCoord(iDim);

                }

                CG[0] = (Coord_1[0]+Coord_2[0]+Coord_3[0]+Coord_4[0]+Coord_5[0])/5;
                CG[1] = (Coord_1[1]+Coord_2[1]+Coord_3[1]+Coord_4[1]+Coord_5[1])/5;
                CG[2] = (Coord_1[2]+Coord_2[2]+Coord_3[2]+Coord_4[2]+Coord_5[2])/5;

                Atri_1[0] = 0.5*((Coord_1[1]-CG[1])*(Coord_2[2]-CG[2])-(Coord_2[1]-CG[1])*(Coord_1[2]-CG[2]));
                Atri_1[1] = -0.5*((Coord_1[0]-CG[0])*(Coord_2[2]-CG[2])-(Coord_2[0]-CG[0])*(Coord_1[2]-CG[2]));
                Atri_1[2] = 0.5*((Coord_1[0]-CG[0])*(Coord_2[1]-CG[1])-(Coord_2[0]-CG[0])*(Coord_1[1]-CG[1]));

                Atri_2[0] = 0.5*((Coord_2[1]-CG[1])*(Coord_3[2]-CG[2])-(Coord_3[1]-CG[1])*(Coord_2[2]-CG[2]));
                Atri_2[1] = -0.5*((Coord_2[0]-CG[0])*(Coord_3[2]-CG[2])-(Coord_3[0]-CG[0])*(Coord_2[2]-CG[2]));
                Atri_2[2] = 0.5*((Coord_2[0]-CG[0])*(Coord_3[1]-CG[1])-(Coord_3[0]-CG[0])*(Coord_2[1]-CG[1]));

                Atri_3[0] = 0.5*((Coord_3[1]-CG[1])*(Coord_4[2]-CG[2])-(Coord_4[1]-CG[1])*(Coord_3[2]-CG[2]));
                Atri_3[1] = -0.5*((Coord_3[0]-CG[0])*(Coord_4[2]-CG[2])-(Coord_4[0]-CG[0])*(Coord_3[2]-CG[2]));
                Atri_3[2] = 0.5*((Coord_3[0]-CG[0])*(Coord_4[1]-CG[1])-(Coord_4[0]-CG[0])*(Coord_3[1]-CG[1]));

                Atri_4[0] = 0.5*((Coord_4[1]-CG[1])*(Coord_5[2]-CG[2])-(Coord_5[1]-CG[1])*(Coord_4[2]-CG[2]));
                Atri_4[1] = -0.5*((Coord_4[0]-CG[0])*(Coord_5[2]-CG[2])-(Coord_5[0]-CG[0])*(Coord_4[2]-CG[2]));
                Atri_4[2] = 0.5*((Coord_4[0]-CG[0])*(Coord_5[1]-CG[1])-(Coord_5[0]-CG[0])*(Coord_4[1]-CG[1]));

                Atri_5[0] = 0.5*((Coord_5[1]-CG[1])*(Coord_1[2]-CG[2])-(Coord_1[1]-CG[1])*(Coord_5[2]-CG[2]));
                Atri_5[1] = -0.5*((Coord_5[0]-CG[0])*(Coord_1[2]-CG[2])-(Coord_1[0]-CG[0])*(Coord_5[2]-CG[2]));
                Atri_5[2] = 0.5*((Coord_5[0]-CG[0])*(Coord_1[1]-CG[1])-(Coord_1[0]-CG[0])*(Coord_5[1]-CG[1]));

                for(iDim = 0; iDim < nDim; iDim++){

                    face[iFace]->SetAtri(0, iDim, Atri_1[iDim]);
                    face[iFace]->SetAtri(1, iDim, Atri_2[iDim]);
                    face[iFace]->SetAtri(2, iDim, Atri_3[iDim]);
                    face[iFace]->SetAtri(3, iDim, Atri_4[iDim]);
                    face[iFace]->SetAtri(4, iDim, Atri_5[iDim]);

                    Normal[iDim] = Atri_1[iDim]+Atri_2[iDim]+Atri_3[iDim]+Atri_4[iDim]+Atri_5[iDim];
                    face[iFace]->SetNormal_Face(iDim, Normal[iDim]);
                    face[iFace]->SetCG(iDim, CG[iDim]);
                }

                face[iFace]->SetNode_Face(0, vnodes_0);
                face[iFace]->SetNode_Face(1, vnodes_1);
                face[iFace]->SetNode_Face(2, vnodes_2);
                face[iFace]->SetNode_Face(3, vnodes_3);
                face[iFace]->SetNode_Face(4, vnodes_4);

                face[iFace]->SetnNodes_Face(nNodes);
                iFace++;
            }

            if(nNodes == 6){
                face_line >> vnodes[0]; face_line >> vnodes[1]; face_line >> vnodes[2]; face_line >> vnodes[3]; face_line >> vnodes[4]; face_line >> vnodes[5];
                vnodes_0 = vnodes[0];
                vnodes_1 = vnodes[1];
                vnodes_2 = vnodes[2];
                vnodes_3 = vnodes[3];
                vnodes_4 = vnodes[4];
                vnodes_5 = vnodes[5];

                for(iDim = 0; iDim < nDim; iDim++){
                    Coord_1[iDim] = node[vnodes_0]->GetCoord(iDim);
                    Coord_2[iDim] = node[vnodes_1]->GetCoord(iDim);
                    Coord_3[iDim] = node[vnodes_2]->GetCoord(iDim);
                    Coord_4[iDim] = node[vnodes_3]->GetCoord(iDim);
                    Coord_5[iDim] = node[vnodes_4]->GetCoord(iDim);
                    Coord_6[iDim] = node[vnodes_5]->GetCoord(iDim);

                }

                CG[0] = (Coord_1[0]+Coord_2[0]+Coord_3[0]+Coord_4[0]+Coord_5[0]+Coord_6[0])/6;
                CG[1] = (Coord_1[1]+Coord_2[1]+Coord_3[1]+Coord_4[1]+Coord_5[1]+Coord_6[1])/6;
                CG[2] = (Coord_1[2]+Coord_2[2]+Coord_3[2]+Coord_4[2]+Coord_5[2]+Coord_6[2])/6;

                Atri_1[0] = 0.5*((Coord_1[1]-CG[1])*(Coord_2[2]-CG[2])-(Coord_2[1]-CG[1])*(Coord_1[2]-CG[2]));
                Atri_1[1] = -0.5*((Coord_1[0]-CG[0])*(Coord_2[2]-CG[2])-(Coord_2[0]-CG[0])*(Coord_1[2]-CG[2]));
                Atri_1[2] = 0.5*((Coord_1[0]-CG[0])*(Coord_2[1]-CG[1])-(Coord_2[0]-CG[0])*(Coord_1[1]-CG[1]));

                Atri_2[0] = 0.5*((Coord_2[1]-CG[1])*(Coord_3[2]-CG[2])-(Coord_3[1]-CG[1])*(Coord_2[2]-CG[2]));
                Atri_2[1] = -0.5*((Coord_2[0]-CG[0])*(Coord_3[2]-CG[2])-(Coord_3[0]-CG[0])*(Coord_2[2]-CG[2]));
                Atri_2[2] = 0.5*((Coord_2[0]-CG[0])*(Coord_3[1]-CG[1])-(Coord_3[0]-CG[0])*(Coord_2[1]-CG[1]));

                Atri_3[0] = 0.5*((Coord_3[1]-CG[1])*(Coord_4[2]-CG[2])-(Coord_4[1]-CG[1])*(Coord_3[2]-CG[2]));
                Atri_3[1] = -0.5*((Coord_3[0]-CG[0])*(Coord_4[2]-CG[2])-(Coord_4[0]-CG[0])*(Coord_3[2]-CG[2]));
                Atri_3[2] = 0.5*((Coord_3[0]-CG[0])*(Coord_4[1]-CG[1])-(Coord_4[0]-CG[0])*(Coord_3[1]-CG[1]));

                Atri_4[0] = 0.5*((Coord_4[1]-CG[1])*(Coord_5[2]-CG[2])-(Coord_5[1]-CG[1])*(Coord_4[2]-CG[2]));
                Atri_4[1] = -0.5*((Coord_4[0]-CG[0])*(Coord_5[2]-CG[2])-(Coord_5[0]-CG[0])*(Coord_4[2]-CG[2]));
                Atri_4[2] = 0.5*((Coord_4[0]-CG[0])*(Coord_5[1]-CG[1])-(Coord_5[0]-CG[0])*(Coord_4[1]-CG[1]));

                Atri_5[0] = 0.5*((Coord_5[1]-CG[1])*(Coord_6[2]-CG[2])-(Coord_6[1]-CG[1])*(Coord_5[2]-CG[2]));
                Atri_5[1] = -0.5*((Coord_5[0]-CG[0])*(Coord_6[2]-CG[2])-(Coord_6[0]-CG[0])*(Coord_5[2]-CG[2]));
                Atri_5[2] = 0.5*((Coord_5[0]-CG[0])*(Coord_6[1]-CG[1])-(Coord_6[0]-CG[0])*(Coord_5[1]-CG[1]));

                Atri_6[0] = 0.5*((Coord_6[1]-CG[1])*(Coord_1[2]-CG[2])-(Coord_1[1]-CG[1])*(Coord_6[2]-CG[2]));
                Atri_6[1] = -0.5*((Coord_6[0]-CG[0])*(Coord_1[2]-CG[2])-(Coord_1[0]-CG[0])*(Coord_6[2]-CG[2]));
                Atri_6[2] = 0.5*((Coord_6[0]-CG[0])*(Coord_1[1]-CG[1])-(Coord_1[0]-CG[0])*(Coord_6[1]-CG[1]));

                for(iDim = 0; iDim < nDim; iDim++){

                    face[iFace]->SetAtri(0, iDim, Atri_1[iDim]);
                    face[iFace]->SetAtri(1, iDim, Atri_2[iDim]);
                    face[iFace]->SetAtri(2, iDim, Atri_3[iDim]);
                    face[iFace]->SetAtri(3, iDim, Atri_4[iDim]);
                    face[iFace]->SetAtri(4, iDim, Atri_5[iDim]);
                    face[iFace]->SetAtri(5, iDim, Atri_6[iDim]);

                    Normal[iDim] = Atri_1[iDim]+Atri_2[iDim]+Atri_3[iDim]+Atri_4[iDim]+Atri_5[iDim]+Atri_6[iDim];
                    face[iFace]->SetNormal_Face(iDim, Normal[iDim]);
                    face[iFace]->SetCG(iDim, CG[iDim]);
                }

                face[iFace]->SetNode_Face(0, vnodes_0);
                face[iFace]->SetNode_Face(1, vnodes_1);
                face[iFace]->SetNode_Face(2, vnodes_2);
                face[iFace]->SetNode_Face(3, vnodes_3);
                face[iFace]->SetNode_Face(4, vnodes_4);
                face[iFace]->SetNode_Face(5, vnodes_5);

                face[iFace]->SetnNodes_Face(nNodes);
                iFace++;
            }

            if(nNodes == 7){
                face_line >> vnodes[0]; face_line >> vnodes[1]; face_line >> vnodes[2]; face_line >> vnodes[3]; face_line >> vnodes[4]; face_line >> vnodes[5];face_line >> vnodes[6];
                vnodes_0 = vnodes[0];
                vnodes_1 = vnodes[1];
                vnodes_2 = vnodes[2];
                vnodes_3 = vnodes[3];
                vnodes_4 = vnodes[4];
                vnodes_5 = vnodes[5];
                vnodes_6 = vnodes[6];

                for(iDim = 0; iDim < nDim; iDim++){
                    Coord_1[iDim] = node[vnodes_0]->GetCoord(iDim);
                    Coord_2[iDim] = node[vnodes_1]->GetCoord(iDim);
                    Coord_3[iDim] = node[vnodes_2]->GetCoord(iDim);
                    Coord_4[iDim] = node[vnodes_3]->GetCoord(iDim);
                    Coord_5[iDim] = node[vnodes_4]->GetCoord(iDim);
                    Coord_6[iDim] = node[vnodes_5]->GetCoord(iDim);
                    Coord_7[iDim] = node[vnodes_6]->GetCoord(iDim);

                }

                CG[0] = (Coord_1[0]+Coord_2[0]+Coord_3[0]+Coord_4[0]+Coord_5[0]+Coord_6[0]+Coord_7[0])/7;
                CG[1] = (Coord_1[1]+Coord_2[1]+Coord_3[1]+Coord_4[1]+Coord_5[1]+Coord_6[1]+Coord_7[1])/7;
                CG[2] = (Coord_1[2]+Coord_2[2]+Coord_3[2]+Coord_4[2]+Coord_5[2]+Coord_6[2]+Coord_7[2])/7;

                Atri_1[0] = 0.5*((Coord_1[1]-CG[1])*(Coord_2[2]-CG[2])-(Coord_2[1]-CG[1])*(Coord_1[2]-CG[2]));
                Atri_1[1] = -0.5*((Coord_1[0]-CG[0])*(Coord_2[2]-CG[2])-(Coord_2[0]-CG[0])*(Coord_1[2]-CG[2]));
                Atri_1[2] = 0.5*((Coord_1[0]-CG[0])*(Coord_2[1]-CG[1])-(Coord_2[0]-CG[0])*(Coord_1[1]-CG[1]));

                Atri_2[0] = 0.5*((Coord_2[1]-CG[1])*(Coord_3[2]-CG[2])-(Coord_3[1]-CG[1])*(Coord_2[2]-CG[2]));
                Atri_2[1] = -0.5*((Coord_2[0]-CG[0])*(Coord_3[2]-CG[2])-(Coord_3[0]-CG[0])*(Coord_2[2]-CG[2]));
                Atri_2[2] = 0.5*((Coord_2[0]-CG[0])*(Coord_3[1]-CG[1])-(Coord_3[0]-CG[0])*(Coord_2[1]-CG[1]));

                Atri_3[0] = 0.5*((Coord_3[1]-CG[1])*(Coord_4[2]-CG[2])-(Coord_4[1]-CG[1])*(Coord_3[2]-CG[2]));
                Atri_3[1] = -0.5*((Coord_3[0]-CG[0])*(Coord_4[2]-CG[2])-(Coord_4[0]-CG[0])*(Coord_3[2]-CG[2]));
                Atri_3[2] = 0.5*((Coord_3[0]-CG[0])*(Coord_4[1]-CG[1])-(Coord_4[0]-CG[0])*(Coord_3[1]-CG[1]));

                Atri_4[0] = 0.5*((Coord_4[1]-CG[1])*(Coord_5[2]-CG[2])-(Coord_5[1]-CG[1])*(Coord_4[2]-CG[2]));
                Atri_4[1] = -0.5*((Coord_4[0]-CG[0])*(Coord_5[2]-CG[2])-(Coord_5[0]-CG[0])*(Coord_4[2]-CG[2]));
                Atri_4[2] = 0.5*((Coord_4[0]-CG[0])*(Coord_5[1]-CG[1])-(Coord_5[0]-CG[0])*(Coord_4[1]-CG[1]));

                Atri_5[0] = 0.5*((Coord_5[1]-CG[1])*(Coord_6[2]-CG[2])-(Coord_6[1]-CG[1])*(Coord_5[2]-CG[2]));
                Atri_5[1] = -0.5*((Coord_5[0]-CG[0])*(Coord_6[2]-CG[2])-(Coord_6[0]-CG[0])*(Coord_5[2]-CG[2]));
                Atri_5[2] = 0.5*((Coord_5[0]-CG[0])*(Coord_6[1]-CG[1])-(Coord_6[0]-CG[0])*(Coord_5[1]-CG[1]));

                Atri_6[0] = 0.5*((Coord_6[1]-CG[1])*(Coord_7[2]-CG[2])-(Coord_7[1]-CG[1])*(Coord_6[2]-CG[2]));
                Atri_6[1] = -0.5*((Coord_6[0]-CG[0])*(Coord_7[2]-CG[2])-(Coord_7[0]-CG[0])*(Coord_6[2]-CG[2]));
                Atri_6[2] = 0.5*((Coord_6[0]-CG[0])*(Coord_7[1]-CG[1])-(Coord_7[0]-CG[0])*(Coord_6[1]-CG[1]));

                Atri_7[0] = 0.5*((Coord_7[1]-CG[1])*(Coord_1[2]-CG[2])-(Coord_1[1]-CG[1])*(Coord_7[2]-CG[2]));
                Atri_7[1] = -0.5*((Coord_7[0]-CG[0])*(Coord_1[2]-CG[2])-(Coord_1[0]-CG[0])*(Coord_7[2]-CG[2]));
                Atri_7[2] = 0.5*((Coord_7[0]-CG[0])*(Coord_1[1]-CG[1])-(Coord_1[0]-CG[0])*(Coord_7[1]-CG[1]));

                for(iDim = 0; iDim < nDim; iDim++){

                    face[iFace]->SetAtri(0, iDim, Atri_1[iDim]);
                    face[iFace]->SetAtri(1, iDim, Atri_2[iDim]);
                    face[iFace]->SetAtri(2, iDim, Atri_3[iDim]);
                    face[iFace]->SetAtri(3, iDim, Atri_4[iDim]);
                    face[iFace]->SetAtri(4, iDim, Atri_5[iDim]);
                    face[iFace]->SetAtri(5, iDim, Atri_6[iDim]);
                    face[iFace]->SetAtri(6, iDim, Atri_7[iDim]);

                    Normal[iDim] = Atri_1[iDim]+Atri_2[iDim]+Atri_3[iDim]+Atri_4[iDim]+Atri_5[iDim]+Atri_6[iDim]+Atri_7[iDim];
                    face[iFace]->SetNormal_Face(iDim, Normal[iDim]);
                    face[iFace]->SetCG(iDim, CG[iDim]);
                }

                face[iFace]->SetNode_Face(0, vnodes_0);
                face[iFace]->SetNode_Face(1, vnodes_1);
                face[iFace]->SetNode_Face(2, vnodes_2);
                face[iFace]->SetNode_Face(3, vnodes_3);
                face[iFace]->SetNode_Face(4, vnodes_4);
                face[iFace]->SetNode_Face(5, vnodes_5);
                face[iFace]->SetNode_Face(6, vnodes_6);

                face[iFace]->SetnNodes_Face(nNodes);
                iFace++;
            }

            if(nNodes == 8){
                face_line >> vnodes[0]; face_line >> vnodes[1]; face_line >> vnodes[2]; face_line >> vnodes[3]; face_line >> vnodes[4]; face_line >> vnodes[5]; face_line >> vnodes[6]; face_line >> vnodes[7];
                vnodes_0 = vnodes[0];
                vnodes_1 = vnodes[1];
                vnodes_2 = vnodes[2];
                vnodes_3 = vnodes[3];
                vnodes_4 = vnodes[4];
                vnodes_5 = vnodes[5];
                vnodes_6 = vnodes[6];
                vnodes_7 = vnodes[7];

                for(iDim = 0; iDim < nDim; iDim++){
                    Coord_1[iDim] = node[vnodes_0]->GetCoord(iDim);
                    Coord_2[iDim] = node[vnodes_1]->GetCoord(iDim);
                    Coord_3[iDim] = node[vnodes_2]->GetCoord(iDim);
                    Coord_4[iDim] = node[vnodes_3]->GetCoord(iDim);
                    Coord_5[iDim] = node[vnodes_4]->GetCoord(iDim);
                    Coord_6[iDim] = node[vnodes_5]->GetCoord(iDim);
                    Coord_7[iDim] = node[vnodes_6]->GetCoord(iDim);
                    Coord_8[iDim] = node[vnodes_7]->GetCoord(iDim);

                }

                CG[0] = (Coord_1[0]+Coord_2[0]+Coord_3[0]+Coord_4[0]+Coord_5[0]+Coord_6[0]+Coord_7[0]+Coord_8[0])/8;
                CG[1] = (Coord_1[1]+Coord_2[1]+Coord_3[1]+Coord_4[1]+Coord_5[1]+Coord_6[1]+Coord_7[1]+Coord_8[1])/8;
                CG[2] = (Coord_1[2]+Coord_2[2]+Coord_3[2]+Coord_4[2]+Coord_5[2]+Coord_6[2]+Coord_7[2]+Coord_8[2])/8;

                Atri_1[0] = 0.5*((Coord_1[1]-CG[1])*(Coord_2[2]-CG[2])-(Coord_2[1]-CG[1])*(Coord_1[2]-CG[2]));
                Atri_1[1] = -0.5*((Coord_1[0]-CG[0])*(Coord_2[2]-CG[2])-(Coord_2[0]-CG[0])*(Coord_1[2]-CG[2]));
                Atri_1[2] = 0.5*((Coord_1[0]-CG[0])*(Coord_2[1]-CG[1])-(Coord_2[0]-CG[0])*(Coord_1[1]-CG[1]));

                Atri_2[0] = 0.5*((Coord_2[1]-CG[1])*(Coord_3[2]-CG[2])-(Coord_3[1]-CG[1])*(Coord_2[2]-CG[2]));
                Atri_2[1] = -0.5*((Coord_2[0]-CG[0])*(Coord_3[2]-CG[2])-(Coord_3[0]-CG[0])*(Coord_2[2]-CG[2]));
                Atri_2[2] = 0.5*((Coord_2[0]-CG[0])*(Coord_3[1]-CG[1])-(Coord_3[0]-CG[0])*(Coord_2[1]-CG[1]));

                Atri_3[0] = 0.5*((Coord_3[1]-CG[1])*(Coord_4[2]-CG[2])-(Coord_4[1]-CG[1])*(Coord_3[2]-CG[2]));
                Atri_3[1] = -0.5*((Coord_3[0]-CG[0])*(Coord_4[2]-CG[2])-(Coord_4[0]-CG[0])*(Coord_3[2]-CG[2]));
                Atri_3[2] = 0.5*((Coord_3[0]-CG[0])*(Coord_4[1]-CG[1])-(Coord_4[0]-CG[0])*(Coord_3[1]-CG[1]));

                Atri_4[0] = 0.5*((Coord_4[1]-CG[1])*(Coord_5[2]-CG[2])-(Coord_5[1]-CG[1])*(Coord_4[2]-CG[2]));
                Atri_4[1] = -0.5*((Coord_4[0]-CG[0])*(Coord_5[2]-CG[2])-(Coord_5[0]-CG[0])*(Coord_4[2]-CG[2]));
                Atri_4[2] = 0.5*((Coord_4[0]-CG[0])*(Coord_5[1]-CG[1])-(Coord_5[0]-CG[0])*(Coord_4[1]-CG[1]));

                Atri_5[0] = 0.5*((Coord_5[1]-CG[1])*(Coord_6[2]-CG[2])-(Coord_6[1]-CG[1])*(Coord_5[2]-CG[2]));
                Atri_5[1] = -0.5*((Coord_5[0]-CG[0])*(Coord_6[2]-CG[2])-(Coord_6[0]-CG[0])*(Coord_5[2]-CG[2]));
                Atri_5[2] = 0.5*((Coord_5[0]-CG[0])*(Coord_6[1]-CG[1])-(Coord_6[0]-CG[0])*(Coord_5[1]-CG[1]));

                Atri_6[0] = 0.5*((Coord_6[1]-CG[1])*(Coord_7[2]-CG[2])-(Coord_7[1]-CG[1])*(Coord_6[2]-CG[2]));
                Atri_6[1] = -0.5*((Coord_6[0]-CG[0])*(Coord_7[2]-CG[2])-(Coord_7[0]-CG[0])*(Coord_6[2]-CG[2]));
                Atri_6[2] = 0.5*((Coord_6[0]-CG[0])*(Coord_7[1]-CG[1])-(Coord_7[0]-CG[0])*(Coord_6[1]-CG[1]));

                Atri_7[0] = 0.5*((Coord_7[1]-CG[1])*(Coord_8[2]-CG[2])-(Coord_8[1]-CG[1])*(Coord_7[2]-CG[2]));
                Atri_7[1] = -0.5*((Coord_7[0]-CG[0])*(Coord_8[2]-CG[2])-(Coord_8[0]-CG[0])*(Coord_7[2]-CG[2]));
                Atri_7[2] = 0.5*((Coord_7[0]-CG[0])*(Coord_8[1]-CG[1])-(Coord_8[0]-CG[0])*(Coord_7[1]-CG[1]));

                Atri_8[0] = 0.5*((Coord_8[1]-CG[1])*(Coord_1[2]-CG[2])-(Coord_1[1]-CG[1])*(Coord_8[2]-CG[2]));
                Atri_8[1] = -0.5*((Coord_8[0]-CG[0])*(Coord_1[2]-CG[2])-(Coord_1[0]-CG[0])*(Coord_8[2]-CG[2]));
                Atri_8[2] = 0.5*((Coord_8[0]-CG[0])*(Coord_1[1]-CG[1])-(Coord_1[0]-CG[0])*(Coord_8[1]-CG[1]));

                for(iDim = 0; iDim < nDim; iDim++){

                    face[iFace]->SetAtri(0, iDim, Atri_1[iDim]);
                    face[iFace]->SetAtri(1, iDim, Atri_2[iDim]);
                    face[iFace]->SetAtri(2, iDim, Atri_3[iDim]);
                    face[iFace]->SetAtri(3, iDim, Atri_4[iDim]);
                    face[iFace]->SetAtri(4, iDim, Atri_5[iDim]);
                    face[iFace]->SetAtri(5, iDim, Atri_6[iDim]);
                    face[iFace]->SetAtri(6, iDim, Atri_7[iDim]);
                    face[iFace]->SetAtri(7, iDim, Atri_8[iDim]);

                    Normal[iDim] = Atri_1[iDim]+Atri_2[iDim]+Atri_3[iDim]+Atri_4[iDim]+Atri_5[iDim]+Atri_6[iDim]+Atri_7[iDim]+Atri_8[iDim];
                    face[iFace]->SetNormal_Face(iDim, Normal[iDim]);
                    face[iFace]->SetCG(iDim, CG[iDim]);
                }

                face[iFace]->SetNode_Face(0, vnodes_0);
                face[iFace]->SetNode_Face(1, vnodes_1);
                face[iFace]->SetNode_Face(2, vnodes_2);
                face[iFace]->SetNode_Face(3, vnodes_3);
                face[iFace]->SetNode_Face(4, vnodes_4);
                face[iFace]->SetNode_Face(5, vnodes_5);
                face[iFace]->SetNode_Face(6, vnodes_6);
                face[iFace]->SetNode_Face(7, vnodes_7);

                face[iFace]->SetnNodes_Face(nNodes);
                iFace++;
            }


        }
    }

    mesh_file2.close();

    cout<<" ... faces file = done ! ... "<<endl;

    for (iFace = 0; iFace < nFace; iFace++){
        for (i = 0; i < 2; i++){
            face[iFace]->SetElems(i, -1);
        }
    }

    strcpy (cstr, val_mesh_filename3.c_str());
    nElem = 0;

    mesh_file3.open(cstr, ios::in);
    nFace =0;
    while (getline (mesh_file3,text_line) && !nFace) {
        nFace = atoi(text_line.c_str());
    }

    iFace = 0;
    while(iFace < nFace&& getline(mesh_file3, text_line)){
        istringstream owner_line(text_line);
        owner_line >> Owner_Cell;

        face[iFace]->SetElems(0, Owner_Cell);

        nElem = max(nElem, Owner_Cell);

        iFace++;
    }
    mesh_file3.close();

    strcpy (cstr, val_mesh_filename4.c_str());
    mesh_file4.open(cstr, ios::in);
    nFaceT =0;
    while (getline (mesh_file4,text_line) && !nFaceT) {
        nFaceT = atoi(text_line.c_str());
    }
    iFace = 0;
    while(iFace < nFaceT&&getline(mesh_file4, text_line)){

        istringstream neighbor_line(text_line);
        neighbor_line >> Neighbor_Cell;
        face[iFace]->SetElems(1, Neighbor_Cell);
        nElem = max(nElem, Neighbor_Cell);

        iFace++;
    }
    mesh_file4.close();

    ++nElem;

    cout<<" ... The total number of elements = "<<nElem<<endl;

    long *nFaceE = NULL; nFaceE =  new long [nElem];
    long *nFaceEE = NULL; nFaceEE = new long [nElem];
    double *Volume_Cell = NULL; Volume_Cell = new double [nElem];
    double **CG_Celll = NULL;
    CG_Celll = new double* [nDim];
    for (iDim = 0; iDim < nDim; iDim++)
        CG_Celll[iDim] = new double[nElem];

    for (iDim = 0; iDim < nDim; iDim++){
        for (iElem = 0; iElem < nElem; iElem++){
            CG_Celll[iDim][iElem] = 0.0;
        }
    }

    for(iElem = 0; iElem < nElem; iElem++){
        Volume_Cell[iElem] = 0.0; nFaceE[iElem] = 0;
    }

    elem = new CPrimalGrid*[nElem];

    strcpy (cstr, val_mesh_filename3.c_str());

    iFace = 0;
    while(iFace < nFace){
        iElem = face[iFace]->GetElems(0);
        Volume_Cell[iElem] = Volume_Cell[iElem]+face[iFace]->GetVolume_Face();
        nFaceE[iElem]++;
        iFace++;
    }

    iFace = 0;
    while(iFace < nFaceT){
        iElem = face[iFace]->GetElems(1);
        Volume_Cell[iElem] = Volume_Cell[iElem]+face[iFace]->GetVolume_Face();
        nFaceE[iElem]++;
        iFace++;
    }

    iFace = 0;
    while(iFace < nFace){
        iElem = face[iFace]->GetElems(0);
        for(iDim = 0; iDim < nDim; iDim++)
            CG_Celll[iDim][iElem]=CG_Celll[iDim][iElem]+face[iFace]->GetCG(iDim);
        iFace++;
    }

    iFace = 0;
    while(iFace < nFaceT){
        iElem = face[iFace]->GetElems(1);
        for(iDim = 0; iDim < nDim; iDim++)
            CG_Celll[iDim][iElem]=CG_Celll[iDim][iElem]+face[iFace]->GetCG(iDim);
        iFace++;
    }

    long **IFace = NULL;
    IFace = new long* [nElem];
    for(iElem = 0; iElem < nElem; iElem++){
        IFace[iElem] = new long[nFaceE[iElem]];
        nFaceE[iElem] = 0;
    }

    iFace = 0;
    while(iFace < nFace){
        iElem = face[iFace]->GetElems(0);
        IFace[iElem][nFaceE[iElem]] = iFace;
        nFaceE[iElem]++;
        iFace++;
    }

    iFace = 0;
    while(iFace < nFaceT){
        iElem = face[iFace]->GetElems(1);
        IFace[iElem][nFaceE[iElem]] = iFace;
        nFaceE[iElem]++;
        iFace++;
    }

    for(iElem = 0; iElem < nElem; iElem++){
        elem[iElem] = new CElement(nFaceE[iElem], iElem);
        elem[iElem]->SetnNeighbor_Face(nFaceE[iElem]);
        for(iDim = 0; iDim < nDim; iDim++) elem[iElem]->SetCG(iDim, CG_Celll[iDim][iElem]);

        for(iFace = 0; iFace < elem[iElem]->GetnNeighbor_Face(); iFace++){
            elem[iElem]->SetNeighbor_Face(IFace[iElem][iFace], iFace);
        }
    }

    for(iElem = 0; iElem < nElem; iElem++){
        delete[] IFace[iElem];
    }
    delete[] IFace;

    cout<<" ... owner and neighbor files = done ! ... "<<endl;

    strcpy (cstr, val_mesh_filename5.c_str());
    mesh_file5.open(cstr, ios::in);

    while (getline (mesh_file5,text_line)) {
        position = text_line.find ("NMARK=",0);
        if (position != string::npos) {
            text_line.erase (0,6);
            nMarker = atoi(text_line.c_str());
        }
        nElem_Bound = new unsigned long [nMarker];
        Start_Face  = new unsigned long [nMarker];

        for(iMarker = 0; iMarker < nMarker; iMarker++){
            getline(mesh_file5, text_line);
            text_line.erase(0,11);
            string::size_type position;
            for (iChar = 0; iChar < 20; iChar++) {
                position = text_line.find( " ", 0 );
                if(position != string::npos) text_line.erase (position,1);
                position = text_line.find( "\r", 0 );
                if(position != string::npos) text_line.erase (position,1);
                position = text_line.find( "\n", 0 );
                if(position != string::npos) text_line.erase (position,1);
            }
            Marker_Tag = text_line.c_str();
            config->SetMarker_All_TagBound(iMarker, Marker_Tag);
            if (Marker_Tag != "SEND_RECEIVE") {
                getline (mesh_file5,text_line);
                text_line.erase (0,6);
                nElem_Bound[iMarker] = atoi(text_line.c_str());
                SetnElem_Bound(iMarker, nElem_Bound[iMarker]);
                cout<<"iMarker = "<<iMarker<<"  nElem =  "<<GetnElem_Bound(iMarker)<<endl;
                getline (mesh_file5,text_line);
                text_line.erase (0,11);
                Start_Face[iMarker] = atoi(text_line.c_str());
                SetStart_Face(iMarker, Start_Face[iMarker]);
                config->SetMarker_All_KindBC(iMarker, config->GetMarker_CfgFile_KindBC(Marker_Tag));
            }
        }
    }
    mesh_file5.close();

    cout<<" ... boundary file = done ! ... "<<endl;

    for(iElem = 0; iElem < nElem; iElem++){
        nFaceEE[iElem] = 0;
        for(i = 0; i < elem[iElem]->GetnNeighbor_Face(); i++){
            iFace = elem[iElem]->GetNeighbor_Face(i);
            for(j = 0; j < 2; j++){
                if(face[iFace]->GetElems(j) != -1){
                    jElem = face[iFace]->GetElems(j);
                    if(jElem != iElem){
                        elem[iElem]->SetNeighbor_Cell(jElem, nFaceEE[iElem]);
                        nFaceEE[iElem]++;
                        elem[iElem]->SetnNeighbor_Cell(nFaceEE[iElem]);
                    }
                }
            }
        }
    }

    unsigned long iVertex;
    bound = new CPrimalGrid**[nMarker];
    for (iMarker = 0; iMarker < nMarker; iMarker++) bound[iMarker] = new CPrimalGrid*[nElem_Bound[iMarker]];

    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        jFace = Start_Face[iMarker];
        for(iVertex = 0; iVertex < nElem_Bound[iMarker]; iVertex++){
            bound[iMarker][iVertex] = new CFace(face[jFace]->GetnNodes_Face(), jFace);
            bound[iMarker][iVertex]->SetGlobalFace(jFace);
            jFace++;
        }
    }

    for(iElem = 0; iElem < nElem; iElem++){
        for(iDim = 0; iDim < nDim; iDim++){
            CG[iDim] = elem[iElem]->GetCG(iDim);
            CG[iDim] = CG[iDim]/elem[iElem]->GetnNeighbor_Face();
            elem[iElem]->SetCG(iDim, CG[iDim]);
        }
    }

    double Vtri, Volume;
    for(iElem = 0; iElem < nElem; iElem++){
        Volume = 0.;
        for(i = 0; i < elem[iElem]->GetnNeighbor_Face(); i++){
            iFace = elem[iElem]->GetNeighbor_Face(i); Vtri = 0.;
            for(j = 0; j < face[iFace]->GetnNodes_Face(); j++){
                for(iDim = 0; iDim < nDim; iDim++)
                    Vtri = Vtri+fabs((face[iFace]->GetAtri(j, iDim))*(elem[iElem]->GetCG(iDim)-face[iFace]->GetCG(iDim)))/3.0;
                Volume = Volume+Vtri;

            }
        }
        elem[iElem]->SetVolume(Volume);
    }

    cout<<"OpenFoam Mesh Format has been read, successfully."<<endl;
}

/*---By Mahtab---*/
void CPhysicalGeometry::Read_CGNS_Format(CConfig *config, string val_mesh_filename, unsigned short val_iZone, unsigned short val_nZone){

}

void CPhysicalGeometry::Read_NETCDF_Format(CConfig *config, string val_mesh_filename, unsigned short val_iZone, unsigned short val_nZone) {

}

void CPhysicalGeometry::Check_IntElem_Orientation(CConfig *config) {

}

void CPhysicalGeometry::Check_BoundElem_Orientation(CConfig *config) {

}

void CPhysicalGeometry::ComputeWall_Distance(CConfig *config) {

    double *coord, dist2, dist;
    unsigned short iDim, iMarker;
    unsigned long iElem_Bound, iFace, iElem, iVertex, nVertex_SolidWall;

    int rank = MASTER_NODE;
#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif
    if (rank == MASTER_NODE)
        cout << "Computing wall distances." <<endl;

#ifndef HAVE_MPI

    nVertex_SolidWall = 0;
    for (iMarker = 0; iMarker < config->GetnMarker_All(); iMarker++){
        if(config->GetMarker_All_KindBC(iMarker) == HEAT_FLUX){
            for(iElem_Bound = 0; iElem_Bound < GetnElem_Bound(iMarker); iElem_Bound++){
                nVertex_SolidWall++;
            }
        }
    }

    double **Coord_bound;
    Coord_bound = new double* [nVertex_SolidWall];
    for (iVertex = 0; iVertex < nVertex_SolidWall; iVertex++)
        Coord_bound[iVertex] = new double [nDim];

    nVertex_SolidWall = 0;
    for(iMarker = 0; iMarker < config->GetnMarker_All(); iMarker++){
        if(config->GetMarker_All_KindBC(iMarker) == HEAT_FLUX){
            for(iElem_Bound = 0; iElem_Bound < GetnElem_Bound(iMarker); iElem_Bound++){
                iFace = bound[iMarker][iElem_Bound]->GetGlobalFace();
                for (iDim = 0; iDim < nDim; iDim++)
                    Coord_bound[nVertex_SolidWall][iDim] = face[iFace]->GetCG(iDim);
                nVertex_SolidWall++;
            }
        }
    }

    if (nVertex_SolidWall != 0) {
        for (iElem = 0; iElem < GetnElem(); iElem++) {
            coord = elem[iElem]->GetCG();
            dist = 1E20;
            for (iVertex = 0; iVertex < nVertex_SolidWall; iVertex++) {
                dist2 = 0.0;
                for (iDim = 0; iDim < nDim; iDim++)
                    dist2 += (coord[iDim]-Coord_bound[iVertex][iDim])
                            *(coord[iDim]-Coord_bound[iVertex][iDim]);
                if (dist2 < dist) dist = dist2;
            }
            elem[iElem]->SetWall_Distance(sqrt(dist));
        }
    }
    else {
        for (iElem = 0; iElem < GetnElem(); iElem++)
            elem[iElem]->SetWall_Distance(0.0);
    }

    for (iVertex = 0; iVertex < nVertex_SolidWall; iVertex++)
        delete[] Coord_bound[iVertex];
    delete[] Coord_bound;


#else


    int iProcessor, nProcessor;
    MPI_Comm_size(MPI_COMM_WORLD, &nProcessor);

    unsigned long nLocalVertex_NS = 0, nGlobalVertex_NS = 0, MaxLocalVertex_NS = 0;
    unsigned long *Buffer_Send_nVertex    = new unsigned long [1];
    unsigned long *Buffer_Receive_nVertex = new unsigned long [nProcessor];

    for (iMarker = 0; iMarker < config->GetnMarker_All(); iMarker++){
        if(config->GetMarker_All_KindBC(iMarker) == HEAT_FLUX){
            for(iVertex = 0; iVertex < GetnElem_Bound(iMarker); iVertex++){
                nLocalVertex_NS++;
            }
        }
    }

    Buffer_Send_nVertex[0] = nLocalVertex_NS;
    MPI_Allreduce(&nLocalVertex_NS, &nGlobalVertex_NS,  1, MPI_UNSIGNED_LONG, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(&nLocalVertex_NS, &MaxLocalVertex_NS, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allgather(Buffer_Send_nVertex, 1, MPI_UNSIGNED_LONG, Buffer_Receive_nVertex, 1, MPI_UNSIGNED_LONG, MPI_COMM_WORLD);


    double *Buffer_Send_Coord    = new double [MaxLocalVertex_NS*nDim];
    double *Buffer_Receive_Coord = new double [nProcessor*MaxLocalVertex_NS*nDim];
    unsigned long nBuffer = MaxLocalVertex_NS*nDim;

    for (iVertex = 0; iVertex < MaxLocalVertex_NS; iVertex++)
        for (iDim = 0; iDim < nDim; iDim++)
            Buffer_Send_Coord[iVertex*nDim+iDim] = 0.0;


    nVertex_SolidWall = 0;
    for (iMarker = 0; iMarker < config->GetnMarker_All(); iMarker++){
        if (config->GetMarker_All_KindBC(iMarker) == HEAT_FLUX){
            for (iVertex = 0; iVertex < GetnElem_Bound(iMarker); iVertex++) {
                iFace = bound[iMarker][iVertex]->GetGlobalFace();
                for (iDim = 0; iDim < nDim; iDim++)
                    Buffer_Send_Coord[nVertex_SolidWall*nDim+iDim] = face[iFace]->GetCG(iDim);
                nVertex_SolidWall++;
            }
        }
    }

    MPI_Allgather(Buffer_Send_Coord, nBuffer, MPI_DOUBLE, Buffer_Receive_Coord, nBuffer, MPI_DOUBLE, MPI_COMM_WORLD);

    nVertex_SolidWall = 0;
    for (iProcessor = 0; iProcessor < nProcessor; iProcessor++) {
        nVertex_SolidWall += Buffer_Receive_nVertex[iProcessor];
    }

    if (nVertex_SolidWall != 0) {
        for (iElem = 0; iElem < GetnElem(); iElem++) {
            coord = elem[iElem]->GetCG();
            dist = 1E20;
            for (iProcessor = 0; iProcessor < nProcessor; iProcessor++)
                for (iVertex = 0; iVertex < Buffer_Receive_nVertex[iProcessor]; iVertex++) {
                    dist2 = 0.0;
                    for (iDim = 0; iDim < nDim; iDim++)
                        dist2 += (coord[iDim]-Buffer_Receive_Coord[(iProcessor*MaxLocalVertex_NS+iVertex)*nDim+iDim])*
                                (coord[iDim]-Buffer_Receive_Coord[(iProcessor*MaxLocalVertex_NS+iVertex)*nDim+iDim]);
                    if (dist2 < dist) dist = dist2;
                }
            elem[iElem]->SetWall_Distance(sqrt(dist));
        }
    }
    else {
        for (iElem = 0; iElem < GetnElem(); iElem++)
            elem[iElem]->SetWall_Distance(0.0);
    }

    delete[] Buffer_Send_Coord;
    delete[] Buffer_Receive_Coord;
    delete[] Buffer_Send_nVertex;
    delete[] Buffer_Receive_nVertex;

#endif

}

void CPhysicalGeometry::SetPositive_ZArea(CConfig *config) {
    unsigned short iMarker, Boundary, Monitoring;
    unsigned long iVertex, iPoint, iPointNormal;
    double *Normal, PositiveZArea;
    int rank = MASTER_NODE;

#ifndef HAVE_MPI

    PositiveZArea = 0.0;
    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        Boundary = config->GetMarker_All_KindBC(iMarker);
        Monitoring = config->GetMarker_All_Monitoring(iMarker);

        if (((Boundary == EULER_WALL)              ||
             (Boundary == HEAT_FLUX)               ||
             (Boundary == HEAT_FLUX_CATALYTIC)     ||
             (Boundary == HEAT_FLUX_NONCATALYTIC)  ||
             (Boundary == ISOTHERMAL)              ||
             (Boundary == ISOTHERMAL_CATALYTIC)    ||
             (Boundary == ISOTHERMAL_NONCATALYTIC) ||
             (Boundary == LOAD_BOUNDARY)           ||
             (Boundary == DISPLACEMENT_BOUNDARY)) && (Monitoring == YES))
            for(iVertex = 0; iVertex < nElem_Bound[iMarker]; iVertex++) {
                iPointNormal = bound[iMarker][iVertex]->GetGlobalFace();
                iPoint = face[iPointNormal]->GetElems(0);
                if (elem[iPoint]->GetDomain()) {
                    Normal = face[iPointNormal]->GetNormal_Face();
                    if (Normal[nDim-1] < 0) PositiveZArea -= Normal[nDim-1];
                }
            }
    }

#else

    double TotalPositiveZArea;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    PositiveZArea = 0.0;
    for (iMarker = 0; iMarker < nMarker; iMarker++) {
        Boundary = config->GetMarker_All_KindBC(iMarker);
        Monitoring = config->GetMarker_All_Monitoring(iMarker);

        if (((Boundary == EULER_WALL)              ||
             (Boundary == HEAT_FLUX)               ||
             (Boundary == HEAT_FLUX_CATALYTIC)     ||
             (Boundary == HEAT_FLUX_NONCATALYTIC)  ||
             (Boundary == ISOTHERMAL)              ||
             (Boundary == ISOTHERMAL_CATALYTIC)    ||
             (Boundary == ISOTHERMAL_NONCATALYTIC) ||
             (Boundary == LOAD_BOUNDARY)           ||
             (Boundary == DISPLACEMENT_BOUNDARY)) && (Monitoring == YES))
            for(iVertex = 0; iVertex < nElem_Bound[iMarker]; iVertex++) {
                iPointNormal = bound[iMarker][iVertex]->GetGlobalFace();
                iPoint = face[iPointNormal]->GetElems(0);
                if (elem[iPoint]->GetDomain()) {
                    Normal = face[iPointNormal]->GetNormal_Face();
                    if (Normal[nDim-1] < 0) PositiveZArea -= Normal[nDim-1];
                }
            }
    }
    MPI_Reduce(&PositiveZArea, &TotalPositiveZArea, 1, MPI_DOUBLE, MPI_SUM, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    if (rank == MASTER_NODE) PositiveZArea = TotalPositiveZArea;
    MPI_Bcast(&PositiveZArea, 1, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);

#endif

    if (config->GetRefAreaCoeff() == 0.0)
        config->SetRefAreaCoeff(PositiveZArea);

    if (rank == MASTER_NODE) {
        if (nDim == 2) cout << "Area projection in the y-plane = "<< PositiveZArea << "." << endl;
        else cout << "Area projection in the z-plane = "<< PositiveZArea << "." << endl;
    }

}

void CPhysicalGeometry::SetPoint_Connectivity(void) {

}

void CPhysicalGeometry::SetRCM_Ordering(CConfig *config) {

}

void CPhysicalGeometry::SetElement_Connectivity(void) {

}

void CPhysicalGeometry::SetBoundVolume(void) {

}

void CPhysicalGeometry::SetVertex(CConfig *config) {

}

void CPhysicalGeometry::SetBoundControlVolume(CConfig *config, unsigned short action) {

}

void CPhysicalGeometry::MatchInterface(CConfig *config) {

}

void CPhysicalGeometry::MatchNearField(CConfig *config) {

}

void CPhysicalGeometry::MatchActuator_Disk(CConfig *config) {

}

void CPhysicalGeometry::MatchZone(CConfig *config, CGeometry *geometry_donor, CConfig *config_donor,
                                  unsigned short val_iZone, unsigned short val_nZone) {

}


void CPhysicalGeometry::SetControlVolume(CConfig *config, unsigned short action) {

}

void CPhysicalGeometry::VisualizeControlVolume(CConfig *config, unsigned short action) {

}

void CPhysicalGeometry::SetMeshFile (CConfig *config, string val_mesh_out_filename) {

}

void CPhysicalGeometry::SetCoord_Smoothing (unsigned short val_nSmooth, double val_smooth_coeff, CConfig *config) {

}

bool CPhysicalGeometry::FindFace(unsigned long first_elem, unsigned long second_elem, unsigned short &face_first_elem,
                                 unsigned short &face_second_elem) {

}

void CPhysicalGeometry::SetTecPlot(char mesh_filename[MAX_STRING_SIZE], bool new_file) {

}

void CPhysicalGeometry::SetBoundTecPlot(char mesh_filename[MAX_STRING_SIZE], bool new_file, CConfig *config) {

}

void CPhysicalGeometry::SetBoundSTL(char mesh_filename[MAX_STRING_SIZE], bool new_file, CConfig *config) {

}

/*---By Mahtab---*/
void CPhysicalGeometry::SetColorGrid(CConfig *config) {

#ifdef HAVE_MPI

#ifdef HAVE_METIS

    unsigned long  iElem, jElem, iFace, iNeigh;
    idx_t *xtemp,*adjncy =NULL, *xadj = NULL, ncon, ne = 0, ncommon, nn, *elmnts = NULL, etype, *epart = NULL, *npart = NULL, numflag, nparts, edgecut, *eptr, *nNeighbors=NULL, **neighbors = NULL;
    int rank, size;

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (size != SINGLE_ZONE)
        cout << endl <<"---------------------------- Grid partitioning --------------------------" << endl;

    unsigned short nDomain = size;
    epart = new idx_t [ne];

    xtemp = new idx_t [nElem];
    for(iElem = 0; iElem < nElem; iElem++){
        xtemp[iElem] =0;
    }

    for(iElem = 0; iElem < nElem; iElem++){
        for(iNeigh = 0; iNeigh < elem[iElem]->GetnNeighbor_Cell(); iNeigh++){
            jElem = elem[iElem]->GetNeighbor_Cell(iNeigh);
            xtemp[iElem] +=1;
            xtemp[jElem] +=1;
        }
    }


    idx_t adjsize=0;
    for(iElem = 0; iElem < nElem; iElem++){
        adjsize += xtemp[iElem];
    }

    xadj = new idx_t [nElem+1];
    adjncy = new idx_t [adjsize];
    xadj[0] = 0;
    for(iElem = 1; iElem < nElem+1; iElem++){
        xadj[iElem] = xadj[iElem-1] + xtemp[iElem-1];
    }

    xtemp = new idx_t [nElem];  //offset
    for(iElem = 0; iElem < nElem; iElem++){
        xtemp[iElem] =0;
    }

    for(iElem = 0; iElem < nElem; iElem++){
        for(iNeigh = 0; iNeigh < elem[iElem]->GetnNeighbor_Cell(); iNeigh++){

            jElem = elem[iElem]->GetNeighbor_Cell(iNeigh);
            int c0 = iElem;
            int c1 = jElem;
            adjncy[xadj[c0] + xtemp[c0]] =c1;
            ++xtemp[c0];
            adjncy[xadj[c1] + xtemp[c1]] =c0;
            ++xtemp[c1];

        }
    }

    ne = nElem;
    ncon = 1;
    MPI_Comm_size(MPI_COMM_WORLD,&nparts);
    cout << "My size is "<< nparts << endl;

    if(nparts ==0) {
        exit(0);
        cout << "My size is "<< nparts << endl;
    }
    epart = new idx_t [ne];

    METIS_PartGraphRecursive
            (&ne, &ncon, xadj, adjncy, NULL, NULL, NULL, &nparts, NULL, NULL, NULL, &edgecut, epart);

    int *pec = new int[nparts];
    for(int l =0; l<nparts; l++) pec[l]=0;
    for(iElem = 0; iElem < nElem; iElem++){
        pec[epart[iElem]]++;
    }

    for(int l =0; l<nparts; l++) cout<<"nElem =    "<<pec[l]<<endl;

    for(iElem = 0; iElem < nElem; iElem++){
        elem[iElem]->SetColor(epart[iElem]);
    }

    cout<<"Grid Partitioning is done "<<endl;

#endif

#endif

}
/*---By Mahtab---*/

void CPhysicalGeometry::GetQualityStatistics(double *statistics) {

}

void CPhysicalGeometry::SetRotationalVelocity(CConfig *config) {

    unsigned long iPoint;
    double RotVel[3], Distance[3], *Coord, Center[3], Omega[3], L_Ref;

    int rank = MASTER_NODE;
#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

    /*--- Center of rotation & angular velocity vector from config ---*/

    Center[0] = config->GetMotion_Origin_X(ZONE_0);
    Center[1] = config->GetMotion_Origin_Y(ZONE_0);
    Center[2] = config->GetMotion_Origin_Z(ZONE_0);
    Omega[0]  = config->GetRotation_Rate_X(ZONE_0)/config->GetOmega_Ref();
    Omega[1]  = config->GetRotation_Rate_Y(ZONE_0)/config->GetOmega_Ref();
    Omega[2]  = config->GetRotation_Rate_Z(ZONE_0)/config->GetOmega_Ref();
    L_Ref     = config->GetLength_Ref();

    /*--- Print some information to the console ---*/

    if (rank == MASTER_NODE) {
        cout << " Rotational origin (x,y,z): ( " << Center[0] << ", " << Center[1];
        cout << ", " << Center[2] << " )" << endl;
        cout << " Angular velocity about x, y, z axes: ( " << Omega[0] << ", ";
        cout << Omega[1] << ", " << Omega[2] << " ) rad/s" << endl;
    }

    /*--- Loop over all nodes and set the rotational velocity ---*/

    for (iPoint = 0; iPoint < nElem; iPoint++) {

        /*--- Get the coordinates of the current node ---*/

        Coord = elem[iPoint]->GetCG();

        /*--- Calculate the non-dim. distance from the rotation center ---*/

        Distance[0] = (Coord[0]-Center[0])/L_Ref;
        Distance[1] = (Coord[1]-Center[1])/L_Ref;
        Distance[2] = (Coord[2]-Center[2])/L_Ref;

        /*--- Calculate the angular velocity as omega X r ---*/

        RotVel[0] = Omega[1]*(Distance[2]) - Omega[2]*(Distance[1]);
        RotVel[1] = Omega[2]*(Distance[0]) - Omega[0]*(Distance[2]);
        RotVel[2] = Omega[0]*(Distance[1]) - Omega[1]*(Distance[0]);

        /*--- Store the grid velocity at this node ---*/

        elem[iPoint]->SetGridVel(RotVel);

    }

}

void CPhysicalGeometry::SetGridVelocity(CConfig *config, unsigned long iter) {

}

void CPhysicalGeometry::Set_MPI_Coord(CConfig *config)  {

}

void CPhysicalGeometry::Set_MPI_GridVel(CConfig *config)  {

}

void CPhysicalGeometry::SetPeriodicBoundary(CConfig *config) {

}

void CPhysicalGeometry::FindNormal_Neighbor(CConfig *config) {

}

void CPhysicalGeometry::SetGeometryPlanes(CConfig *config) {

}

void CPhysicalGeometry::SetBoundSensitivity(CConfig *config) {

}

double CPhysicalGeometry::Compute_MaxThickness(double *Plane_P0, double *Plane_Normal, unsigned short iSection, CConfig *config, vector<double> &Xcoord_Airfoil, vector<double> &Ycoord_Airfoil, vector<double> &Zcoord_Airfoil, bool original_surface) {
    unsigned long iVertex, jVertex, n, Trailing_Point, Leading_Point;
    double Normal[3], Tangent[3], BiNormal[3], auxXCoord, auxYCoord, auxZCoord, zp1, zpn, MaxThickness_Value = 0, Thickness, Length, Xcoord_Trailing, Ycoord_Trailing, Zcoord_Trailing, ValCos, ValSin, XValue, ZValue, MaxDistance, Distance, AoA;
    vector<double> Xcoord, Ycoord, Zcoord, Z2coord, Xcoord_Normal, Ycoord_Normal, Zcoord_Normal, Xcoord_Airfoil_, Ycoord_Airfoil_, Zcoord_Airfoil_;

    /*--- Find the leading and trailing edges and compute the angle of attack ---*/

    MaxDistance = 0.0; Trailing_Point = 0; Leading_Point = 0;
    for (iVertex = 1; iVertex < Xcoord_Airfoil.size(); iVertex++) {
        Distance = sqrt(pow(Xcoord_Airfoil[iVertex] - Xcoord_Airfoil[Trailing_Point], 2.0) +
                        pow(Ycoord_Airfoil[iVertex] - Ycoord_Airfoil[Trailing_Point], 2.0) +
                        pow(Zcoord_Airfoil[iVertex] - Zcoord_Airfoil[Trailing_Point], 2.0));

        if (MaxDistance < Distance) { MaxDistance = Distance; Leading_Point = iVertex; }
    }

    AoA = atan((Zcoord_Airfoil[Leading_Point] - Zcoord_Airfoil[Trailing_Point]) / (Xcoord_Airfoil[Trailing_Point] - Xcoord_Airfoil[Leading_Point]))*180/PI_NUMBER;

    /*--- Translate to the origin ---*/

    Xcoord_Trailing = Xcoord_Airfoil[0];
    Ycoord_Trailing = Ycoord_Airfoil[0];
    Zcoord_Trailing = Zcoord_Airfoil[0];

    for (iVertex = 0; iVertex < Xcoord_Airfoil.size(); iVertex++) {
        Xcoord_Airfoil_.push_back(Xcoord_Airfoil[iVertex] - Xcoord_Trailing);
        Ycoord_Airfoil_.push_back(Ycoord_Airfoil[iVertex] - Ycoord_Trailing);
        Zcoord_Airfoil_.push_back(Zcoord_Airfoil[iVertex] - Zcoord_Trailing);
    }

    /*--- Rotate the airfoil ---*/

    ValCos = cos(AoA*PI_NUMBER/180.0);
    ValSin = sin(AoA*PI_NUMBER/180.0);

    for (iVertex = 0; iVertex < Xcoord_Airfoil.size(); iVertex++) {
        XValue = Xcoord_Airfoil_[iVertex];
        ZValue = Zcoord_Airfoil_[iVertex];

        Xcoord_Airfoil_[iVertex] = XValue*ValCos - ZValue*ValSin;
        Zcoord_Airfoil_[iVertex] = ZValue*ValCos + XValue*ValSin;

    }

    /*--- Identify upper and lower side, and store the value of the normal --*/

    for (iVertex = 1; iVertex < Xcoord_Airfoil_.size(); iVertex++) {
        Tangent[0] = Xcoord_Airfoil_[iVertex] - Xcoord_Airfoil_[iVertex-1];
        Tangent[1] = Ycoord_Airfoil_[iVertex] - Ycoord_Airfoil_[iVertex-1];
        Tangent[2] = Zcoord_Airfoil_[iVertex] - Zcoord_Airfoil_[iVertex-1];
        Length = sqrt(pow(Tangent[0], 2.0) + pow(Tangent[1], 2.0) + pow(Tangent[2], 2.0));
        Tangent[0] /= Length; Tangent[1] /= Length; Tangent[2] /= Length;

        BiNormal[0] = Plane_Normal[0];
        BiNormal[1] = Plane_Normal[1];
        BiNormal[2] = Plane_Normal[2];
        Length = sqrt(pow(BiNormal[0], 2.0) + pow(BiNormal[1], 2.0) + pow(BiNormal[2], 2.0));
        BiNormal[0] /= Length; BiNormal[1] /= Length; BiNormal[2] /= Length;

        Normal[0] = Tangent[1]*BiNormal[2] - Tangent[2]*BiNormal[1];
        Normal[1] = Tangent[2]*BiNormal[0] - Tangent[0]*BiNormal[2];
        Normal[2] = Tangent[0]*BiNormal[1] - Tangent[1]*BiNormal[0];

        Xcoord_Normal.push_back(Normal[0]); Ycoord_Normal.push_back(Normal[1]); Zcoord_Normal.push_back(Normal[2]);

        unsigned short index = 2;
        if ((config->GetAxis_Orientation() == Z_AXIS) && (nDim == 3)) index = 0;

        if (Normal[index] >= 0.0) {
            Xcoord.push_back(Xcoord_Airfoil_[iVertex]);
            Ycoord.push_back(Ycoord_Airfoil_[iVertex]);
            Zcoord.push_back(Zcoord_Airfoil_[iVertex]);
        }

    }

    /*--- Order the arrays using the X component ---*/

    for (iVertex = 0; iVertex < Xcoord.size(); iVertex++) {
        for (jVertex = 0; jVertex < Xcoord.size() - 1 - iVertex; jVertex++) {
            if (Xcoord[jVertex] > Xcoord[jVertex+1]) {
                auxXCoord = Xcoord[jVertex]; Xcoord[jVertex] = Xcoord[jVertex+1]; Xcoord[jVertex+1] = auxXCoord;
                auxYCoord = Ycoord[jVertex]; Ycoord[jVertex] = Ycoord[jVertex+1]; Ycoord[jVertex+1] = auxYCoord;
                auxZCoord = Zcoord[jVertex]; Zcoord[jVertex] = Zcoord[jVertex+1]; Zcoord[jVertex+1] = auxZCoord;
            }
        }
    }

    n = Xcoord.size();
    zp1 = (Zcoord[1]-Zcoord[0])/(Xcoord[1]-Xcoord[0]);
    zpn = (Zcoord[n-1]-Zcoord[n-2])/(Xcoord[n-1]-Xcoord[n-2]);
    Z2coord.resize(n+1);
    SetSpline(Xcoord, Zcoord, n, zp1, zpn, Z2coord);

    /*--- Compute the thickness (we add a fabs because we can not guarantee the
   right sorting of the points and the upper and/or lower part of the airfoil is not well defined) ---*/

    MaxThickness_Value = 0.0;
    for (iVertex = 0; iVertex < Xcoord_Airfoil_.size(); iVertex++) {
        if (Zcoord_Normal[iVertex] < 0.0) {
            Thickness = fabs(Zcoord_Airfoil_[iVertex] - GetSpline(Xcoord, Zcoord, Z2coord, n, Xcoord_Airfoil_[iVertex]));
            if (Thickness > MaxThickness_Value) { MaxThickness_Value = Thickness; }
        }
    }

    return MaxThickness_Value;

}

double CPhysicalGeometry::Compute_AoA(double *Plane_P0, double *Plane_Normal, unsigned short iSection, vector<double> &Xcoord_Airfoil, vector<double> &Ycoord_Airfoil, vector<double> &Zcoord_Airfoil, bool original_surface) {
    unsigned long iVertex, Trailing_Point, Leading_Point;
    double MaxDistance, Distance, AoA = 0.0;

    /*--- Find the leading and trailing edges and compute the angle of attack ---*/
    MaxDistance = 0.0; Trailing_Point = 0; Leading_Point = 0;
    for (iVertex = 1; iVertex < Xcoord_Airfoil.size(); iVertex++) {
        Distance = sqrt(pow(Xcoord_Airfoil[iVertex] - Xcoord_Airfoil[Trailing_Point], 2.0) +
                        pow(Ycoord_Airfoil[iVertex] - Ycoord_Airfoil[Trailing_Point], 2.0) +
                        pow(Zcoord_Airfoil[iVertex] - Zcoord_Airfoil[Trailing_Point], 2.0));

        if (MaxDistance < Distance) { MaxDistance = Distance; Leading_Point = iVertex; }
    }

    AoA = atan((Zcoord_Airfoil[Leading_Point] - Zcoord_Airfoil[Trailing_Point]) / (Xcoord_Airfoil[Trailing_Point] - Xcoord_Airfoil[Leading_Point]))*180/PI_NUMBER;

    return AoA;

}

double CPhysicalGeometry::Compute_Chord(double *Plane_P0, double *Plane_Normal, unsigned short iSection, vector<double> &Xcoord_Airfoil, vector<double> &Ycoord_Airfoil, vector<double> &Zcoord_Airfoil, bool original_surface) {
    unsigned long iVertex, Trailing_Point;
    double MaxDistance, Distance, Chord = 0.0;

    /*--- Find the leading and trailing edges and compute the angle of attack ---*/
    MaxDistance = 0.0; Trailing_Point = 0;
    for (iVertex = 1; iVertex < Xcoord_Airfoil.size(); iVertex++) {

        Distance = sqrt(pow(Xcoord_Airfoil[iVertex] - Xcoord_Airfoil[Trailing_Point], 2.0) +
                        pow(Ycoord_Airfoil[iVertex] - Ycoord_Airfoil[Trailing_Point], 2.0) +
                        pow(Zcoord_Airfoil[iVertex] - Zcoord_Airfoil[Trailing_Point], 2.0));

        if (MaxDistance < Distance) { MaxDistance = Distance; }
    }

    Chord = MaxDistance;

    return Chord;

}

double CPhysicalGeometry::Compute_Thickness(double *Plane_P0, double *Plane_Normal, unsigned short iSection, double Location, CConfig *config, vector<double> &Xcoord_Airfoil, vector<double> &Ycoord_Airfoil, vector<double> &Zcoord_Airfoil, bool original_surface) {
    unsigned long iVertex, jVertex, n_Upper, n_Lower, Trailing_Point, Leading_Point;
    double Thickness_Location, Normal[3], Tangent[3], BiNormal[3], auxXCoord, auxYCoord, auxZCoord, Thickness_Value = 0.0, Length, Xcoord_Trailing, Ycoord_Trailing, Zcoord_Trailing, ValCos, ValSin, XValue, ZValue, zp1, zpn, Chord, MaxDistance, Distance, AoA;
    vector<double> Xcoord_Upper, Ycoord_Upper, Zcoord_Upper, Z2coord_Upper, Xcoord_Lower, Ycoord_Lower, Zcoord_Lower, Z2coord_Lower, Z2coord, Xcoord_Normal, Ycoord_Normal, Zcoord_Normal, Xcoord_Airfoil_, Ycoord_Airfoil_, Zcoord_Airfoil_;

    /*--- Find the leading and trailing edges and compute the angle of attack ---*/

    MaxDistance = 0.0; Trailing_Point = 0; Leading_Point = 0;
    for (iVertex = 1; iVertex < Xcoord_Airfoil.size(); iVertex++) {
        Distance = sqrt(pow(Xcoord_Airfoil[iVertex] - Xcoord_Airfoil[Trailing_Point], 2.0) +
                        pow(Ycoord_Airfoil[iVertex] - Ycoord_Airfoil[Trailing_Point], 2.0) +
                        pow(Zcoord_Airfoil[iVertex] - Zcoord_Airfoil[Trailing_Point], 2.0));

        if (MaxDistance < Distance) { MaxDistance = Distance; Leading_Point = iVertex; }
    }

    AoA = atan((Zcoord_Airfoil[Leading_Point] - Zcoord_Airfoil[Trailing_Point]) / (Xcoord_Airfoil[Trailing_Point] - Xcoord_Airfoil[Leading_Point]))*180/PI_NUMBER;
    Chord = MaxDistance;

    /*--- Translate to the origin ---*/

    Xcoord_Trailing = Xcoord_Airfoil[0];
    Ycoord_Trailing = Ycoord_Airfoil[0];
    Zcoord_Trailing = Zcoord_Airfoil[0];

    for (iVertex = 0; iVertex < Xcoord_Airfoil.size(); iVertex++) {
        Xcoord_Airfoil_.push_back(Xcoord_Airfoil[iVertex] - Xcoord_Trailing);
        Ycoord_Airfoil_.push_back(Ycoord_Airfoil[iVertex] - Ycoord_Trailing);
        Zcoord_Airfoil_.push_back(Zcoord_Airfoil[iVertex] - Zcoord_Trailing);
    }

    /*--- Rotate the airfoil ---*/

    ValCos = cos(AoA*PI_NUMBER/180.0);
    ValSin = sin(AoA*PI_NUMBER/180.0);

    for (iVertex = 0; iVertex < Xcoord_Airfoil.size(); iVertex++) {
        XValue = Xcoord_Airfoil_[iVertex];
        ZValue = Zcoord_Airfoil_[iVertex];

        Xcoord_Airfoil_[iVertex] = XValue*ValCos - ZValue*ValSin;
        Zcoord_Airfoil_[iVertex] = ZValue*ValCos + XValue*ValSin;
    }

    /*--- Identify upper and lower side, and store the value of the normal --*/

    for (iVertex = 1; iVertex < Xcoord_Airfoil_.size(); iVertex++) {
        Tangent[0] = Xcoord_Airfoil_[iVertex] - Xcoord_Airfoil_[iVertex-1];
        Tangent[1] = Ycoord_Airfoil_[iVertex] - Ycoord_Airfoil_[iVertex-1];
        Tangent[2] = Zcoord_Airfoil_[iVertex] - Zcoord_Airfoil_[iVertex-1];
        Length = sqrt(pow(Tangent[0], 2.0) + pow(Tangent[1], 2.0) + pow(Tangent[2], 2.0));
        Tangent[0] /= Length; Tangent[1] /= Length; Tangent[2] /= Length;

        BiNormal[0] = Plane_Normal[0];
        BiNormal[1] = Plane_Normal[1];
        BiNormal[2] = Plane_Normal[2];
        Length = sqrt(pow(BiNormal[0], 2.0) + pow(BiNormal[1], 2.0) + pow(BiNormal[2], 2.0));
        BiNormal[0] /= Length; BiNormal[1] /= Length; BiNormal[2] /= Length;

        Normal[0] = Tangent[1]*BiNormal[2] - Tangent[2]*BiNormal[1];
        Normal[1] = Tangent[2]*BiNormal[0] - Tangent[0]*BiNormal[2];
        Normal[2] = Tangent[0]*BiNormal[1] - Tangent[1]*BiNormal[0];

        Xcoord_Normal.push_back(Normal[0]); Ycoord_Normal.push_back(Normal[1]); Zcoord_Normal.push_back(Normal[2]);

        unsigned short index = 2;
        if ((config->GetAxis_Orientation() == Z_AXIS) && (nDim == 3)) index = 0;

        if (Normal[index] >= 0.0) {
            Xcoord_Upper.push_back(Xcoord_Airfoil_[iVertex]);
            Ycoord_Upper.push_back(Ycoord_Airfoil_[iVertex]);
            Zcoord_Upper.push_back(Zcoord_Airfoil_[iVertex]);
        }
        else {
            Xcoord_Lower.push_back(Xcoord_Airfoil_[iVertex]);
            Ycoord_Lower.push_back(Ycoord_Airfoil_[iVertex]);
            Zcoord_Lower.push_back(Zcoord_Airfoil_[iVertex]);
        }

    }

    /*--- Order the arrays using the X component ---*/

    for (iVertex = 0; iVertex < Xcoord_Upper.size(); iVertex++) {
        for (jVertex = 0; jVertex < Xcoord_Upper.size() - 1 - iVertex; jVertex++) {
            if (Xcoord_Upper[jVertex] > Xcoord_Upper[jVertex+1]) {
                auxXCoord = Xcoord_Upper[jVertex]; Xcoord_Upper[jVertex] = Xcoord_Upper[jVertex+1]; Xcoord_Upper[jVertex+1] = auxXCoord;
                auxYCoord = Ycoord_Upper[jVertex]; Ycoord_Upper[jVertex] = Ycoord_Upper[jVertex+1]; Ycoord_Upper[jVertex+1] = auxYCoord;
                auxZCoord = Zcoord_Upper[jVertex]; Zcoord_Upper[jVertex] = Zcoord_Upper[jVertex+1]; Zcoord_Upper[jVertex+1] = auxZCoord;
            }
        }
    }

    /*--- Order the arrays using the X component ---*/

    for (iVertex = 0; iVertex < Xcoord_Lower.size(); iVertex++) {
        for (jVertex = 0; jVertex < Xcoord_Lower.size() - 1 - iVertex; jVertex++) {
            if (Xcoord_Lower[jVertex] > Xcoord_Lower[jVertex+1]) {
                auxXCoord = Xcoord_Lower[jVertex]; Xcoord_Lower[jVertex] = Xcoord_Lower[jVertex+1]; Xcoord_Lower[jVertex+1] = auxXCoord;
                auxYCoord = Ycoord_Lower[jVertex]; Ycoord_Lower[jVertex] = Ycoord_Lower[jVertex+1]; Ycoord_Lower[jVertex+1] = auxYCoord;
                auxZCoord = Zcoord_Lower[jVertex]; Zcoord_Lower[jVertex] = Zcoord_Lower[jVertex+1]; Zcoord_Lower[jVertex+1] = auxZCoord;
            }
        }
    }

    n_Upper = Xcoord_Upper.size();
    zp1 = (Zcoord_Upper[1]-Zcoord_Upper[0])/(Xcoord_Upper[1]-Xcoord_Upper[0]);
    zpn = (Zcoord_Upper[n_Upper-1]-Zcoord_Upper[n_Upper-2])/(Xcoord_Upper[n_Upper-1]-Xcoord_Upper[n_Upper-2]);
    Z2coord_Upper.resize(n_Upper+1);
    SetSpline(Xcoord_Upper, Zcoord_Upper, n_Upper, zp1, zpn, Z2coord_Upper);

    n_Lower = Xcoord_Lower.size();
    zp1 = (Zcoord_Lower[1]-Zcoord_Lower[0])/(Xcoord_Lower[1]-Xcoord_Lower[0]);
    zpn = (Zcoord_Lower[n_Lower-1]-Zcoord_Lower[n_Lower-2])/(Xcoord_Lower[n_Lower-1]-Xcoord_Lower[n_Lower-2]);
    Z2coord_Lower.resize(n_Lower+1);
    SetSpline(Xcoord_Lower, Zcoord_Lower, n_Lower, zp1, zpn, Z2coord_Lower);

    /*--- Compute the thickness (we add a fabs because we can not guarantee the
   right sorting of the points and the upper and/or lower part of the airfoil is not well defined) ---*/

    Thickness_Location = - Chord*(1.0-Location);

    Thickness_Value = fabs(GetSpline(Xcoord_Upper, Zcoord_Upper, Z2coord_Upper, n_Upper, Thickness_Location) - GetSpline(Xcoord_Lower, Zcoord_Lower, Z2coord_Lower, n_Lower, Thickness_Location));

    return Thickness_Value;

}

double CPhysicalGeometry::Compute_Area(double *Plane_P0, double *Plane_Normal, unsigned short iSection, CConfig *config, vector<double> &Xcoord_Airfoil, vector<double> &Ycoord_Airfoil, vector<double> &Zcoord_Airfoil, bool original_surface) {
    unsigned long iVertex, jVertex;
    double Normal[3], Tangent[3], BiNormal[3], auxXCoord, auxYCoord, auxZCoord, Area_Value = 0.0, Area_Value_Upper = 0.0, Area_Value_Lower = 0.0, Length, Xcoord_Trailing, Ycoord_Trailing, Zcoord_Trailing, ValCos, ValSin, XValue, ZValue;
    vector<double> Xcoord_Upper, Ycoord_Upper, Zcoord_Upper, Xcoord_Lower, Ycoord_Lower, Zcoord_Lower, Z2coord, Xcoord_Normal, Ycoord_Normal, Zcoord_Normal, Xcoord_Airfoil_, Ycoord_Airfoil_, Zcoord_Airfoil_;
    unsigned long Trailing_Point, Leading_Point;
    double MaxDistance, Distance, AoA;

    /*--- Find the leading and trailing edges and compute the angle of attack ---*/

    MaxDistance = 0.0; Trailing_Point = 0; Leading_Point = 0;
    for (iVertex = 1; iVertex < Xcoord_Airfoil.size(); iVertex++) {
        Distance = sqrt(pow(Xcoord_Airfoil[iVertex] - Xcoord_Airfoil[Trailing_Point], 2.0) +
                        pow(Ycoord_Airfoil[iVertex] - Ycoord_Airfoil[Trailing_Point], 2.0) +
                        pow(Zcoord_Airfoil[iVertex] - Zcoord_Airfoil[Trailing_Point], 2.0));

        if (MaxDistance < Distance) { MaxDistance = Distance; Leading_Point = iVertex; }
    }

    AoA = atan((Zcoord_Airfoil[Leading_Point] - Zcoord_Airfoil[Trailing_Point]) / (Xcoord_Airfoil[Trailing_Point] - Xcoord_Airfoil[Leading_Point]))*180/PI_NUMBER;

    /*--- Translate to the origin ---*/

    Xcoord_Trailing = Xcoord_Airfoil[0];
    Ycoord_Trailing = Ycoord_Airfoil[0];
    Zcoord_Trailing = Zcoord_Airfoil[0];

    for (iVertex = 0; iVertex < Xcoord_Airfoil.size(); iVertex++) {
        Xcoord_Airfoil_.push_back(Xcoord_Airfoil[iVertex] - Xcoord_Trailing);
        Ycoord_Airfoil_.push_back(Ycoord_Airfoil[iVertex] - Ycoord_Trailing);
        Zcoord_Airfoil_.push_back(Zcoord_Airfoil[iVertex] - Zcoord_Trailing);
    }

    /*--- Rotate the airfoil ---*/

    ValCos = cos(AoA*PI_NUMBER/180.0);
    ValSin = sin(AoA*PI_NUMBER/180.0);

    for (iVertex = 0; iVertex < Xcoord_Airfoil.size(); iVertex++) {
        XValue = Xcoord_Airfoil_[iVertex];
        ZValue = Zcoord_Airfoil_[iVertex];

        Xcoord_Airfoil_[iVertex] = XValue*ValCos - ZValue*ValSin;
        Zcoord_Airfoil_[iVertex] = ZValue*ValCos + XValue*ValSin;

    }

    /*--- Identify upper and lower side, and store the value of the normal --*/

    for (iVertex = 1; iVertex < Xcoord_Airfoil_.size(); iVertex++) {
        Tangent[0] = Xcoord_Airfoil_[iVertex] - Xcoord_Airfoil_[iVertex-1];
        Tangent[1] = Ycoord_Airfoil_[iVertex] - Ycoord_Airfoil_[iVertex-1];
        Tangent[2] = Zcoord_Airfoil_[iVertex] - Zcoord_Airfoil_[iVertex-1];
        Length = sqrt(pow(Tangent[0], 2.0) + pow(Tangent[1], 2.0) + pow(Tangent[2], 2.0));
        Tangent[0] /= Length; Tangent[1] /= Length; Tangent[2] /= Length;

        BiNormal[0] = Plane_Normal[0];
        BiNormal[1] = Plane_Normal[1];
        BiNormal[2] = Plane_Normal[2];
        Length = sqrt(pow(BiNormal[0], 2.0) + pow(BiNormal[1], 2.0) + pow(BiNormal[2], 2.0));
        BiNormal[0] /= Length; BiNormal[1] /= Length; BiNormal[2] /= Length;

        Normal[0] = Tangent[1]*BiNormal[2] - Tangent[2]*BiNormal[1];
        Normal[1] = Tangent[2]*BiNormal[0] - Tangent[0]*BiNormal[2];
        Normal[2] = Tangent[0]*BiNormal[1] - Tangent[1]*BiNormal[0];

        Xcoord_Normal.push_back(Normal[0]); Ycoord_Normal.push_back(Normal[1]); Zcoord_Normal.push_back(Normal[2]);

        unsigned short index = 2;
        if ((config->GetAxis_Orientation() == Z_AXIS) && (nDim == 3)) index = 0;

        if (Normal[index] >= 0.0) {
            Xcoord_Upper.push_back(Xcoord_Airfoil_[iVertex]);
            Ycoord_Upper.push_back(Ycoord_Airfoil_[iVertex]);
            Zcoord_Upper.push_back(Zcoord_Airfoil_[iVertex]);
        }
        else {
            Xcoord_Lower.push_back(Xcoord_Airfoil_[iVertex]);
            Ycoord_Lower.push_back(Ycoord_Airfoil_[iVertex]);
            Zcoord_Lower.push_back(Zcoord_Airfoil_[iVertex]);
        }

    }

    /*--- Order the arrays using the X component ---*/

    for (iVertex = 0; iVertex < Xcoord_Upper.size(); iVertex++) {
        for (jVertex = 0; jVertex < Xcoord_Upper.size() - 1 - iVertex; jVertex++) {
            if (Xcoord_Upper[jVertex] > Xcoord_Upper[jVertex+1]) {
                auxXCoord = Xcoord_Upper[jVertex]; Xcoord_Upper[jVertex] = Xcoord_Upper[jVertex+1]; Xcoord_Upper[jVertex+1] = auxXCoord;
                auxYCoord = Ycoord_Upper[jVertex]; Ycoord_Upper[jVertex] = Ycoord_Upper[jVertex+1]; Ycoord_Upper[jVertex+1] = auxYCoord;
                auxZCoord = Zcoord_Upper[jVertex]; Zcoord_Upper[jVertex] = Zcoord_Upper[jVertex+1]; Zcoord_Upper[jVertex+1] = auxZCoord;
            }
        }
    }

    /*--- Order the arrays using the X component ---*/

    for (iVertex = 0; iVertex < Xcoord_Lower.size(); iVertex++) {
        for (jVertex = 0; jVertex < Xcoord_Lower.size() - 1 - iVertex; jVertex++) {
            if (Xcoord_Lower[jVertex] > Xcoord_Lower[jVertex+1]) {
                auxXCoord = Xcoord_Lower[jVertex]; Xcoord_Lower[jVertex] = Xcoord_Lower[jVertex+1]; Xcoord_Lower[jVertex+1] = auxXCoord;
                auxYCoord = Ycoord_Lower[jVertex]; Ycoord_Lower[jVertex] = Ycoord_Lower[jVertex+1]; Ycoord_Lower[jVertex+1] = auxYCoord;
                auxZCoord = Zcoord_Lower[jVertex]; Zcoord_Lower[jVertex] = Zcoord_Lower[jVertex+1]; Zcoord_Lower[jVertex+1] = auxZCoord;
            }
        }
    }

    /*--- Compute total area ---*/

    Area_Value_Upper = 0.0;
    Area_Value_Lower = 0.0;

    for (iVertex = 0; iVertex < Xcoord_Upper.size()-1; iVertex++)
        Area_Value_Upper += (Xcoord_Upper[iVertex+1] - Xcoord_Upper[iVertex]) * 0.5*(Zcoord_Upper[iVertex+1] + Zcoord_Upper[iVertex]);
    for (iVertex = 0; iVertex < Xcoord_Lower.size()-1; iVertex++)
        Area_Value_Lower += (Xcoord_Lower[iVertex+1] - Xcoord_Lower[iVertex]) * 0.5*(Zcoord_Lower[iVertex+1] + Zcoord_Lower[iVertex]);

    Area_Value = fabs(Area_Value_Upper - Area_Value_Lower);
    return Area_Value;

}

double CPhysicalGeometry::Compute_Volume(CConfig *config, bool original_surface) {

}

CMultiGridGeometry::CMultiGridGeometry(CGeometry ***geometry, CConfig **config_container, unsigned short iMesh, unsigned short iZone) : CGeometry() {

}


CMultiGridGeometry::~CMultiGridGeometry(void) {

}

bool CMultiGridGeometry::SetBoundAgglomeration(unsigned long CVPoint, short marker_seed, CGeometry *fine_grid, CConfig *config) {

}


bool CMultiGridGeometry::GeometricalCheck(unsigned long iPoint, CGeometry *fine_grid, CConfig *config) {

}

void CMultiGridGeometry::SetSuitableNeighbors(vector<unsigned long> *Suitable_Indirect_Neighbors, unsigned long iPoint,
                                              unsigned long Index_CoarseCV, CGeometry *fine_grid) {
}

void CMultiGridGeometry::SetPoint_Connectivity(CGeometry *fine_grid) {

}

void CMultiGridGeometry::SetVertex(CGeometry *fine_grid, CConfig *config) {

}

void CMultiGridGeometry::MatchNearField(CConfig *config) {

}

void CMultiGridGeometry::MatchActuator_Disk(CConfig *config) {

}

void CMultiGridGeometry::MatchInterface(CConfig *config) {

}


void CMultiGridGeometry::SetControlVolume(CConfig *config, CGeometry *fine_grid, unsigned short action) {

}

void CMultiGridGeometry::SetBoundControlVolume(CConfig *config, CGeometry *fine_grid, unsigned short action) {

}

void CMultiGridGeometry::SetCoord(CGeometry *geometry) {

}

void CMultiGridGeometry::SetRotationalVelocity(CConfig *config) {

}

void CMultiGridGeometry::SetGridVelocity(CConfig *config, unsigned long iter) {

}

void CMultiGridGeometry::SetRestricted_GridVelocity(CGeometry *fine_mesh, CConfig *config) {

}


void CMultiGridGeometry::FindNormal_Neighbor(CConfig *config) {

}


void CMultiGridGeometry::SetGeometryPlanes(CConfig *config) {

}

CPeriodicGeometry::CPeriodicGeometry(CGeometry *geometry, CConfig *config) {

}

CPeriodicGeometry::~CPeriodicGeometry(void) {

}

void CPeriodicGeometry::SetPeriodicBoundary(CGeometry *geometry, CConfig *config) {

}

void CPeriodicGeometry::SetMeshFile(CGeometry *geometry, CConfig *config, string val_mesh_out_filename) {

}

void CPeriodicGeometry::SetTecPlot(char mesh_filename[MAX_STRING_SIZE]) {

}

CMultiGridQueue::CMultiGridQueue(unsigned long val_npoint) {

}

CMultiGridQueue::~CMultiGridQueue(void) {

}

void CMultiGridQueue::AddCV(unsigned long val_new_point, unsigned short val_number_neighbors) {

}

void CMultiGridQueue::RemoveCV(unsigned long val_remove_point) {

}

void CMultiGridQueue::MoveCV(unsigned long val_move_point, short val_number_neighbors) {

}

void CMultiGridQueue::IncrPriorityCV(unsigned long val_incr_point) {

}

void CMultiGridQueue::RedPriorityCV(unsigned long val_red_point) {

}

void CMultiGridQueue::VisualizeQueue(void) {

}

void CMultiGridQueue::VisualizePriority(void) {

}

long CMultiGridQueue::NextCV(void) {

}

bool CMultiGridQueue::EmptyQueue(void) {

}

unsigned long CMultiGridQueue::TotalCV(void) {

}

void CMultiGridQueue::Update(unsigned long iPoint, CGeometry *fine_grid) {

}
